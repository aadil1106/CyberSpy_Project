"""
Seed script: wipes existing data and populates realistic fake OSINT data.

Structure:
  10 cities × 5 branches × 5 officers × 10-15 login logs + 1-2 result logs each
"""

import os
import sys
import json
import random
from datetime import datetime, date, timedelta
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app.db.session import SessionLocal, Base, engine
from app.models.city import City
from app.models.branch import Branch
from app.models.officer import Officer
from app.models.officer_login_log import OfficerLoginLog
from app.models.result_log import ResultLog
from app.models.search_type import SearchType
from app.core.security import hash_password

# ─── Constants ─────────────────────────────────────────────────────────────────

CITY_DATA = [
    ("Mumbai",     400001),
    ("Delhi",      110001),
    ("Bengaluru",  560001),
    ("Hyderabad",  500001),
    ("Chennai",    600001),
    ("Kolkata",    700001),
    ("Ahmedabad",  380001),
    ("Pune",       411001),
    ("Jaipur",     302001),
    ("Lucknow",    226001),
]

BRANCH_NAMES = [
    "Central", "North", "South", "East", "West",
    "HQ", "Metro", "District", "Tech Park", "Cyber"
]

FIRST_NAMES_M = ["Rahul", "Amit", "Vikas", "Deepak", "Rajesh",
                  "Sanjay", "Manish", "Suresh", "Arun", "Kiran",
                  "Tarun", "Pradeep", "Nitin", "Gaurav", "Naveen"]
FIRST_NAMES_F = ["Priya", "Sunita", "Anjali", "Rekha", "Pooja",
                  "Neha", "Kavita", "Anita", "Swati", "Meena",
                  "Sonia", "Rita", "Divya", "Jyoti", "Radha"]
LAST_NAMES   = ["Sharma", "Verma", "Gupta", "Singh", "Kumar",
                 "Joshi", "Patel", "Mehta", "Shah", "Chopra",
                 "Malhotra", "Nair", "Pillai", "Iyer", "Reddy"]

SEARCH_USERNAMES = [
    "rahul_india_99", "isthaturja", "aadil_can_sing", "deepika_mumbai_21",
    "preetisinha_of", "siddharth_kv", "meenakshi_blr", "riya_ahmedabad",
    "ankit_malhotra", "_kunaladwani_", "sherrydoc013", "siimii_21",
    "dhwanirpshah", "abhishek_hyd", "codroit_in"
]

RISK_LEVELS = ["low", "low", "medium", "medium", "high"]

SEARCH_TYPES_LIST = ["single-platform", "multi-platform"]

RESULTS_DIR = Path("search_results")
RESULTS_DIR.mkdir(exist_ok=True)

# ─── Helpers ────────────────────────────────────────────────────────────────────

def rand_date_between(start_days_ago: int, end_days_ago: int) -> datetime:
    delta = random.randint(end_days_ago, start_days_ago)
    return datetime.utcnow() - timedelta(days=delta)

def rand_dob() -> date:
    start = date(1975, 1, 1)
    end = date(2000, 12, 31)
    return start + timedelta(days=random.randint(0, (end - start).days))

def make_phone(used: set) -> str:
    while True:
        num = f"9{random.randint(100000000, 999999999)}"
        if num not in used:
            used.add(num)
            return num

def make_email(first: str, last: str, city: str, used: set) -> str:
    base = f"{first.lower()}.{last.lower()}{random.randint(10, 999)}@cyberspy.in"
    counter = 0
    candidate = base
    while candidate in used:
        counter += 1
        candidate = f"{first.lower()}.{last.lower()}{random.randint(10, 9999)+counter}@cyberspy.in"
    used.add(candidate)
    return candidate

def make_result_json(officer_id: int, username: str, search_type: str, platform: str, timestamp: datetime) -> dict:
    risk = random.choice(RISK_LEVELS)
    risk_score = {"low": random.randint(5, 30), "medium": random.randint(31, 60), "high": random.randint(61, 95)}[risk]
    posts = []
    for i in range(random.randint(3, 6)):
        posts.append({
            "post_url": f"https://www.instagram.com/p/Fake{random.randint(100000,999999)}/",
            "caption": random.choice([
                "Exciting new opportunity! 💰 DM for details. #finance #income",
                "Beautiful sunset in the city 🌇 #life #travel",
                "Just launched my new course. Join now! Limited seats. #learning",
                "Government approved investment scheme — guaranteed returns! #invest",
                "Happy to share my latest achievement 🏆 #success #motivated"
            ]),
            "likes": random.randint(20, 2000),
            "comments": random.randint(5, 300),
            "date": (timestamp - timedelta(days=i * 3)).isoformat(),
            "is_video": random.choice([True, False]),
            "video_views": random.randint(500, 50000) if random.random() > 0.5 else None
        })
    return {
        "search_type": search_type,
        "username": username,
        "platform": platform,
        "officer_id": officer_id,
        "timestamp": timestamp.isoformat(),
        "result": {
            "profile": {
                "username": username,
                "full_name": username.replace("_", " ").title(),
                "biography": f"Bio for {username} | Interests: crypto, finance, fitness",
                "followers": random.randint(500, 50000),
                "following": random.randint(100, 5000),
                "posts_count": random.randint(10, 200),
                "is_private": random.choice([True, False]),
                "is_verified": random.choice([True, False, False]),
                "profile_pic_url": f"https://ui-avatars.com/api/?name={username}&background=random",
                "external_url": f"https://bit.ly/{username}" if random.random() > 0.6 else None,
                "is_business_account": random.choice([True, False]),
                "business_category": random.choice(["Finance", "Tech", "Health", None])
            },
            "recent_posts": posts,
            "engagement_rate": round(random.uniform(1.0, 12.5), 2),
            "avg_likes": random.randint(50, 1500),
            "avg_comments": random.randint(5, 200),
            "found": True,
            "error": None,
            "cybercrime_analysis": {
                "risk_level": risk,
                "risk_score": risk_score,
                "indicators": random.sample([
                    "Promotes guaranteed high financial returns",
                    "Requests upfront registration fees",
                    "Uses government scheme branding",
                    "External shortened URL linked to unverified scheme",
                    "Unusually high engagement ratio",
                    "Multiple solicitation posts",
                    "Inconsistent location data",
                    "Newly created account with burst activity"
                ], k=random.randint(2, 5)),
                "categories": random.sample(["investment_fraud", "financial_scam", "phishing", "spam", "impersonation"], k=random.randint(1, 3)),
                "summary": f"The account @{username} exhibits {'high' if risk == 'high' else 'moderate'} risk indicators. {'Immediate review recommended.' if risk == 'high' else 'Monitor for further activity.'}",
                "recommendations": [
                    "Flag for cybercrime review unit",
                    "Monitor DM transactions",
                    "Cross-reference with known fraud databases"
                ],
                "detailed_analysis": {
                    "bio_analysis": f"The bio for @{username} uses attention-capturing financial language.",
                    "content_analysis": f"Posts analyzed for @{username} show {'frequent financial solicitation' if risk == 'high' else 'mixed content with some concerning patterns'}.",
                    "engagement_analysis": "Engagement rate is above average for account size.",
                    "language_analysis": "Language uses urgency and emotional triggers consistent with social engineering."
                }
            },
            "ai_summary": f"**Account @{username}** — Risk Level: {risk.upper()}\n\nProfiled on {platform}. Account shows {'strong fraud indicators and warrants immediate investigation.' if risk == 'high' else 'some questionable patterns that should be monitored over time.'}"
        }
    }


# ─── Main Seed ──────────────────────────────────────────────────────────────────

def seed():
    db = SessionLocal()
    print("🗑️  Clearing existing data...")

    # Clear in FK-safe order
    db.query(ResultLog).delete()
    db.query(OfficerLoginLog).delete()
    db.query(Officer).delete()
    db.query(Branch).delete()
    db.query(City).delete()
    db.query(SearchType).delete()
    db.commit()
    print("✅ All existing data deleted.")

    # Ensure search types
    search_type_objs = {}
    for st in SEARCH_TYPES_LIST:
        obj = SearchType(search_type=st, is_active=True)
        db.add(obj)
        db.flush()
        search_type_objs[st] = obj
    db.commit()
    print("✅ Search types created.")

    used_phones = set()
    used_emails = set()
    officer_counter = 0

    for city_idx, (city_name, base_pin) in enumerate(CITY_DATA):
        city = City(city_name=city_name, is_active=True)
        db.add(city)
        db.flush()
        print(f"\n🏙️  City: {city_name} (id={city.id})")

        for b_idx in range(5):
            branch_name = f"{BRANCH_NAMES[b_idx]} {city_name[:3]}"
            pincode = base_pin + b_idx * 10
            branch = Branch(city_id=city.id, branch_name=branch_name, pincode=pincode, is_active=True)
            db.add(branch)
            db.flush()
            print(f"  🏢 Branch: {branch_name} (id={branch.id})")

            for o_idx in range(5):
                officer_counter += 1
                gender = random.choice(["M", "F"])
                first_name = random.choice(FIRST_NAMES_M if gender == "M" else FIRST_NAMES_F)
                last_name = random.choice(LAST_NAMES)
                dob = rand_dob()
                phone = make_phone(used_phones)
                email = make_email(first_name, last_name, city_name, used_emails)
                password = hash_password("Officer@123")
                created_at = rand_date_between(365, 60)

                officer = Officer(
                    branch_id=branch.id,
                    first_name=first_name,
                    last_name=last_name,
                    gender=gender,
                    dob=dob,
                    phone_no=phone,
                    email=email,
                    password=password,
                    created_at=created_at,
                    modified_at=created_at,
                    is_active=random.choices([True, False], weights=[0.9, 0.1])[0]
                )
                db.add(officer)
                db.flush()
                print(f"    👮 Officer: {first_name} {last_name} ({email}) id={officer.id}")

                # Login logs: 10–15 per officer
                num_logins = random.randint(10, 15)
                for ll_idx in range(num_logins):
                    days_ago = random.randint(1, 180)
                    login_log = OfficerLoginLog(
                        officer_id=officer.id,
                        loggedin_at=datetime.utcnow() - timedelta(days=days_ago, hours=random.randint(0, 23), minutes=random.randint(0, 59))
                    )
                    db.add(login_log)

                # Result logs: 1–2 per officer
                num_results = random.randint(1, 2)
                for rl_idx in range(num_results):
                    username = random.choice(SEARCH_USERNAMES)
                    st_key = random.choice(SEARCH_TYPES_LIST)
                    st_obj = search_type_objs[st_key]
                    platform = random.choice(["instagram", "facebook", "reddit", "telegram"])
                    ts = rand_date_between(180, 1)
                    ts_str = ts.strftime("%Y%m%d_%H%M%S")
                    safe_q = "".join(c if c.isalnum() else "_" for c in username)[:25]
                    filename = f"{st_key}_{safe_q}_{ts_str}.json"
                    file_path = RESULTS_DIR / filename

                    result_json = make_result_json(officer.id, username, st_key, platform, ts)
                    with open(file_path, "w", encoding="utf-8") as f:
                        json.dump(result_json, f, indent=2, ensure_ascii=False, default=str)

                    result_log = ResultLog(
                        officer_id=officer.id,
                        search_type_id=st_obj.id,
                        search_query=username[:30],
                        searched_at=ts,
                        result_file_path=str(file_path)
                    )
                    db.add(result_log)

    db.commit()
    print(f"\n\n✅ Seed complete!")
    print(f"   🏙️  Cities   : {len(CITY_DATA)}")
    print(f"   🏢 Branches  : {len(CITY_DATA) * 5}")
    print(f"   👮 Officers  : {officer_counter}")
    print(f"   📋 Login logs: ~{officer_counter * 12} (10-15 each)")
    print(f"   📄 Result logs: ~{officer_counter * 1} (1-2 each)")
    db.close()


if __name__ == "__main__":
    seed()
