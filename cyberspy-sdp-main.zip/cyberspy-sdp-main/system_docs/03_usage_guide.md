# Complete Usage Guide

## Table of Contents

1. [Getting Started](#getting-started)
2. [For Officers](#for-officers)
3. [For Administrators](#for-administrators)
4. [Using the Chatbot](#using-the-chatbot)
5. [Best Practices](#best-practices)
6. [Tips & Tricks](#tips--tricks)

---

## Getting Started

### Installation & Setup

1. **Install Dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

2. **Configure Environment**:
   Create a `.env` file in the root directory:
   ```env
   APP_NAME=Activity Monitoring Backend
   API_PREFIX=/api
   DATABASE_URL=sqlite:///./activity_monitoring.db
   DEBUG=true
   GEMINI_API_KEY=your_gemini_api_key_here
   SECRET_KEY=your_secret_key_for_jwt
   CHATBOT_ENABLED=true
   ```

3. **Run the Server**:
   
   **Option 1 - Using uvicorn directly**:
   ```bash
   uvicorn app.main:app --reload
   ```
   
   **Option 2 - Using main.py (supports debugging)**:
   ```bash
   python main.py
   ```

4. **Access the System**:
   - **Admin Panel**: http://localhost:8000
   - **API Docs**: http://localhost:8000/docs
   - **Alternative Docs**: http://localhost:8000/redoc

---

## For Officers

### 1. Logging In

#### Via Admin Panel
1. Navigate to http://localhost:8000
2. Click "Login" or navigate to the login page
3. Enter your email and password
4. Click "Login"
5. You'll receive a JWT token (stored automatically)

#### Via API
```bash
curl -X POST "http://localhost:8000/api/officers/login" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "officer@example.com",
    "password": "your_password"
  }'
```

**Response includes**:
- `access_token`: Use this for authenticated requests
- `token_type`: "bearer"
- `officer`: Your profile information

### 2. Performing Searches

#### Single Platform Search (Instagram)

**Via Admin Panel**:
1. Go to "Search" page
2. Select "Single Platform"
3. Choose platform: "Instagram"
4. Enter username
5. Select search type (e.g., "Investigation")
6. Click "Search"
7. Wait for results (may take 10-30 seconds)

**Via API**:
```bash
curl -X POST "http://localhost:8000/api/search/single-platform" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "username": "target_username",
    "platform": "instagram",
    "officer_id": 1
  }'
```

**What You Get**:
- Profile statistics (followers, following, posts)
- Recent posts with engagement metrics
- AI-powered cybercrime risk assessment
- Profile summary and analysis
- Business account information (if applicable)

#### Multi-Platform Search

**Via Admin Panel**:
1. Go to "Search" page
2. Select "Multi-Platform"
3. Enter username
4. Select platforms to search (or select all)
5. Select search type
6. Click "Search All Platforms"
7. Results appear for each platform

**Via API**:
```bash
curl -X POST "http://localhost:8000/api/search/multi-platform" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "keyword": "target_username",
    "platforms": ["instagram", "facebook", "reddit", "telegram"],
    "officer_id": 1
  }'
```

**Benefits**:
- Search all platforms at once
- Consolidated view of user presence
- Cross-platform analysis
- Time-saving for investigations

#### Hashtag/Keyword Search

**Use Case**: Find posts or profiles related to specific topics.

**Via API**:
```bash
curl -X POST "http://localhost:8000/api/search/hashtag-search" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "keyword": "#cybercrime",
    "limit": 20,
    "officer_id": 1
  }'
```

**Results Include**:
- Top posts with the hashtag
- Profiles frequently using the hashtag
- Engagement statistics
- Post timestamps

### 3. Understanding AI Analysis

#### Risk Levels

The AI analyzes profiles and assigns risk levels:

- **Low (0-25)**: No significant concerns
  - Normal personal account
  - Appropriate content
  - No suspicious patterns

- **Medium (26-50)**: Minor concerns
  - Some questionable content
  - Unusual posting patterns
  - Requires monitoring

- **High (51-75)**: Significant concerns
  - Multiple red flags
  - Suspicious behavior patterns
  - Potential illegal activity indicators

- **Critical (76-100)**: Immediate attention required
  - Clear cybercrime indicators
  - Illegal content or activities
  - Requires immediate action

#### Cybercrime Indicators

The AI looks for:
- **Scam/Fraud**: Fake giveaways, phishing attempts
- **Harassment**: Threatening language, bullying
- **Illegal Activities**: Drug references, weapon sales
- **Identity Theft**: Impersonation, fake accounts
- **Misinformation**: Fake news, conspiracy theories
- **Suspicious Patterns**: Unusual posting times, bot-like behavior

#### AI Summary

Each profile gets a comprehensive summary including:
- Overall assessment
- Content themes
- Behavioral patterns
- Engagement analysis
- Recommendations for action

### 4. Viewing Your Dashboard

**Via Admin Panel**:
1. Click "Dashboard" or "Home"
2. View your statistics:
   - Total searches performed
   - Reports generated
   - Login history
   - Recent activity
   - Search type breakdown
   - Most searched platform

**Via API**:
```bash
curl -X GET "http://localhost:8000/api/dashboard/officer/1" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**Dashboard Features**:
- **Profile Info**: Your account details
- **Activity Stats**: Searches, reports, logins (total, weekly, monthly)
- **Recent Searches**: Last 10 searches with quick access
- **Search Type Breakdown**: Visual distribution
- **Performance Metrics**: Average searches per day
- **Activity Timeline**: Daily search chart (last 30 days)

### 5. Generating Reports

#### From Search Results

**Via Admin Panel**:
1. After performing a search
2. Review the results and AI analysis
3. Click "Generate Report" or "Report Profile"
4. Fill in reporting details:
   - Platform
   - Username
   - Reporting results/notes
5. Click "Submit Report"
6. Report is saved to database

**Via API**:
```bash
curl -X POST "http://localhost:8000/api/reports" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "officer_id": 1,
    "username": "target_user",
    "social_media": "instagram",
    "reporting_results": "Account reported for suspicious activity. Risk level: High",
    "result_log_id": 123
  }'
```

#### Viewing Your Reports

**Via Admin Panel**:
1. Go to "Reports" page
2. View all your reports
3. Filter by:
   - Platform
   - Date range
   - Username
4. Sort by date, platform, etc.

**Via API**:
```bash
curl -X GET "http://localhost:8000/api/reports/filter?officer_id=1&page=1&page_size=20" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

### 6. Mass Reporting

**Use Case**: Report multiple profiles from a single search across different platforms.

**Via Admin Panel**:
1. Go to "Mass Report" page
2. View recent searches
3. Select a search result
4. Review the profiles found
5. Select platforms to report
6. Click "Mass Report"
7. View reporting results

**Via API**:

**Step 1 - Get recent searches**:
```bash
curl -X GET "http://localhost:8000/api/mass-report/recent-searches?limit=50" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**Step 2 - Get search result details**:
```bash
curl -X GET "http://localhost:8000/api/mass-report/search-result/123" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**Step 3 - Create mass report**:
```bash
curl -X POST "http://localhost:8000/api/mass-report/report" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "log_id": 123,
    "platforms": ["instagram", "facebook", "reddit"]
  }'
```

**Benefits**:
- Report across multiple platforms at once
- Saves time for widespread investigations
- Automated report creation
- Comprehensive tracking

### 7. Updating Your Profile

**Via Admin Panel**:
1. Click on your profile/name
2. Click "Edit Profile"
3. Update information:
   - First name, Last name
   - Phone number
   - Gender
   - Date of birth
4. Click "Save Changes"

**Via API**:
```bash
curl -X PATCH "http://localhost:8000/api/officers/1" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{
    "first_name": "Updated",
    "phone_no": "+9876543210"
  }'
```

**Note**: You'll receive a new JWT token after updating.

### 8. Using the Chatbot

The intelligent chatbot can help you with:
- Understanding system features
- Learning how to use APIs
- Troubleshooting issues
- Getting guidance on workflows

**Via Admin Panel**:
1. Click the chatbot icon (usually bottom-right)
2. Type your question
3. Receive AI-powered answer with sources
4. Continue conversation for follow-up questions

**Via API**:
```bash
curl -X POST "http://localhost:8000/api/chatbot/chat" \
  -H "Content-Type: application/json" \
  -d '{
    "message": "How do I search for a user on Instagram?",
    "user_id": "officer_1"
  }'
```

**Example Questions**:
- "How do I perform a multi-platform search?"
- "What do the risk levels mean?"
- "How can I filter my reports?"
- "What is the rate limit for searches?"
- "How do I interpret the AI analysis?"

**Rate Limits**:
- 10 messages per minute
- 100 messages per hour

---

## For Administrators

### 1. Managing Officers

#### Create New Officer

**Via Admin Panel**:
1. Go to "Officers" management page
2. Click "Add New Officer"
3. Fill in details:
   - Email (unique)
   - Password
   - First name, Last name
   - Phone number
   - Gender, Date of birth
   - Branch assignment
4. Click "Create Officer"

**Via API**:
```bash
curl -X POST "http://localhost:8000/api/officers" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "newofficer@example.com",
    "password": "secure_password",
    "first_name": "Jane",
    "last_name": "Smith",
    "phone_no": "+1234567890",
    "gender": "Female",
    "dob": "1995-05-15",
    "branch_id": 1
  }'
```

#### View All Officers

```bash
curl -X GET "http://localhost:8000/api/officers?is_active=true"
```

#### Deactivate Officer

Update officer with `is_active: false` to deactivate without deleting.

### 2. Managing Organizational Structure

#### Cities

```bash
# List cities
curl -X GET "http://localhost:8000/api/cities"

# Create city
curl -X POST "http://localhost:8000/api/cities" \
  -H "Content-Type: application/json" \
  -d '{"city_name": "New York"}'
```

#### Branches

```bash
# List branches
curl -X GET "http://localhost:8000/api/branches"

# Create branch
curl -X POST "http://localhost:8000/api/branches" \
  -H "Content-Type: application/json" \
  -d '{
    "branch_name": "Manhattan Precinct",
    "city_id": 1
  }'
```

#### Search Types

```bash
# List search types
curl -X GET "http://localhost:8000/api/search-types"

# Create search type
curl -X POST "http://localhost:8000/api/search-types" \
  -H "Content-Type: application/json" \
  -d '{"search_type_name": "Background Check"}'
```

### 3. Viewing System-Wide Statistics

**Via Admin Panel**:
1. Go to "Admin Dashboard"
2. View statistics:
   - Total officers
   - Total searches
   - Total reports
   - Activity by branch
   - Activity by city
   - Platform usage trends

**Via API**:
```bash
curl -X GET "http://localhost:8000/api/admin/reports/statistics" \
  -H "Authorization: Bearer ADMIN_TOKEN"
```

### 4. Advanced Filtering

**Filter reports by multiple criteria**:
```bash
curl -X GET "http://localhost:8000/api/admin/reports/detailed?branch_id=1&start_date=2024-01-01&end_date=2024-01-31&social_media=instagram" \
  -H "Authorization: Bearer ADMIN_TOKEN"
```

---

## Best Practices

### 1. Search Types

**Use appropriate search types** for proper categorization:
- **Investigation**: Active criminal investigations
- **Monitoring**: Ongoing surveillance
- **Background Check**: Pre-employment or verification
- **Threat Assessment**: Potential security threats
- **Cybercrime Analysis**: Digital crime investigation

### 2. Documentation

**Always review AI analysis** before taking action:
- AI is a tool, not a replacement for human judgment
- Verify findings with manual review
- Document your reasoning for actions taken
- Cross-reference with other sources

### 3. Report Generation

**Generate reports for important findings**:
- Creates audit trail
- Enables collaboration
- Supports legal proceedings
- Tracks investigation progress

### 4. Privacy & Data Protection

**Follow data protection guidelines**:
- Only search when justified by investigation
- Don't share search results unnecessarily
- Respect privacy laws and regulations
- Secure your JWT tokens
- Log out when finished

### 5. Rate Limits & Performance

**Be mindful of rate limits**:
- Instagram has strict rate limits (avoid excessive searches)
- System implements anti-rate-limit measures
- Space out searches when possible
- Use multi-platform search efficiently

### 6. Verification

**Verify AI findings**:
- AI analysis is probabilistic, not definitive
- Look for corroborating evidence
- Consider context and cultural factors
- Don't rely solely on risk scores

---

## Tips & Tricks

### 1. Efficient Searching

- **Use multi-platform search** for initial reconnaissance
- **Follow up with single-platform** for detailed analysis
- **Use hashtag search** to discover related accounts
- **Check recent searches** before repeating queries

### 2. Dashboard Usage

- **Monitor your activity timeline** to track productivity
- **Review search type breakdown** to ensure proper categorization
- **Check quick stats** for at-a-glance information
- **Use recent searches** for quick re-access

### 3. Chatbot Assistance

- **Ask specific questions** for better answers
- **Use conversation history** for context
- **Request examples** when learning new features
- **Ask for troubleshooting help** when stuck

### 4. Report Management

- **Use advanced filters** to find specific reports quickly
- **Sort by date** to see recent activity
- **Filter by platform** for platform-specific analysis
- **Export data** for external analysis (if implemented)

### 5. Mass Reporting

- **Review search results** before mass reporting
- **Select relevant platforms** only
- **Document reasoning** in reporting results
- **Track success/failure** rates

### 6. Profile Updates

- **Keep your profile current** for accurate attribution
- **Update contact information** for communications
- **Note**: Profile updates generate new JWT tokens

### 7. API Usage

- **Use interactive docs** (http://localhost:8000/docs) for testing
- **Save JWT tokens** securely
- **Check response status codes** for error handling
- **Use pagination** for large result sets

### 8. Performance Optimization

- **Clear old logs** periodically (admin function)
- **Use specific date ranges** in filters
- **Limit result sets** with pagination
- **Cache frequently accessed data** (client-side)

---

## Common Workflows

### Workflow 1: New Investigation

1. Log in to system
2. Perform multi-platform search for subject
3. Review AI risk assessment
4. Perform single-platform deep dive on high-risk platforms
5. Generate report with findings
6. Document in case management system

### Workflow 2: Ongoing Monitoring

1. Set up profile tracking (if available)
2. Perform periodic searches (weekly/monthly)
3. Compare results over time
4. Note changes in behavior or content
5. Update reports with new findings

### Workflow 3: Mass Investigation

1. Compile list of subjects
2. Perform searches for each
3. Review all results
4. Use mass reporting for confirmed cases
5. Generate summary report

### Workflow 4: Getting Help

1. Check this usage guide
2. Review API documentation
3. Ask chatbot for specific questions
4. Check troubleshooting guide
5. Contact system administrator if needed

---

## Keyboard Shortcuts (Admin Panel)

- `Ctrl + /`: Open chatbot
- `Ctrl + S`: Quick search
- `Ctrl + D`: Go to dashboard
- `Ctrl + R`: Go to reports
- `Esc`: Close modals

---

## Mobile Usage

The admin panel is responsive and works on mobile devices:
- Touch-friendly interface
- Optimized layouts for small screens
- Swipe gestures for navigation
- Mobile-optimized charts

---

## Next Steps

1. **Explore the system**: Try different search types
2. **Test the chatbot**: Ask questions about features
3. **Review your dashboard**: Understand your activity
4. **Practice reporting**: Generate sample reports
5. **Read API docs**: Learn programmatic access
6. **Check troubleshooting**: Prepare for common issues
