# Comprehensive Troubleshooting Guide

## Table of Contents

1. [Common Issues](#common-issues)
2. [Search Problems](#search-problems)
3. [AI & Chatbot Issues](#ai--chatbot-issues)
4. [Authentication Problems](#authentication-problems)
5. [Performance Issues](#performance-issues)
6. [Database Issues](#database-issues)
7. [API Errors](#api-errors)
8. [Error Codes Reference](#error-codes-reference)
9. [Getting Help](#getting-help)

---

## Common Issues

### Issue: Server Won't Start

**Symptoms**:
- Error when running `uvicorn app.main:app --reload`
- Import errors
- Module not found errors

**Solutions**:

1. **Check Python version**:
   ```bash
   python --version  # Should be 3.11+
   ```

2. **Reinstall dependencies**:
   ```bash
   pip install -r requirements.txt --upgrade
   ```

3. **Check for syntax errors**:
   ```bash
   python -m py_compile app/main.py
   ```

4. **Verify environment variables**:
   - Check `.env` file exists
   - Ensure `GEMINI_API_KEY` is set
   - Verify `DATABASE_URL` is correct

5. **Check port availability**:
   ```bash
   # Windows
   netstat -ano | findstr :8000
   
   # Linux/Mac
   lsof -i :8000
   ```

### Issue: Database Not Created

**Symptoms**:
- `activity_monitoring.db` file not created
- Table doesn't exist errors
- Database connection errors

**Solutions**:

1. **Check write permissions**:
   - Ensure directory is writable
   - Run with appropriate permissions

2. **Manually create database**:
   ```python
   from app.db.session import Base, engine
   Base.metadata.create_all(bind=engine)
   ```

3. **Check DATABASE_URL**:
   ```env
   DATABASE_URL=sqlite:///./activity_monitoring.db
   ```

4. **Delete and recreate**:
   ```bash
   # Backup first!
   rm activity_monitoring.db
   # Restart server to recreate
   ```

### Issue: Static Files Not Loading

**Symptoms**:
- Admin panel shows 404 errors
- CSS/JS files not loading
- Blank admin page

**Solutions**:

1. **Check static directory exists**:
   ```bash
   ls -la static/
   ```

2. **Verify static files mounting**:
   - Check `app/main.py` has static files mount
   - Ensure path is correct

3. **Check VERCEL environment variable**:
   - Static files disabled on Vercel
   - Use local development for admin panel

4. **Clear browser cache**:
   - Hard refresh: `Ctrl + Shift + R`
   - Clear cache and cookies

---

## Search Problems

### Issue: Instagram Search Not Working

**Symptoms**:
- "Profile not found" for existing profiles
- Rate limit errors
- Connection timeouts
- Login required errors

**Solutions**:

1. **Rate Limit Exceeded**:
   - **Wait 15-30 minutes** before retrying
   - Instagram has strict rate limits
   - System auto-resets session after limits
   
   **Prevention**:
   - Space out searches (wait 30-60 seconds between searches)
   - Don't search same profile repeatedly
   - Use multi-platform search sparingly

2. **Profile is Private**:
   - Private profiles have limited data
   - Only public info available
   - Consider using authenticated session (advanced)

3. **Username Doesn't Exist**:
   - Verify username spelling
   - Check if account was deleted
   - Try searching on Instagram directly

4. **Connection Issues**:
   ```bash
   # Test Instagram connectivity
   curl -I https://www.instagram.com
   ```

5. **User Agent Blocked**:
   - System rotates user agents automatically
   - If persistent, update `USER_AGENTS` list in `search.py`

6. **Session Reset Needed**:
   - System auto-resets after 3 requests
   - Manual reset: Restart server
   - Check logs for session reset messages

**Advanced Debugging**:
```python
# Enable debug logging in search.py
import logging
logging.basicConfig(level=logging.DEBUG)
```

### Issue: Multi-Platform Search Slow

**Symptoms**:
- Takes longer than 30 seconds
- Timeout errors
- Incomplete results

**Solutions**:

1. **Expected Behavior**:
   - Multi-platform searches take 20-40 seconds
   - Each platform searched sequentially
   - Instagram is slowest (rate limits)

2. **Reduce Platforms**:
   - Search fewer platforms
   - Use single-platform for urgent needs

3. **Check Internet Speed**:
   ```bash
   # Test connection
   ping google.com
   ```

4. **Increase Timeout** (if needed):
   - Modify timeout in `search.py`
   - Not recommended for production

### Issue: Hashtag Search Returns No Results

**Symptoms**:
- Empty results for valid hashtags
- "No posts found" error

**Solutions**:

1. **Verify Hashtag Format**:
   - Include `#` symbol: `#cybercrime`
   - No spaces in hashtag
   - Check spelling

2. **Hashtag May Be Banned**:
   - Instagram bans certain hashtags
   - Try alternative hashtags

3. **Rate Limits**:
   - Same as profile search
   - Wait and retry

4. **Limit Too Low**:
   - Increase `limit` parameter
   - Default is 20, try 50

### Issue: Search Results Not Saved

**Symptoms**:
- No log entry created
- JSON file not saved
- Can't find search in history

**Solutions**:

1. **Check `search_results` Directory**:
   ```bash
   ls -la search_results/
   ```

2. **Verify Write Permissions**:
   ```bash
   chmod 755 search_results/
   ```

3. **Check Database Connection**:
   - Ensure database is accessible
   - Check for database errors in logs

4. **Officer ID Invalid**:
   - Verify officer_id exists
   - Check officer is active

---

## AI & Chatbot Issues

### Issue: AI Analysis Not Available

**Symptoms**:
- "AI analysis unavailable" message
- No risk assessment in results
- Empty `cybercrime_analysis` field

**Solutions**:

1. **Check GEMINI_API_KEY**:
   ```bash
   # In .env file
   GEMINI_API_KEY=your_actual_api_key_here
   ```

2. **Verify API Key is Valid**:
   - Test key at https://aistudio.google.com
   - Check for typos
   - Ensure key has proper permissions

3. **Check API Quota**:
   - Gemini has free tier limits
   - Monitor usage at Google AI Studio
   - Upgrade plan if needed

4. **Network Issues**:
   ```bash
   # Test Gemini API connectivity
   curl -H "x-goog-api-key: YOUR_KEY" \
     "https://generativelanguage.googleapis.com/v1beta/models"
   ```

5. **Review Error Logs**:
   ```bash
   # Check for Gemini errors
   grep "Gemini" logs.txt
   ```

**Temporary Workaround**:
- Searches still work without AI
- Manual analysis required
- Fix API key for full functionality

### Issue: Chatbot Not Responding

**Symptoms**:
- Chatbot returns errors
- "Service unavailable" message
- Timeout on chat requests

**Solutions**:

1. **Check Chatbot Initialization**:
   ```bash
   curl http://localhost:8000/api/chatbot/chat/health
   ```
   
   **Expected Response**:
   ```json
   {
     "status": "healthy",
     "rag_initialized": true,
     "service": "chatbot"
   }
   ```

2. **RAG Not Initialized**:
   - Check `CHATBOT_ENABLED=true` in `.env`
   - Verify `GEMINI_API_KEY` is set
   - Check `system_docs/` directory exists
   - Restart server

3. **Vector Store Issues**:
   ```bash
   # Check ChromaDB directory
   ls -la chroma_db/
   ```
   
   **Fix**:
   ```bash
   # Delete and reinitialize
   rm -rf chroma_db/
   # Restart server
   ```

4. **Rate Limit Exceeded**:
   - **Error**: "Too many requests"
   - **Limit**: 10/minute, 100/hour
   - **Solution**: Wait and retry
   
   **Check Rate Limit**:
   ```bash
   # In logs
   grep "RATE_LIMIT" logs.txt
   ```

5. **Message Validation Failed**:
   - **Too short**: Minimum 3 characters
   - **Too long**: Maximum 2000 characters
   - **Blocked content**: Remove inappropriate words

### Issue: Chatbot Gives Incorrect Answers

**Symptoms**:
- Answers don't match documentation
- Outdated information
- Generic responses

**Solutions**:

1. **Update Documentation**:
   - Ensure `system_docs/` is current
   - Add new features to docs
   - Restart server to reload

2. **Reinitialize RAG**:
   ```bash
   # Delete vector store
   rm -rf chroma_db/
   # Restart server
   python main.py
   ```

3. **Improve Question Specificity**:
   - Ask specific questions
   - Provide context
   - Use technical terms

4. **Check Sources**:
   - Review `sources` in response
   - Verify source documents are correct

---

## Authentication Problems

### Issue: Login Failed

**Symptoms**:
- "Invalid credentials" error
- Can't log in with correct password
- 401 Unauthorized error

**Solutions**:

1. **Verify Credentials**:
   - Check email spelling
   - Verify password (case-sensitive)
   - Ensure officer account exists

2. **Check Officer Status**:
   ```bash
   curl http://localhost:8000/api/officers
   ```
   - Verify `is_active: true`
   - Check officer exists in database

3. **Password Hash Issue**:
   - Passwords are hashed with bcrypt
   - Can't retrieve original password
   - Reset password if needed:
   ```python
   from app.core.security import get_password_hash
   new_hash = get_password_hash("new_password")
   # Update in database
   ```

4. **Database Connection**:
   - Ensure database is accessible
   - Check for database errors

### Issue: JWT Token Invalid

**Symptoms**:
- "Invalid token" error
- 401 Unauthorized on API calls
- Token expired message

**Solutions**:

1. **Token Expired**:
   - Tokens expire after 7 days
   - **Solution**: Log in again to get new token

2. **Token Format Wrong**:
   - **Correct**: `Authorization: Bearer <token>`
   - **Wrong**: `Authorization: <token>`
   - Include "Bearer " prefix

3. **SECRET_KEY Changed**:
   - Changing `SECRET_KEY` invalidates all tokens
   - All users must log in again
   - Don't change in production

4. **Token Corrupted**:
   - Copy token carefully
   - No extra spaces or newlines
   - Use proper encoding

**Test Token**:
```bash
curl -H "Authorization: Bearer YOUR_TOKEN" \
  http://localhost:8000/api/officers/1
```

### Issue: Session Lost

**Symptoms**:
- Logged out unexpectedly
- Session not persisting
- Must log in repeatedly

**Solutions**:

1. **Browser Cookies**:
   - Enable cookies
   - Check cookie storage
   - Don't use incognito mode

2. **Token Storage**:
   - Store token in localStorage
   - Implement token refresh
   - Check browser console for errors

3. **Server Restart**:
   - In-memory sessions lost on restart
   - Use persistent storage for production

---

## Performance Issues

### Issue: Slow API Response

**Symptoms**:
- Requests take >5 seconds
- Timeout errors
- Sluggish admin panel

**Solutions**:

1. **Database Size**:
   ```bash
   # Check database size
   ls -lh activity_monitoring.db
   ```
   
   **If >100MB**:
   - Archive old logs
   - Implement data retention policy
   - Optimize queries

2. **Too Many Logs**:
   ```sql
   -- Count logs
   SELECT COUNT(*) FROM result_logs;
   SELECT COUNT(*) FROM report_logs;
   ```
   
   **Clean Up**:
   ```sql
   -- Delete logs older than 90 days
   DELETE FROM result_logs 
   WHERE searched_at < date('now', '-90 days');
   ```

3. **Optimize Queries**:
   - Use pagination (limit results)
   - Add indexes to database
   - Use filters to reduce data

4. **Server Resources**:
   ```bash
   # Check CPU/Memory
   top
   # or
   htop
   ```
   
   **If high usage**:
   - Increase server resources
   - Optimize code
   - Use caching

5. **Network Latency**:
   - Check internet speed
   - Use CDN for static files
   - Optimize API calls

### Issue: High Memory Usage

**Symptoms**:
- Server crashes
- Out of memory errors
- Slow performance

**Solutions**:

1. **Large Search Results**:
   - Limit posts fetched (default: 20)
   - Reduce concurrent searches
   - Implement result pagination

2. **Vector Store Size**:
   ```bash
   du -sh chroma_db/
   ```
   
   **If large**:
   - Limit document size
   - Prune old embeddings
   - Use external vector DB

3. **Memory Leaks**:
   - Restart server periodically
   - Monitor memory over time
   - Update dependencies

4. **Increase Server Memory**:
   - Allocate more RAM
   - Use swap space
   - Optimize Python memory

---

## Database Issues

### Issue: Database Locked

**Symptoms**:
- "Database is locked" error
- Write operations fail
- Concurrent access issues

**Solutions**:

1. **SQLite Limitation**:
   - SQLite doesn't handle concurrent writes well
   - **Solution**: Use PostgreSQL for production
   
   ```env
   DATABASE_URL=postgresql://user:pass@localhost/dbname
   ```

2. **Close Connections**:
   - Ensure sessions are closed
   - Use context managers
   - Check for hanging connections

3. **Increase Timeout**:
   ```python
   # In db/session.py
   engine = create_engine(
       DATABASE_URL,
       connect_args={"timeout": 30}
   )
   ```

### Issue: Migration Needed

**Symptoms**:
- Column doesn't exist errors
- Table structure mismatch
- Schema errors

**Solutions**:

1. **Use Alembic** (recommended):
   ```bash
   # Install Alembic
   pip install alembic
   
   # Initialize
   alembic init alembic
   
   # Create migration
   alembic revision --autogenerate -m "description"
   
   # Apply migration
   alembic upgrade head
   ```

2. **Manual Schema Update**:
   ```python
   # Add column manually
   from sqlalchemy import text
   with engine.connect() as conn:
       conn.execute(text("ALTER TABLE officers ADD COLUMN new_field VARCHAR"))
   ```

3. **Recreate Database** (development only):
   ```bash
   # CAUTION: Deletes all data!
   rm activity_monitoring.db
   # Restart server
   ```

---

## API Errors

### Error Codes Reference

#### 400 Bad Request

**Cause**: Invalid input data

**Common Issues**:
- Missing required fields
- Invalid data types
- Validation errors

**Example**:
```json
{
  "detail": [
    {
      "loc": ["body", "email"],
      "msg": "field required",
      "type": "value_error.missing"
    }
  ]
}
```

**Solution**:
- Check request body format
- Verify all required fields
- Match expected data types

#### 401 Unauthorized

**Cause**: Authentication required or failed

**Solutions**:
- Include JWT token in header
- Verify token is valid
- Log in to get new token

#### 404 Not Found

**Cause**: Resource doesn't exist

**Common Issues**:
- Wrong ID in URL
- Resource was deleted
- Incorrect endpoint

**Solution**:
- Verify resource ID
- Check endpoint spelling
- Ensure resource exists

#### 422 Unprocessable Entity

**Cause**: Validation error

**Example**:
```json
{
  "detail": [
    {
      "loc": ["body", "officer_id"],
      "msg": "value is not a valid integer",
      "type": "type_error.integer"
    }
  ]
}
```

**Solution**:
- Fix data type
- Match schema requirements
- Check Pydantic model

#### 429 Too Many Requests

**Cause**: Rate limit exceeded

**Limits**:
- Chatbot: 10/min, 100/hour
- Instagram: Platform limits

**Solution**:
- Wait before retrying
- Implement exponential backoff
- Reduce request frequency

#### 500 Internal Server Error

**Cause**: Server-side error

**Solutions**:
1. **Check Server Logs**:
   ```bash
   # View logs
   tail -f logs.txt
   ```

2. **Common Causes**:
   - Database connection failed
   - API key invalid
   - Unhandled exception

3. **Debug Mode**:
   ```env
   DEBUG=true
   ```

4. **Report to Admin**:
   - Include error message
   - Provide request details
   - Share logs if possible

---

## Getting Help

### 1. Check System Logs

**View Logs**:
```bash
# If using main.py
python main.py 2>&1 | tee logs.txt

# If using uvicorn
uvicorn app.main:app --reload --log-level debug
```

**Log Locations**:
- Console output
- `logs.txt` (if configured)
- System logs

### 2. Use Interactive Documentation

**Swagger UI**: http://localhost:8000/docs
- Test endpoints
- View request/response schemas
- See validation requirements

**ReDoc**: http://localhost:8000/redoc
- Detailed API documentation
- Examples and descriptions

### 3. Ask the Chatbot

```bash
curl -X POST "http://localhost:8000/api/chatbot/chat" \
  -H "Content-Type: application/json" \
  -d '{
    "message": "Why am I getting a 401 error?",
    "user_id": "troubleshoot"
  }'
```

### 4. Check GitHub Issues

- Search existing issues
- Report new bugs
- Request features

### 5. Contact System Administrator

**Provide**:
- Error message (full text)
- Steps to reproduce
- System logs
- Request/response details
- Environment info (OS, Python version)

### 6. Community Resources

- FastAPI documentation
- SQLAlchemy docs
- Google Gemini API docs
- Instaloader documentation

---

## Diagnostic Commands

### System Health Check

```bash
# API health
curl http://localhost:8000/api/health

# Chatbot health
curl http://localhost:8000/api/chatbot/chat/health

# Database check
sqlite3 activity_monitoring.db "SELECT COUNT(*) FROM officers;"
```

### Environment Check

```bash
# Python version
python --version

# Installed packages
pip list

# Environment variables
printenv | grep -E "GEMINI|DATABASE|SECRET"
```

### Network Check

```bash
# Test Instagram
curl -I https://www.instagram.com

# Test Gemini API
curl -H "x-goog-api-key: YOUR_KEY" \
  "https://generativelanguage.googleapis.com/v1beta/models"
```

### Database Check

```bash
# Open database
sqlite3 activity_monitoring.db

# List tables
.tables

# Check officers
SELECT COUNT(*) FROM officers;

# Check recent searches
SELECT COUNT(*) FROM result_logs WHERE searched_at > date('now', '-7 days');
```

---

## Prevention Tips

1. **Regular Backups**:
   ```bash
   # Backup database
   cp activity_monitoring.db backups/backup_$(date +%Y%m%d).db
   ```

2. **Monitor Logs**:
   - Review logs daily
   - Set up log rotation
   - Alert on errors

3. **Update Dependencies**:
   ```bash
   pip install -r requirements.txt --upgrade
   ```

4. **Test Before Deploying**:
   - Run tests
   - Check all features
   - Verify integrations

5. **Document Changes**:
   - Keep changelog
   - Update documentation
   - Note configuration changes

6. **Monitor Resources**:
   - Check disk space
   - Monitor memory usage
   - Track API quotas

---

## Emergency Procedures

### Server Crash

1. Check logs for errors
2. Restart server
3. Verify database integrity
4. Test basic functionality
5. Notify users if needed

### Data Loss

1. Stop server immediately
2. Don't write to database
3. Restore from backup
4. Verify data integrity
5. Document incident

### Security Breach

1. Disable affected accounts
2. Rotate SECRET_KEY
3. Force password resets
4. Review access logs
5. Patch vulnerability
6. Notify affected users

---

## Quick Reference

| Issue | Quick Fix |
|-------|-----------|
| Server won't start | Check dependencies, Python version |
| Database locked | Use PostgreSQL, increase timeout |
| Rate limit | Wait 15-30 minutes |
| AI not working | Check GEMINI_API_KEY |
| Chatbot down | Restart server, check health endpoint |
| Login failed | Verify credentials, check is_active |
| Token invalid | Log in again |
| Slow performance | Clear old logs, optimize queries |
| 500 error | Check logs, debug mode |
| Search fails | Check rate limits, verify username |
