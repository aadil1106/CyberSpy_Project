# User Guide - Activity Monitoring System

## Welcome to the Activity Monitoring System

This guide will help you use the Activity Monitoring System effectively. All instructions are for using the **web interface** - no technical knowledge required!

---

## Getting Started

### Logging In

1. Open your web browser and go to the system URL (provided by your administrator)
2. You'll see the login page
3. Enter your **email address** and **password**
4. Click the **"Login"** button
5. You're now logged in and will see your dashboard!

**Forgot your password?** Contact your system administrator to reset it.

---

## Dashboard Overview

After logging in, you'll see your **Dashboard** with:

- **Your Profile**: Your name, email, and account details
- **Activity Summary**: 
  - Total searches you've performed
  - Reports you've generated
  - Your login history
- **Recent Searches**: Quick access to your last 10 searches
- **Activity Chart**: Visual graph showing your daily search activity
- **Quick Stats**: Today's searches and reports at a glance

### What You Can Do From Dashboard

- Click on any **recent search** to view it again
- View your **performance metrics** (average searches per day)
- See which **platform you search most** (Instagram, Facebook, etc.)
- Check your **last login time**

---

## How to Search for Profiles

### Single Platform Search

**Use this when**: You want detailed information about a person on one specific platform (like Instagram).

**Steps**:

1. Click **"Search"** in the main menu
2. Select **"Single Platform"** option
3. Choose the platform from dropdown:
   - Instagram
   - Facebook
   - Reddit
   - Telegram
4. Enter the **username** you want to search
5. Select **search type** (Investigation, Monitoring, etc.)
6. Click **"Search"** button
7. Wait 10-30 seconds for results

**What You'll Get**:
- ✅ Profile picture and bio
- ✅ Follower/following count
- ✅ Number of posts
- ✅ Recent posts with likes and comments
- ✅ **AI Risk Assessment** (Low, Medium, High, Critical)
- ✅ **AI Summary** of the profile
- ✅ Engagement rate and statistics

### Multi-Platform Search

**Use this when**: You want to find a person across all social media platforms at once.

**Steps**:

1. Click **"Search"** in the main menu
2. Select **"Multi-Platform"** option
3. Enter the **username** to search
4. Select which platforms to search (or check "All")
5. Select **search type**
6. Click **"Search All Platforms"** button
7. Wait 30-60 seconds for results from all platforms

**What You'll Get**:
- ✅ Results from each platform where the username exists
- ✅ Profile information from all platforms
- ✅ AI analysis for each platform
- ✅ Consolidated view of the person's online presence

### Hashtag/Keyword Search

**Use this when**: You want to find posts or profiles related to a specific topic or hashtag.

**Steps**:

1. Click **"Search"** in the main menu
2. Select **"Hashtag Search"** option
3. Enter the hashtag (with # symbol) or keyword
   - Example: `#cybercrime` or `scam`
4. Click **"Search"** button

**What You'll Get**:
- ✅ Top posts using that hashtag
- ✅ Profiles that frequently use the hashtag
- ✅ Engagement statistics
- ✅ Post timestamps and trends

---

## Understanding AI Risk Assessment

The system uses **Artificial Intelligence** to analyze profiles and detect potential cybercrime indicators.

### Risk Levels Explained

**🟢 Low Risk (0-25)**
- Normal personal or business account
- Appropriate content
- No suspicious patterns
- **Action**: No immediate concerns

**🟡 Medium Risk (26-50)**
- Some questionable content detected
- Unusual posting patterns
- Minor red flags
- **Action**: Monitor the account, review manually

**🟠 High Risk (51-75)**
- Multiple red flags detected
- Suspicious behavior patterns
- Potential illegal activity indicators
- **Action**: Investigate further, consider reporting

**🔴 Critical Risk (76-100)**
- Clear cybercrime indicators found
- Illegal content or activities
- Immediate threat detected
- **Action**: Take immediate action, generate report

### What the AI Looks For

The AI analyzes profiles for:

- **Scams & Fraud**: Fake giveaways, phishing attempts, get-rich-quick schemes
- **Harassment**: Threatening language, bullying, stalking behavior
- **Illegal Activities**: Drug references, weapon sales, illegal services
- **Identity Theft**: Impersonation, fake accounts, stolen photos
- **Misinformation**: Fake news, conspiracy theories, false information
- **Suspicious Patterns**: Bot-like behavior, unusual posting times, coordinated activity

### AI Summary

Each profile gets a **plain-English summary** that includes:
- Overall assessment of the account
- Main themes and topics discussed
- Behavioral patterns observed
- Engagement analysis
- **Recommendations** for what to do next

**Important**: Always verify AI findings with your own review. AI is a helpful tool, but human judgment is essential!

---

## Generating Reports

### When to Generate a Report

Generate a report when:
- You find suspicious or illegal activity
- You need to document your investigation
- You want to report an account to authorities
- You need to share findings with your team

### How to Generate a Report

**From Search Results**:

1. After performing a search, review the results
2. Look at the AI risk assessment and summary
3. Click **"Generate Report"** or **"Report Profile"** button
4. A form will appear - fill in:
   - **Platform**: Already filled (Instagram, Facebook, etc.)
   - **Username**: Already filled
   - **Reporting Notes**: Add your observations and reasoning
   - **Action Taken**: What you did (reported to platform, forwarded to authorities, etc.)
5. Click **"Submit Report"** button
6. Your report is saved!

### Viewing Your Reports

1. Click **"Reports"** in the main menu
2. You'll see a list of all your reports
3. Use filters to find specific reports:
   - **Platform**: Filter by Instagram, Facebook, etc.
   - **Date Range**: Select start and end dates
   - **Username**: Search by username
4. Click on any report to view full details

### Report Details Include

- Date and time of report
- Platform and username
- Your notes and observations
- AI risk assessment from the search
- Profile information captured
- Your officer ID (for audit trail)

---

## Mass Reporting

**Use this when**: You found the same person on multiple platforms and want to report them everywhere.

### How to Use Mass Reporting

1. Click **"Mass Report"** in the main menu
2. You'll see your **recent searches**
3. Find the multi-platform search you want to report
4. Click **"View Results"** to review the profiles found
5. Select which platforms you want to report:
   - ☑️ Instagram
   - ☑️ Facebook
   - ☑️ Reddit
   - ☑️ Telegram
6. Click **"Mass Report"** button
7. The system will create reports for all selected platforms automatically
8. You'll see a summary:
   - ✅ Successfully reported: 3 platforms
   - ❌ Failed: 0 platforms

**Benefits**:
- Save time - report to multiple platforms at once
- Ensure comprehensive action
- Automatic documentation
- Track all reports in one place

---

## Using the AI Chatbot Assistant

The system has an **intelligent chatbot** that can help you!

### How to Access the Chatbot

- Look for the **chat icon** (usually in the bottom-right corner)
- Click it to open the chat window
- Type your question and press Enter
- The AI will respond with helpful information

### What You Can Ask

**System Features**:
- "How do I search for a user on Instagram?"
- "What are the different risk levels?"
- "How do I generate a report?"
- "What is mass reporting?"

**Troubleshooting**:
- "Why is my search not working?"
- "What does 'rate limit exceeded' mean?"
- "How do I filter my reports?"

**General Help**:
- "What can this system do?"
- "How do I view my dashboard?"
- "What platforms can I search?"

### Chatbot Tips

- ✅ Ask specific questions for better answers
- ✅ You can ask follow-up questions
- ✅ The chatbot remembers your conversation
- ✅ It provides sources for its answers
- ⚠️ Limit: 10 questions per minute, 100 per hour

---

## Profile Management

### Viewing Your Profile

1. Click on your **name** or **profile icon** (top-right)
2. Select **"My Profile"**
3. You'll see:
   - Your name and email
   - Phone number
   - Gender and date of birth
   - Branch assignment
   - Account creation date
   - Last profile update

### Editing Your Profile

1. Go to your profile page
2. Click **"Edit Profile"** button
3. Update any of these fields:
   - First name
   - Last name
   - Phone number
   - Gender
   - Date of birth
4. Click **"Save Changes"**
5. Your profile is updated!

**Note**: You cannot change your email address. Contact your administrator if needed.

---

## Tips for Effective Searching

### Instagram Search Tips

- **Be patient**: Instagram searches take 15-30 seconds
- **Exact usernames**: Use the exact username (case doesn't matter)
- **Private accounts**: You'll get limited information for private profiles
- **Rate limits**: Don't search too frequently (wait 30-60 seconds between searches)
- **Best time**: Search during off-peak hours for faster results

### Facebook Search Tips

- **Username format**: Use the username from the profile URL
- **Public profiles**: Work best for detailed information
- **Name searches**: Try both username and full name

### General Search Tips

- ✅ **Use search types correctly**: Choose the right category for your investigation
- ✅ **Review AI analysis**: Don't skip the AI summary - it highlights important findings
- ✅ **Check recent posts**: Look at posting patterns and content themes
- ✅ **Note engagement**: High engagement with suspicious content is a red flag
- ✅ **Cross-reference**: Use multi-platform search to verify identity
- ✅ **Document everything**: Generate reports for important findings

---

## Common Questions

### "Why is my search taking so long?"

- **Instagram searches** take 15-30 seconds (platform rate limits)
- **Multi-platform searches** take 30-60 seconds (searching multiple platforms)
- **Network issues** can slow things down
- **High traffic** times may be slower

**Solution**: Be patient, don't refresh the page!

### "I got 'Rate Limit Exceeded' error"

This means you've searched too many times too quickly.

**Solution**: 
- Wait 15-30 minutes before searching again
- Space out your searches (wait 30-60 seconds between each)
- Use multi-platform search instead of multiple single searches

### "Profile not found"

Possible reasons:
- ❌ Username is misspelled
- ❌ Account was deleted or suspended
- ❌ Account is private with strict settings
- ❌ Username changed recently

**Solution**: 
- Double-check the username spelling
- Try searching on the platform directly
- Try alternative usernames

### "AI analysis not available"

This means the AI couldn't analyze the profile.

Possible reasons:
- Not enough data (very new account)
- Private account with no visible content
- Technical issue with AI service

**Solution**: 
- You can still see profile information
- Review manually without AI assistance
- Try searching again later

### "My reports aren't showing"

**Solution**:
- Check your filters (date range, platform)
- Make sure you're logged in with the correct account
- Click "Clear Filters" to see all reports
- Contact administrator if problem persists

---

## Best Practices

### For Investigations

1. **Start broad**: Use multi-platform search first
2. **Go deep**: Follow up with single-platform search for details
3. **Document everything**: Generate reports for all findings
4. **Verify AI findings**: Always review manually
5. **Cross-reference**: Check multiple sources
6. **Follow procedures**: Use appropriate search types

### For Privacy & Ethics

1. **Only search when justified**: Have a legitimate reason
2. **Respect privacy**: Don't share results unnecessarily
3. **Follow regulations**: Comply with data protection laws
4. **Secure your account**: Log out when finished
5. **Don't abuse**: Use the system responsibly

### For Efficiency

1. **Use dashboard**: Check recent searches before repeating
2. **Use filters**: Find reports quickly with filters
3. **Use chatbot**: Get quick answers to questions
4. **Batch work**: Use mass reporting for efficiency
5. **Review stats**: Monitor your activity timeline

---

## Getting Help

### If You Need Assistance

1. **Try the chatbot first**: Ask your question in the chat
2. **Check this guide**: Search for your issue
3. **Contact your administrator**: For account issues
4. **Report bugs**: If something isn't working correctly

### Contact Information

- **System Administrator**: [Contact details provided by your organization]
- **Technical Support**: [Contact details provided by your organization]
- **Emergency Contact**: [Contact details provided by your organization]

---

## Quick Reference Card

### Main Features

| Feature | What It Does | Where to Find It |
|---------|--------------|------------------|
| Dashboard | View your activity and stats | Home page after login |
| Single Search | Search one platform in detail | Search → Single Platform |
| Multi Search | Search all platforms at once | Search → Multi-Platform |
| Hashtag Search | Find posts by topic | Search → Hashtag Search |
| Reports | View and create reports | Reports menu |
| Mass Report | Report to multiple platforms | Mass Report menu |
| Chatbot | Get help and answers | Chat icon (bottom-right) |
| Profile | View/edit your info | Your name (top-right) |

### Risk Levels

| Level | Score | Color | Action |
|-------|-------|-------|--------|
| Low | 0-25 | 🟢 Green | No concerns |
| Medium | 26-50 | 🟡 Yellow | Monitor |
| High | 51-75 | 🟠 Orange | Investigate |
| Critical | 76-100 | 🔴 Red | Take action |

### Search Times

| Search Type | Expected Time |
|-------------|---------------|
| Instagram Single | 15-30 seconds |
| Other Platforms | 10-20 seconds |
| Multi-Platform | 30-60 seconds |
| Hashtag Search | 20-40 seconds |

---

## Remember

- ✅ The system is here to **help you**, not replace your judgment
- ✅ **AI is a tool** - always verify findings manually
- ✅ **Document your work** - generate reports for important cases
- ✅ **Use responsibly** - respect privacy and follow regulations
- ✅ **Ask for help** - use the chatbot or contact your administrator

**Happy investigating! 🔍**
