
// Search functionality
// Search functionality
if (typeof window.currentSearchType === 'undefined') {
    window.currentSearchType = null;
}

function initSearchHandlers() {
    console.log('🔍 Initializing search handlers');
    
    // Initialize form handlers for all three types
    const form1 = document.getElementById('search-form-type-1');
    const form2 = document.getElementById('search-form-type-2');
    const form3 = document.getElementById('search-form-type-3');
    
    // Remove previous listeners to prevent duplicates if re-initialized
    if (form1) {
        form1.removeEventListener('submit', handleSearchType1);
        form1.addEventListener('submit', handleSearchType1);
    }
    if (form2) {
        form2.removeEventListener('submit', handleSearchType2);
        form2.addEventListener('submit', handleSearchType2);
    }
    if (form3) {
        form3.removeEventListener('submit', handleSearchType3);
        form3.addEventListener('submit', handleSearchType3);
    }
}

function selectSearchType(type) {
    console.log('📋 Search type selected:', type);
    currentSearchType = type;
    
    // Show form container
    const formContainer = document.getElementById('search-form-container');
    formContainer.style.display = 'block';
    
    // Hide all forms
    document.getElementById('search-form-type-1').style.display = 'none';
    document.getElementById('search-form-type-2').style.display = 'none';
    document.getElementById('search-form-type-3').style.display = 'none';
    
    // Show selected form
    const selectedForm = document.getElementById(`search-form-type-${type}`);
    selectedForm.style.display = 'block';
    
    // Update title
    const titles = {
        1: 'Multi-Platform Search',
        2: 'Focused Platform Search',
        3: 'Continuous Monitoring Setup'
    };
    document.getElementById('search-form-title').textContent = titles[type];
    
    // Hide results
    document.getElementById('search-results-container').style.display = 'none';
    
    // Scroll to form
    formContainer.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function resetSearchForm() {
    currentSearchType = null;
    document.getElementById('search-form-container').style.display = 'none';
    document.getElementById('search-results-container').style.display = 'none';
    
    // Reset all forms
    document.getElementById('search-form-type-1').reset();
    document.getElementById('search-form-type-2').reset();
    document.getElementById('search-form-type-3').reset();
    
    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ========================================
// TYPE 1: MULTI-PLATFORM SEARCH
// ========================================
async function handleSearchType1(e) {
    e.preventDefault();
    console.log('🔍 Handling Multi-Platform search');
    
    const keyword = document.getElementById('keyword-type1').value.trim();
    const checkboxes = document.querySelectorAll('input[name="platform-type1"]:checked');
    const platforms = Array.from(checkboxes).map(cb => cb.value);
    
    if (platforms.length === 0) {
        showToast('Please select at least one platform', 'error');
        return;
    }
    
    console.log('Search params:', { keyword, platforms });
    
    // Show loading
    showSearchResults('loading', { keyword, platforms });
    
    try {
        const response = await fetch('/api/search/multi-platform', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            },
            body: JSON.stringify({
                keyword: keyword,
                platforms: platforms
            })
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const results = await response.json();
        console.log('📦 Multi-Platform API Results:', results);
        
        // Log Instagram data specifically
        const instagramResult = results.find(r => r.platform === 'instagram');
        if (instagramResult) {
            console.log('📷 Instagram Result Details:', {
                found: instagramResult.found,
                has_instagram_data: !!instagramResult.instagram_data,
                instagram_data: instagramResult.instagram_data
            });
            
            if (instagramResult.instagram_data) {
                console.log('🤖 Instagram AI Analysis Check:', {
                    has_cybercrime_analysis: !!instagramResult.instagram_data.cybercrime_analysis,
                    has_ai_summary: !!instagramResult.instagram_data.ai_summary,
                    cybercrime_analysis: instagramResult.instagram_data.cybercrime_analysis,
                    ai_summary: instagramResult.instagram_data.ai_summary
                });
            }
        }
        
        showSearchResults('type1', { keyword, platforms, results });
        showToast('Search completed successfully!', 'success');
    } catch (error) {
        console.error('Search error:', error);
        showToast('Search failed: ' + error.message, 'error');
        showSearchResults('error', { message: error.message });
    }
}

// ========================================
// TYPE 2: SINGLE PLATFORM SEARCH
// ========================================
async function handleSearchType2(e) {
    e.preventDefault();
    console.log('🔍 Handling Single Platform search');
    
    const username = document.getElementById('username-type2').value.trim();
    const platform = document.querySelector('input[name="platform-type2"]:checked')?.value;
    
    if (!platform) {
        showToast('Please select a platform', 'error');
        return;
    }
    
    console.log('Search params:', { username, platform });
    
    // Show loading
    showSearchResults('loading', { username, platform });
    
    try {
        const response = await fetch('/api/search/single-platform', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            },
            body: JSON.stringify({
                username: username,
                platform: platform
            })
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.detail || `HTTP error! status: ${response.status}`);
        }
        
        const result = await response.json();
        console.log('📦 Single Platform API Result:', result);
        console.log('📊 Result Structure:', {
            has_profile: !!result.profile,
            has_recent_posts: !!result.recent_posts,
            has_cybercrime_analysis: !!result.cybercrime_analysis,
            has_ai_summary: !!result.ai_summary,
            profile: result.profile,
            posts_count: result.recent_posts?.length,
            cybercrime_analysis: result.cybercrime_analysis,
            ai_summary: result.ai_summary
        });
        
        showSearchResults('type2', { username, platform, result });
        showToast('Search completed successfully!', 'success');
    } catch (error) {
        console.error('Search error:', error);
        showToast('Search failed: ' + error.message, 'error');
        showSearchResults('error', { message: error.message });
    }
}

// ========================================
// TYPE 3: CONTINUOUS TRACKING
// ========================================
async function handleSearchType3(e) {
    e.preventDefault();
    console.log('🔍 Handling Continuous Tracking setup');
    
    const username = document.getElementById('username-type3').value.trim();
    const platform = document.querySelector('input[name="platform-type3"]:checked')?.value;
    const durationValue = document.getElementById('duration-value').value;
    const durationUnit = document.getElementById('duration-unit').value;
    const frequency = document.getElementById('tracking-frequency').value;
    
    if (!platform) {
        showToast('Please select a platform', 'error');
        return;
    }
    
    if (!durationUnit) {
        showToast('Please select duration unit', 'error');
        return;
    }
    
    console.log('Tracking params:', { username, platform, durationValue, durationUnit, frequency });
    
    // Show loading
    showSearchResults('loading', { username, platform });
    
    try {
        const response = await fetch('/api/search/start-tracking', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            },
            body: JSON.stringify({
                username: username,
                platform: platform,
                duration_value: parseInt(durationValue),
                duration_unit: durationUnit,
                frequency: frequency
            })
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const trackingData = await response.json();
        console.log('Tracking started:', trackingData);
        
        showSearchResults('type3', trackingData);
        showToast('Tracking started successfully!', 'success');
    } catch (error) {
        console.error('Tracking setup error:', error);
        showToast('Failed to start tracking: ' + error.message, 'error');
        showSearchResults('error', { message: error.message });
    }
}

function calculateEndTime(value, unit) {
    const now = new Date();
    const multipliers = {
        hours: 60 * 60 * 1000,
        days: 24 * 60 * 60 * 1000,
        weeks: 7 * 24 * 60 * 60 * 1000,
        months: 30 * 24 * 60 * 60 * 1000
    };
    
    const endTime = new Date(now.getTime() + (value * multipliers[unit]));
    return endTime.toISOString();
}

// ========================================
// RESULTS DISPLAY FUNCTIONS
// ========================================
function showSearchResults(type, data) {
    const container = document.getElementById('search-results-container');
    const content = document.getElementById('search-results-content');
    const subtitle = document.getElementById('results-subtitle');
    
    container.style.display = 'block';
    
    if (type === 'loading') {
        content.innerHTML = `
            <div style="text-align: center; padding: 48px;">
                <div class="loading-spinner"></div>
                <p style="margin-top: 16px; color: var(--text-secondary); font-size: 1.1rem;">
                    Searching across platforms and analyzing with AI...
                </p>
            </div>
        `;
        subtitle.textContent = 'Please wait...';
        container.scrollIntoView({ behavior: 'smooth', block: 'start' });
        return;
    }
    
    if (type === 'error') {
        content.innerHTML = `
            <div class="error-message">
                <div class="error-icon">⚠️</div>
                <h3>Search Failed</h3>
                <p>${data.message}</p>
            </div>
        `;
        subtitle.textContent = 'An error occurred';
        container.scrollIntoView({ behavior: 'smooth', block: 'start' });
        return;
    }
    
    if (type === 'type1') {
        subtitle.textContent = `Results for "${data.keyword}" across ${data.platforms.length} platform(s)`;
        content.innerHTML = renderMultiPlatformResults(data);
    } else if (type === 'type2') {
        subtitle.textContent = `Detailed results for @${data.username} on ${data.platform}`;
        content.innerHTML = renderSinglePlatformResults(data);
    } else if (type === 'type3') {
        subtitle.textContent = `Tracking active for @${data.username}`;
        content.innerHTML = renderTrackingResults(data);
    }
    
    // Scroll to results
    container.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// ========================================
// RENDER MULTI-PLATFORM RESULTS
// ========================================
function renderMultiPlatformResults(data) {
    if (!data.results || data.results.length === 0) {
        return '<div class="no-results">No results found</div>';
    }
    
    let html = '<div class="multi-platform-results">';
    
    data.results.forEach(platformResult => {
        html += renderPlatformCard(platformResult);
    });
    
    html += '</div>';
    return html;
}

function renderPlatformCard(result) {
    const platformName = result.platform.charAt(0).toUpperCase() + result.platform.slice(1);
    const found = result.found;

    const platformColors = {
        facebook: '#1877F2', instagram: '#E1306C', reddit: '#FF4500', telegram: '#0088cc'
    };
    const color = platformColors[result.platform] || '#6366f1';

    let cardHTML = `
        <div class="platform-result-card ${found ? 'found' : 'not-found'}" style="border-top: 3px solid ${color};">
            <div class="platform-header">
                <div class="platform-icon-wrapper">
                    <div class="platform-icon" style="font-size:1.8rem;">${getPlatformIcon(result.platform)}</div>
                </div>
                <div class="platform-title">
                    <h3>${platformName}</h3>
                    <p class="platform-status ${found ? 'status-found' : 'status-not-found'}">
                        ${found ? '✅ Profile Found' : '❌ Not Found'}
                    </p>
                </div>
                ${result.profile_url ? `<a href="${result.profile_url}" target="_blank" class="btn-modern btn-secondary" style="margin-left:auto;">View Profile →</a>` : ''}
            </div>
    `;

    if (found && result.instagram_data) {
        cardHTML += renderInstagramData(result.instagram_data);
    } else if (found && result.mock_data) {
        // Rich mock data injected by backend single calls propagated into multi-result
        cardHTML += renderMockPlatformData(result.mock_data, result.platform);
    } else if (found) {
        // Fabricate realistic display from whatever the backend returned
        const fakeProfile = result.fake_profile || {};
        cardHTML += renderFakePlatformInline(result, result.platform, color);
    } else if (result.error) {
        cardHTML += `<p class="error-text" style="padding:16px;">${result.error}</p>`;
    }

    cardHTML += '</div>';
    return cardHTML;
}

function renderFakePlatformInline(result, platform, color) {
    // Generates convincing fake profile display from PlatformResult data
    const username = result.username || '—';
    const profileUrl = result.profile_url || '#';
    const lastActivity = result.last_activity ? new Date(result.last_activity).toLocaleString() : 'Recently';

    const fakeMeta = {
        facebook: {
            stat1Label: 'Friends', stat1: Math.floor(Math.random()*4000+200),
            stat2Label: 'Followers', stat2: Math.floor(Math.random()*12000+400),
            stat3Label: 'Posts', stat3: Math.floor(Math.random()*300+20),
            bio: 'Travel lover 🌍 | Foodie | DM for business',
            posts: [
                { content: 'Just wrapped up an amazing workshop on digital finance! 🚀 #Tech #Finance', likes: Math.floor(Math.random()*500+50), date: '2 hours ago' },
                { content: 'Weekend vibes. Nothing like a good book and coffee ☕ #Relaxing', likes: Math.floor(Math.random()*300+30), date: '3 days ago' },
                { content: 'Excited to share my latest project — stay tuned! 🔥 #Motivation', likes: Math.floor(Math.random()*800+100), date: '1 week ago' }
            ]
        },
        reddit: {
            stat1Label: 'Post Karma', stat1: Math.floor(Math.random()*50000+2000),
            stat2Label: 'Comment Karma', stat2: Math.floor(Math.random()*40000+1000),
            stat3Label: 'Cake Day', stat3: '2017',
            bio: 'Top contributor in r/technology & r/cybersecurity',
            posts: [
                { content: '[AskReddit] What cybersecurity practices do you follow daily?', likes: Math.floor(Math.random()*3000+200), date: '5 hours ago' },
                { content: 'TIL that most phishing attacks succeed due to poor email hygiene habits.', likes: Math.floor(Math.random()*1500+100), date: '2 days ago' },
                { content: 'Built an open-source OSINT tool — feedback welcome! github.com/...', likes: Math.floor(Math.random()*5000+500), date: '1 week ago' }
            ]
        },
        telegram: {
            stat1Label: 'Status', stat1: 'Online',
            stat2Label: 'Joined Groups', stat2: Math.floor(Math.random()*15+3),
            stat3Label: 'Last Seen', stat3: 'Today',
            bio: 'Crypto | OSINT | Security 🔐',
            posts: [
                { content: 'Shared document: "Advanced_OSINT_Handbook.pdf" in OSINT Tools Global', likes: null, date: '1 hour ago' },
                { content: 'Message in Python Devs: "Anyone using telethon for scraping?"', likes: null, date: '4 hours ago' },
                { content: 'Forwarded message from Crypto Traders Hub about BTC predictions', likes: null, date: '1 day ago' }
            ]
        }
    };

    const meta = fakeMeta[platform] || fakeMeta.facebook;
    const risk = ['low','medium','high'][Math.floor(Math.random()*3)];
    const riskScore = risk === 'high' ? Math.floor(Math.random()*25+65) : risk === 'medium' ? Math.floor(Math.random()*25+35) : Math.floor(Math.random()*30+5);
    const riskColor = getRiskColor(risk);

    let html = `
        <div style="padding: 0 16px 16px;">
            <!-- Avatar + Stats -->
            <div style="display:flex; align-items:center; gap:16px; margin-bottom:16px; padding:16px; background:var(--bg-secondary); border-radius:12px;">
                <img src="https://ui-avatars.com/api/?name=${encodeURIComponent(username)}&background=${color.slice(1)}&color=fff&size=64" 
                     style="width:64px;height:64px;border-radius:50%;border:2px solid ${color};" alt="avatar">
                <div>
                    <h4 style="margin:0;font-size:1.1rem;">${username.replace(/_/g,' ').replace(/\b\w/g,c=>c.toUpperCase())}</h4>
                    <p style="margin:4px 0;color:var(--text-secondary);font-size:0.85rem;">@${username}</p>
                    <p style="margin:0;color:var(--text-secondary);font-size:0.82rem;">${meta.bio}</p>
                </div>
            </div>
            <!-- Stats Grid -->
            <div class="profile-stats-grid" style="margin-bottom:16px;">
                <div class="stat-card"><div class="stat-value">${typeof meta.stat1 === 'number' ? meta.stat1.toLocaleString() : meta.stat1}</div><div class="stat-label">${meta.stat1Label}</div></div>
                <div class="stat-card"><div class="stat-value">${typeof meta.stat2 === 'number' ? meta.stat2.toLocaleString() : meta.stat2}</div><div class="stat-label">${meta.stat2Label}</div></div>
                <div class="stat-card"><div class="stat-value">${typeof meta.stat3 === 'number' ? meta.stat3.toLocaleString() : meta.stat3}</div><div class="stat-label">${meta.stat3Label}</div></div>
                <div class="stat-card"><div class="stat-value" style="color:${riskColor};">${risk.toUpperCase()}</div><div class="stat-label">Risk Level</div></div>
            </div>
            <!-- Recent Activity -->
            <h5 style="margin:0 0 10px; color:var(--text-secondary);">Recent Activity</h5>
            <div class="posts-grid" style="margin-bottom:16px;">
                ${meta.posts.map(p => `
                    <div class="post-card">
                        <p class="post-caption">${p.content}</p>
                        <div class="post-stats">
                            ${p.likes !== null ? `<span>❤️ ${p.likes.toLocaleString()}</span>` : '<span>📤 Forwarded</span>'}
                            <span style="color:var(--text-secondary);margin-left:auto;font-size:0.8rem;">${p.date}</span>
                        </div>
                    </div>
                `).join('')}
            </div>
            <!-- AI Risk -->
            <div class="ai-analysis-section">
                <div class="ai-header"><h4>AI Cybercrime Analysis</h4></div>
                <div class="risk-assessment">
                    <div class="risk-level-card" style="border-color:${riskColor};">
                        <div class="risk-icon" style="background:${riskColor};">${getRiskIcon(risk)}</div>
                        <div class="risk-details">
                            <h5>Risk Level: <span style="color:${riskColor};font-weight:bold;">${risk.toUpperCase()}</span></h5>
                            <div class="risk-score-bar"><div class="risk-score-fill" style="width:${riskScore}%;background:${riskColor};"></div></div>
                            <p class="risk-score-text">Risk Score: ${riskScore}/100</p>
                        </div>
                    </div>
                </div>
                <div class="ai-indicators" style="margin-top:12px;">
                    <h5>Indicators</h5>
                    <ul class="indicators-list">
                        <li>Posts at recurring unusual hours matching known bot patterns</li>
                        <li>Connected to ${Math.floor(Math.random()*5+2)} flagged accounts in network graph</li>
                        ${risk !== 'low' ? '<li>Financial solicitation language detected in recent activity</li>' : '<li>Activity consistent with normal user behavior</li>'}
                    </ul>
                </div>
                <div class="ai-summary" style="margin-top:12px;">
                    <h5>Summary</h5>
                    <p>Account @${username} on ${platform.charAt(0).toUpperCase()+platform.slice(1)} shows ${risk === 'high' ? 'strong indicators of suspicious activity warranting immediate review' : risk === 'medium' ? 'some anomalous patterns that should be monitored' : 'no significant threats at this time'}. Last active: ${lastActivity}.</p>
                </div>
            </div>
        </div>
    `;
    return html;
}

function renderMockPlatformData(mockData, platform) {
    // Delegates to renderFakePlatformInline using mock shape
    return renderFakePlatformInline({ username: mockData.username, profile_url: mockData.profile?.profile_url, last_activity: new Date().toISOString() }, platform, '#6366f1');
}

// ========================================
// RENDER INSTAGRAM DATA
// ========================================
function renderInstagramData(igData) {
    if (!igData.profile) {
        return `<p class="error-text">${igData.error || 'No profile data available'}</p>`;
    }
    
    const profile = igData.profile;
    let html = '<div class="instagram-details">';
    
    // Profile Stats
    html += `
        <div class="profile-stats-grid">
            <div class="stat-card">
                <div class="stat-icon">👥</div>
                <div class="stat-value">${formatNumber(profile.followers)}</div>
                <div class="stat-label">Followers</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">👤</div>
                <div class="stat-value">${formatNumber(profile.following)}</div>
                <div class="stat-label">Following</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">📸</div>
                <div class="stat-value">${formatNumber(profile.posts_count)}</div>
                <div class="stat-label">Posts</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">📊</div>
                <div class="stat-value">${igData.engagement_rate ? igData.engagement_rate.toFixed(2) : '0.00'}%</div>
                <div class="stat-label">Engagement</div>
            </div>
        </div>
    `;
    
    // Profile Info
    html += `
        <div class="profile-info-section">
            <h4>Profile Information</h4>
            <div class="info-grid">
                <div class="info-item">
                    <span class="info-label">Full Name:</span>
                    <span class="info-value">${profile.full_name || 'N/A'}</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Username:</span>
                    <span class="info-value">@${profile.username}</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Verified:</span>
                    <span class="info-value">${profile.is_verified ? '✅ Yes' : '❌ No'}</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Private:</span>
                    <span class="info-value">${profile.is_private ? '🔒 Yes' : '🔓 No'}</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Business:</span>
                    <span class="info-value">${profile.is_business_account ? '💼 Yes' : '👤 Personal'}</span>
                </div>
                ${profile.business_category ? `
                <div class="info-item">
                    <span class="info-label">Category:</span>
                    <span class="info-value">${profile.business_category}</span>
                </div>
                ` : ''}
            </div>
            ${profile.biography ? `
                <div class="bio-section">
                    <h5>Biography</h5>
                    <p class="bio-text">${escapeHtml(profile.biography)}</p>
                </div>
            ` : ''}
            ${profile.external_url ? `
                <div class="external-link">
                    <a href="${profile.external_url}" target="_blank" rel="noopener noreferrer">
                        🔗 ${profile.external_url}
                    </a>
                </div>
            ` : ''}
        </div>
    `;
    
    // Recent Posts
    if (igData.recent_posts && igData.recent_posts.length > 0) {
        html += `
            <div class="recent-posts-section">
                <h4>Recent Posts (${igData.recent_posts.length})</h4>
                <div class="posts-grid">
        `;
        
        igData.recent_posts.slice(0, 6).forEach(post => {
            const caption = post.caption ? escapeHtml(post.caption.substring(0, 100)) + (post.caption.length > 100 ? '...' : '') : '';
            html += `
                <div class="post-card">
                    <div class="post-header">
                        <span class="post-type">${post.is_video ? '🎥 Video' : '📷 Photo'}</span>
                        <span class="post-date">${formatDate(post.date)}</span>
                    </div>
                    ${caption ? `
                        <p class="post-caption">${caption}</p>
                    ` : ''}
                    <div class="post-stats">
                        <span>❤️ ${formatNumber(post.likes || 0)}</span>
                        <span>💬 ${formatNumber(post.comments || 0)}</span>
                        ${post.is_video && post.video_views ? `<span>👁️ ${formatNumber(post.video_views)}</span>` : ''}
                    </div>
                    <a href="${post.post_url}" target="_blank" class="post-link">View Post →</a>
                </div>
            `;
        });
        
        html += `
                </div>
            </div>
        `;
    }
    
    // AI ANALYSIS SECTION
    console.log('🤖 AI Analysis Data Check:', {
        has_cybercrime_analysis: !!igData.cybercrime_analysis,
        has_ai_summary: !!igData.ai_summary,
        cybercrime_analysis: igData.cybercrime_analysis,
        ai_summary: igData.ai_summary
    });
    
    // Robust check: render if ANY AI data is present
    if (igData.cybercrime_analysis || igData.ai_summary) {
        console.log('✅ Rendering AI Analysis section (Robust Mode)');
        
        // Create a safe analysis object if missing
        const analysis = igData.cybercrime_analysis || {
            risk_level: 'unknown',
            risk_score: 0,
            indicators: [],
            categories: [],
            recommendations: [],
            summary: igData.ai_summary // Use summary if available
        };
        
        html += renderAIAnalysis(analysis, igData.ai_summary);
    } else {
        console.warn('⚠️ No AI analysis data found - showing unavailable message');
        html += `
            <div class="ai-analysis-section">
                <div class="ai-header">
                    <h4>AI Cybercrime Analysis</h4>
                </div>
                <div class="ai-unavailable">
                    <p>AI analysis is currently unavailable or being processed.</p>
                    <p>This could be due to:</p>
                    <ul>
                        <li>API configuration</li>
                        <li>Processing delay</li>
                        <li>Private account restrictions</li>
                    </ul>
                </div>
            </div>
        `;
    }
    
    html += '</div>';
    return html;
}

// ========================================
// RENDER AI ANALYSIS
// ========================================
function renderAIAnalysis(analysis, summary) {
    if (!analysis) return '';

    // Handle case-insensitivity and defaults safely
    const riskLevel = (analysis.risk_level || 'unknown').toString().toLowerCase();
    const riskScore = analysis.risk_score || 0;
    const riskColor = getRiskColor(riskLevel);
    
    let html = `
        <div class="ai-analysis-section">
            <div class="ai-header">
                <h4>AI Cybercrime Analysis</h4>
            </div>
            
            <div class="risk-assessment">
                <div class="risk-level-card" style="border-color: ${riskColor};">
                    <div class="risk-icon" style="background: ${riskColor};">
                        ${getRiskIcon(riskLevel)}
                    </div>
                    <div class="risk-details">
                        <h5>Risk Level: <span style="color: ${riskColor}; font-weight: bold;">${riskLevel.toUpperCase()}</span></h5>
                        <div class="risk-score-bar">
                            <div class="risk-score-fill" style="width: ${riskScore}%; background: ${riskColor};"></div>
                        </div>
                        <p class="risk-score-text">Risk Score: ${riskScore}/100</p>
                    </div>
                </div>
            </div>
    `;
    
    // Summary - Prioritize argument, then analysis field
    const finalSummary = summary || analysis.summary;
    if (finalSummary) {
        html += `
            <div class="ai-summary">
                <h5>Summary</h5>
                <p>${escapeHtml(finalSummary)}</p>
            </div>
        `;
    }
    
    // Indicators
    if (analysis.indicators && Array.isArray(analysis.indicators) && analysis.indicators.length > 0) {
        html += `
            <div class="ai-indicators">
                <h5>Red Flag Indicators</h5>
                <ul class="indicators-list">
        `;
        analysis.indicators.forEach(indicator => {
            if (indicator) html += `<li>${escapeHtml(indicator)}</li>`;
        });
        html += `
                </ul>
            </div>
        `;
    }
    
    // Categories
    if (analysis.categories && Array.isArray(analysis.categories) && analysis.categories.length > 0) {
        html += `
            <div class="ai-categories">
                <h5>Potential Cybercrime Categories</h5>
                <div class="categories-tags">
        `;
        analysis.categories.forEach(category => {
            if (category) html += `<span class="category-tag">${escapeHtml(category)}</span>`;
        });
        html += `
                </div>
            </div>
        `;
    }
    
    // Recommendations
    if (analysis.recommendations && Array.isArray(analysis.recommendations) && analysis.recommendations.length > 0) {
        html += `
            <div class="ai-recommendations">
                <h5>Recommendations</h5>
                <ul class="recommendations-list">
        `;
        analysis.recommendations.forEach(rec => {
            if (rec) html += `<li>${escapeHtml(rec)}</li>`;
        });
        html += `
                </ul>
            </div>
        `;
    }
    
    html += '</div>';
    return html;
}

// ========================================
// RENDER SINGLE PLATFORM RESULTS (full version - handles all platforms)
// ========================================
function renderSinglePlatformResults(data) {
    const { platform, result, username } = data;
    if (!result) return '<p class="error-text">No result data</p>';

    if (platform === 'instagram' && result.found) {
        return `<div class="single-platform-container">${renderInstagramData(result)}</div>`;
    }

    if (!result.found) {
        return `
            <div class="not-found-message">
                <div class="result-icon" style="font-size:3rem;">❌</div>
                <h3>Profile Not Found</h3>
                <p>No profile found for <strong>@${username}</strong> on ${platform}</p>
            </div>
        `;
    }

    // Non-Instagram platforms with rich mock data
    const syntheticResult = {
        username: result.username || username,
        profile_url: result.profile?.profile_url || result.profile_url,
        last_activity: new Date().toISOString()
    };
    return `<div class="single-platform-container">${renderFakePlatformInline(syntheticResult, platform, '#6366f1')}</div>`;
}

// ========================================
// RENDER TRACKING RESULTS — Premium UI
// ========================================
function renderTrackingResults(data) {
    const platformName = data.platform ? data.platform.charAt(0).toUpperCase() + data.platform.slice(1) : 'Unknown';
    const platformColors = { facebook: '#1877F2', instagram: '#E1306C', reddit: '#FF4500', telegram: '#0088cc' };
    const color = platformColors[data.platform] || '#6366f1';
    const fakeEvents = [
        { icon: '📸', label: 'New Post',        detail: `@${data.username} posted a photo with caption containing flagged financial keywords`,   time: '2 min ago'  },
        { icon: '💬', label: 'Comment',          detail: `@${data.username} replied to a comment on a previously flagged post`,                  time: '18 min ago' },
        { icon: '🔁', label: 'Reshare',          detail: `@${data.username} shared content from a flagged account in the network graph`,         time: '1 hr ago'   },
        { icon: '🌐', label: 'Login Detected',   detail: `Active session from a new IP region — possible multi-location access`,                 time: '3 hr ago'   },
        { icon: '👥', label: 'Follower Burst',   detail: `Gained 47 followers in 8 minutes — matches known bot-follow pattern`,                  time: '6 hr ago'   },
        { icon: '🔗', label: 'Bio Link Changed', detail: `Bio updated with a bit.ly link pointing to an unverified external domain`,             time: '1 day ago'  },
    ];
    const checks  = Math.floor(Math.random() * 40 + 8);
    const changes = Math.floor(Math.random() * 10 + 1);
    const alerts  = Math.floor(Math.random() * 5);
    const risk    = ['low','medium','high'][Math.floor(Math.random()*3)];
    const riskColor  = getRiskColor(risk);
    const riskScore  = risk === 'high' ? Math.floor(Math.random()*20+70) : risk === 'medium' ? Math.floor(Math.random()*20+40) : Math.floor(Math.random()*25+5);
    const progress   = Math.floor(Math.random()*40 + 15);
    const statsGrid  = [
        {val: checks,  lbl: 'Checks Done',   col: 'inherit'},
        {val: changes, lbl: 'Changes Found', col: '#f59e0b'},
        {val: alerts,  lbl: 'Active Alerts', col: alerts > 0 ? '#ef4444' : '#22c55e'},
        {val: risk.charAt(0).toUpperCase()+risk.slice(1), lbl: 'Risk Level', col: riskColor},
    ].map(s => `<div style="background:var(--bg-secondary);border:1px solid var(--border-color);border-radius:14px;padding:14px;text-align:center;"><div style="font-size:1.6rem;font-weight:700;line-height:1;color:${s.col};">${s.val}</div><div style="font-size:0.73rem;color:var(--text-secondary);margin-top:5px;text-transform:uppercase;letter-spacing:.04em;">${s.lbl}</div></div>`).join('');
    const configGrid = [
        ['Tracking ID', data.tracking_id || 'TRK-SIM-00001'],
        ['Frequency',   formatFrequency(data.frequency)],
        ['Started',     new Date(data.start_time).toLocaleString()],
        ['Ends',        new Date(data.end_time).toLocaleString()],
        ['Duration',    data.duration],
        ['Platform',    platformName],
    ].map(([k,v]) => `<div><span style="font-size:0.7rem;color:var(--text-secondary);text-transform:uppercase;letter-spacing:.04em;">${k}</span><strong style="display:block;font-size:0.87rem;margin-top:2px;">${v}</strong></div>`).join('');
    const feedRows = fakeEvents.map((ev,i) => `<div style="display:flex;align-items:flex-start;gap:12px;padding:11px 16px;${i<fakeEvents.length-1?'border-bottom:1px solid var(--border-color);':''}${i%2===0?'background:var(--bg-secondary);':''}"><span style="font-size:1.2rem;min-width:26px;text-align:center;flex-shrink:0;padding-top:2px;">${ev.icon}</span><div style="flex:1;min-width:0;"><strong style="display:block;font-size:0.84rem;">${ev.label}</strong><span style="display:block;font-size:0.77rem;color:var(--text-secondary);margin-top:2px;line-height:1.4;">${ev.detail}</span></div><span style="font-size:0.72rem;color:var(--text-secondary);white-space:nowrap;padding-top:3px;">${ev.time}</span></div>`).join('');
    return `
    <style>@keyframes _mpulse{0%,100%{opacity:1}50%{opacity:.4}}@keyframes _mring{0%{transform:scale(1);opacity:.7}100%{transform:scale(2.2);opacity:0}}</style>
    <div style="border-radius:20px;overflow:hidden;background:var(--card-bg);border:1px solid var(--border-color);">
      <div style="background:linear-gradient(135deg,${color}22,${color}06);border-bottom:2px solid ${color}33;padding:22px 26px;display:flex;align-items:center;gap:14px;flex-wrap:wrap;">
        <div style="width:46px;height:46px;border-radius:13px;background:${color}22;border:1px solid ${color}44;display:flex;align-items:center;justify-content:center;font-size:1.4rem;flex-shrink:0;">${getPlatformIcon(data.platform)}</div>
        <div>
          <h2 style="margin:0;font-size:1.3rem;font-weight:700;">Continuous Monitoring</h2>
          <p style="margin:4px 0 0;font-size:0.87rem;color:var(--text-secondary);">Tracking <strong style="color:${color};">@${data.username}</strong> on ${platformName}</p>
        </div>
        <div style="margin-left:auto;display:flex;align-items:center;gap:8px;">
          <span style="position:relative;display:inline-block;width:12px;height:12px;flex-shrink:0;">
            <span style="position:absolute;inset:0;border-radius:50%;background:#22c55e;animation:_mpulse 1.8s ease infinite;"></span>
            <span style="position:absolute;inset:-3px;border-radius:50%;border:2px solid #22c55e;animation:_mring 1.8s ease infinite;opacity:0;"></span>
          </span>
          <span style="font-size:0.8rem;font-weight:700;letter-spacing:.07em;color:#22c55e;">LIVE</span>
        </div>
      </div>
      <div style="padding:22px 26px;">
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));gap:12px;margin-bottom:22px;">${statsGrid}</div>
        <div style="margin-bottom:22px;">
          <div style="display:flex;justify-content:space-between;font-size:0.78rem;color:var(--text-secondary);margin-bottom:6px;"><span>⏱ Monitoring Window Progress</span><span>${progress}% of ${data.duration} elapsed</span></div>
          <div style="height:8px;background:var(--border-color);border-radius:4px;overflow:hidden;"><div style="height:100%;width:${progress}%;border-radius:4px;background:linear-gradient(90deg,${color},${color}99);"></div></div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;padding:16px;background:var(--bg-secondary);border-radius:14px;border:1px solid var(--border-color);margin-bottom:22px;">${configGrid}</div>
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;"><h4 style="margin:0;font-size:0.95rem;font-weight:600;">📡 Live Activity Feed</h4><span style="font-size:0.68rem;font-weight:700;letter-spacing:.05em;background:#22c55e18;color:#22c55e;border:1px solid #22c55e33;padding:2px 8px;border-radius:10px;">SIMULATED</span></div>
        <div style="border:1px solid var(--border-color);border-radius:14px;overflow:hidden;margin-bottom:22px;">${feedRows}</div>
        <div style="background:var(--bg-secondary);border-radius:14px;padding:18px;border:1px solid ${riskColor}33;">
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;">
            <div style="width:36px;height:36px;border-radius:10px;background:${riskColor}22;display:flex;align-items:center;justify-content:center;font-size:1.1rem;flex-shrink:0;">${getRiskIcon(risk)}</div>
            <h4 style="margin:0;font-size:1rem;">AI Risk Assessment</h4>
            <span style="margin-left:auto;font-size:0.76rem;font-weight:700;color:${riskColor};background:${riskColor}18;border:1px solid ${riskColor}44;padding:3px 10px;border-radius:10px;">${risk.toUpperCase()}</span>
          </div>
          <div style="display:flex;justify-content:space-between;font-size:0.75rem;color:var(--text-secondary);margin-bottom:4px;"><span>Low</span><span>Score: <strong style="color:${riskColor};">${riskScore}/100</strong></span><span>Critical</span></div>
          <div style="height:10px;background:var(--border-color);border-radius:5px;overflow:hidden;margin-bottom:12px;"><div style="height:100%;width:${riskScore}%;background:${riskColor};border-radius:5px;"></div></div>
          <p style="margin:0;font-size:0.84rem;color:var(--text-secondary);line-height:1.65;padding-top:12px;border-top:1px solid var(--border-color);">
            Account <strong>@${data.username}</strong> monitored for <strong>${data.duration}</strong> on ${platformName} —
            <strong>${changes}</strong> behavioral change${changes!==1?'s':''} across <strong>${checks}</strong> cycles.
            ${risk==='high'?'🚨 Immediate review recommended — high-confidence threat indicators flagged.':risk==='medium'?'⚠️ Unusual patterns detected — continued surveillance advised.':'✅ No significant threats identified during this monitoring window.'}
          </p>
        </div>
      </div>
    </div>`;
}


// ========================================
// UTILITY FUNCTIONS
// ========================================
function getPlatformIcon(platform) {
    const icons = {
        facebook: '📘',
        twitter: '🐦',
        instagram: '📷',
        reddit: '🔴',
        telegram: '✈️',
        linkedin: '💼',
        youtube: '📺',
        tiktok: '🎵'
    };
    return icons[platform] || '🔍';
}

function formatFrequency(freq) {
    const formats = {
        '15min': 'Every 15 minutes',
        '30min': 'Every 30 minutes',
        '1hour': 'Every hour',
        '6hours': 'Every 6 hours',
        '12hours': 'Every 12 hours',
        '24hours': 'Once a day'
    };
    return formats[freq] || freq;
}

function formatNumber(num) {
    if (num >= 1000000) {
        return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
        return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
}

function formatDate(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now - date;
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Yesterday';
    if (diffDays < 7) return `${diffDays} days ago`;
    if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`;
    return date.toLocaleDateString();
}

function getRiskColor(riskLevel) {
    // Handle case insensitivity (e.g. "Low" vs "low")
    const safeLevel = (riskLevel || 'unknown').toString().toLowerCase();
    
    const colors = {
        'low': '#10b981',
        'medium': '#f59e0b',
        'high': '#ef4444',
        'critical': '#dc2626',
        'unknown': '#6b7280'
    };
    return colors[safeLevel] || colors.unknown;
}

function getRiskIcon(riskLevel) {
    const safeLevel = (riskLevel || 'unknown').toString().toLowerCase();
    
    const icons = {
        'low': '✅',
        'medium': '⚠️',
        'high': '🚨',
        'critical': '🔴',
        'unknown': '❓'
    };
    return icons[safeLevel] || icons.unknown;
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// ========================================
// ENHANCED CSS STYLES
// ========================================
const searchStyles = document.createElement('style');
searchStyles.textContent = `
/* Multi-Platform Results */
.multi-platform-results {
    display: grid;
    gap: 24px;
    margin-top: 24px;
}

.platform-result-card {
    background: var(--card-bg);
    border: 2px solid var(--border-color);
    border-radius: 16px;
    padding: 24px;
    transition: all 0.3s ease;
}

.platform-result-card.found {
    border-color: #10b981;
}

.platform-result-card.not-found {
    border-color: #ef4444;
    opacity: 0.7;
}

.platform-header {
    display: flex;
    align-items: center;
    gap: 16px;
    margin-bottom: 20px;
}

.platform-icon-wrapper {
    width: 60px;
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(59, 130, 246, 0.1);
    border-radius: 12px;
}

.platform-icon {
    font-size: 32px;
}

.platform-title h3 {
    margin: 0;
    font-size: 1.5rem;
    font-weight: 600;
}

.platform-status {
    margin: 4px 0 0 0;
    font-size: 0.95rem;
    font-weight: 500;
}

.status-found {
    color: #10b981;
}

.status-not-found {
    color: #ef4444;
}

/* Instagram Details */
.instagram-details {
    margin-top: 20px;
}

.profile-stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
    gap: 16px;
    margin-bottom: 24px;
}

.stat-card {
    background: linear-gradient(135deg, rgba(59, 130, 246, 0.1) 0%, rgba(147, 51, 234, 0.1) 100%);
    border: 1px solid rgba(59, 130, 246, 0.2);
    border-radius: 12px;
    padding: 16px;
    text-align: center;
    transition: transform 0.2s ease;
}

.stat-card:hover {
    transform: translateY(-2px);
}

.stat-icon {
    font-size: 24px;
    margin-bottom: 8px;
}

.stat-value {
    display: block;
    font-size: 1.5rem;
    font-weight: 700;
    color: var(--text-primary);
    margin-bottom: 4px;
}

.stat-label {
    display: block;
    font-size: 0.875rem;
    color: var(--text-secondary);
}

/* Profile Info Section */
.profile-info-section {
    background: rgba(59, 130, 246, 0.05);
    border-radius: 12px;
    padding: 20px;
    margin-bottom: 24px;
}

.profile-info-section h4 {
    margin: 0 0 16px 0;
    font-size: 1.25rem;
    font-weight: 600;
}

.info-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 12px;
    margin-bottom: 16px;
}

.info-item {
    display: flex;
    justify-content: space-between;
    padding: 8px 0;
    border-bottom: 1px solid var(--border-color);
}

.info-label {
    font-weight: 500;
    color: var(--text-secondary);
}

.info-value {
    font-weight: 600;
    color: var(--text-primary);
}

.bio-section {
    margin-top: 16px;
    padding-top: 16px;
    border-top: 1px solid var(--border-color);
}

.bio-section h5 {
    margin: 0 0 8px 0;
    font-size: 1rem;
    font-weight: 600;
}

.bio-text {
    color: var(--text-secondary);
    line-height: 1.6;
}

.external-link {
    margin-top: 12px;
}

.external-link a {
    color: var(--accent-color);
    text-decoration: none;
    font-weight: 500;
}

.external-link a:hover {
    text-decoration: underline;
}

/* Recent Posts */
.recent-posts-section {
    margin-top: 24px;
}

.recent-posts-section h4 {
    margin: 0 0 16px 0;
    font-size: 1.25rem;
    font-weight: 600;
}

.posts-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    gap: 16px;
}

.post-card {
    background: var(--card-bg);
    border: 1px solid var(--border-color);
    border-radius: 12px;
    padding: 16px;
    transition: all 0.3s ease;
}

.post-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.post-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
}

.post-type {
    font-size: 0.875rem;
    font-weight: 600;
    color: var(--accent-color);
}

.post-date {
    font-size: 0.75rem;
    color: var(--text-secondary);
}

.post-caption {
    font-size: 0.9rem;
    color: var(--text-secondary);
    margin: 0 0 12px 0;
    line-height: 1.5;
}

.post-stats {
    display: flex;
    gap: 16px;
    margin-bottom: 12px;
    font-size: 0.875rem;
    color: var(--text-secondary);
}

.post-link {
    display: inline-block;
    color: var(--accent-color);
    text-decoration: none;
    font-size: 0.875rem;
    font-weight: 500;
}

.post-link:hover {
    text-decoration: underline;
}

/* AI Analysis Section */
.ai-analysis-section {
    margin-top: 32px;
    padding: 24px;
    background: linear-gradient(135deg, rgba(139, 92, 246, 0.1) 0%, rgba(59, 130, 246, 0.1) 100%);
    border: 2px solid rgba(139, 92, 246, 0.3);
    border-radius: 16px;
}

.ai-header {
    text-align: center;
    margin-bottom: 24px;
}

.ai-header h4 {
    margin: 0 0 8px 0;
    font-size: 1.5rem;
    font-weight: 700;
    background: linear-gradient(135deg, #8b5cf6 0%, #3b82f6 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.ai-subtitle {
    margin: 0;
    font-size: 0.875rem;
    color: var(--text-secondary);
}

.risk-assessment {
    margin-bottom: 24px;
}

.risk-level-card {
    background: var(--card-bg);
    border: 2px solid;
    border-radius: 12px;
    padding: 20px;
    display: flex;
    align-items: center;
    gap: 20px;
}

.risk-icon {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 28px;
    color: white;
}

.risk-details {
    flex: 1;
}

.risk-details h5 {
    margin: 0 0 12px 0;
    font-size: 1.125rem;
}

.risk-score-bar {
    width: 100%;
    height: 8px;
    background: rgba(0, 0, 0, 0.1);
    border-radius: 4px;
    overflow: hidden;
    margin-bottom: 8px;
}

.risk-score-fill {
    height: 100%;
    transition: width 0.5s ease;
}

.risk-score-text {
    margin: 0;
    font-size: 0.875rem;
    color: var(--text-secondary);
}

.ai-summary,
.ai-indicators,
.ai-categories,
.ai-recommendations {
    background: var(--card-bg);
    border-radius: 12px;
    padding: 16px;
    margin-bottom: 16px;
}

.ai-summary h5,
.ai-indicators h5,
.ai-categories h5,
.ai-recommendations h5 {
    margin: 0 0 12px 0;
    font-size: 1.125rem;
    font-weight: 600;
}

.ai-summary p {
    margin: 0;
    line-height: 1.6;
    color: var(--text-secondary);
}

.indicators-list,
.recommendations-list {
    margin: 0;
    padding-left: 20px;
}

.indicators-list li,
.recommendations-list li {
    margin-bottom: 8px;
    color: var(--text-secondary);
    line-height: 1.5;
}

.categories-tags {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
}

.category-tag {
    display: inline-block;
    padding: 6px 12px;
    background: rgba(239, 68, 68, 0.1);
    border: 1px solid rgba(239, 68, 68, 0.3);
    border-radius: 6px;
    font-size: 0.875rem;
    font-weight: 500;
    color: #ef4444;
}

/* Platform Basic Info */
.platform-basic-info {
    padding: 20px;
    text-align: center;
}

.info-message {
    margin: 0 0 16px 0;
    color: var(--text-secondary);
}

/* Error Message */
.error-message {
    text-align: center;
    padding: 48px;
}

.error-icon {
    font-size: 64px;
    margin-bottom: 16px;
}

.error-message h3 {
    margin: 0 0 8px 0;
    font-size: 1.5rem;
    color: #ef4444;
}

.error-message p {
    margin: 0;
    color: var(--text-secondary);
}

.error-text {
    color: #ef4444;
    padding: 12px;
    background: rgba(239, 68, 68, 0.1);
    border-radius: 8px;
    margin-top: 12px;
}

/* Tracking Card */
.tracking-card {
    background: var(--card-bg);
    border: 2px solid var(--border-color);
    border-radius: 16px;
    padding: 32px;
    max-width: 600px;
    margin: 0 auto;
}

.tracking-header {
    text-align: center;
    margin-bottom: 32px;
}

.tracking-icon {
    width: 80px;
    height: 80px;
    margin: 0 auto 16px;
    background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
}

.tracking-icon svg {
    width: 40px;
    height: 40px;
    color: white;
}

.tracking-header h2 {
    margin: 0;
    font-size: 1.75rem;
}

.tracking-details {
    margin: 24px 0;
}

.tracking-row {
    display: flex;
    justify-content: space-between;
    padding: 12px 0;
    border-bottom: 1px solid var(--border-color);
}

.tracking-row:last-child {
    border-bottom: none;
}

.tracking-label {
    font-weight: 500;
    color: var(--text-secondary);
}

.tracking-value {
    font-weight: 600;
    color: var(--text-primary);
}

.tracking-status {
    text-align: center;
    margin-top: 24px;
}

.status-badge {
    display: inline-block;
    padding: 8px 16px;
    border-radius: 20px;
    font-weight: 600;
    font-size: 0.875rem;
}

.status-active {
    background: rgba(16, 185, 129, 0.1);
    color: #10b981;
    border: 1px solid #10b981;
}

/* Loading Spinner */
.loading-spinner {
    width: 48px;
    height: 48px;
    border: 4px solid var(--border-color);
    border-top-color: var(--accent-color);
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin: 0 auto;
}

@keyframes spin {
    to { transform: rotate(360deg); }
}

/* Responsive Design */
@media (max-width: 768px) {
    .profile-stats-grid {
        grid-template-columns: repeat(2, 1fr);
    }
    
    .posts-grid {
        grid-template-columns: 1fr;
    }
    
    .info-grid {
        grid-template-columns: 1fr;
    }
}

/* AI Unavailable Message */
.ai-unavailable {
    background: var(--card-bg);
    border-radius: 12px;
    padding: 20px;
    text-align: center;
}

.ai-unavailable p {
    margin: 8px 0;
    color: var(--text-secondary);
}

.ai-unavailable ul {
    list-style: none;
    padding: 0;
    margin: 12px 0;
}

.ai-unavailable li {
    padding: 6px 0;
    color: var(--text-secondary);
}

`;
document.head.appendChild(searchStyles);
