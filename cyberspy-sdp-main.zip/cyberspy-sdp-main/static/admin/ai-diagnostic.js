// Quick diagnostic script to test AI data flow
// Run this in browser console after doing a search

console.log('=== AI DATA DIAGNOSTIC ===');

// Check if search-functions.js is loaded
console.log('search-functions.js loaded:', typeof initSearchHandlers !== 'undefined');

// Check current search type
console.log('Current search type:', window.currentSearchType);

// Try to manually trigger a search and log the response
async function testSearch() {
    try {
        const response = await fetch('/api/search/single-platform', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                username: 'isthaturja',
                platform: 'instagram'
            })
        });
        
        const data = await response.json();
        console.log('=== FULL API RESPONSE ===');
        console.log(JSON.stringify(data, null, 2));
        
        console.log('\n=== AI DATA CHECK ===');
        console.log('Has instagram_data:', !!data.instagram_data);
        console.log('Has cybercrime_analysis:', !!data.instagram_data?.cybercrime_analysis);
        console.log('Has ai_summary:', !!data.instagram_data?.ai_summary);
        
        if (data.instagram_data?.cybercrime_analysis) {
            console.log('\n=== CYBERCRIME ANALYSIS ===');
            console.log(JSON.stringify(data.instagram_data.cybercrime_analysis, null, 2));
        }
        
        if (data.instagram_data?.ai_summary) {
            console.log('\n=== AI SUMMARY ===');
            console.log(data.instagram_data.ai_summary);
        }
        
    } catch (error) {
        console.error('Test search failed:', error);
    }
}

console.log('\nRun testSearch() to check API response');
