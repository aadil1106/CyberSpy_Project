// Admin Reports (loaded dynamically by static/admin/script.js)
// Exposes functions on window for onclick handlers in reports.html.

(() => {
    const API_BASE = '/api';

    // State
    let currentReportData = [];
    let _filteredData = [];
    let _currentPage = 1;
    const PAGE_SIZE = 50;

    let _rvCurrentJson = null;
    let _isInitialized = false;

    // Utilities
    function $(id) { return document.getElementById(id); }

    function notify(message, type = 'info') {
        if (typeof window.showToast === 'function') return window.showToast(message, type === 'error' ? 'error' : type);
        if (typeof window.showNotification === 'function') return window.showNotification(message, type);
        console.log(`[${type.toUpperCase()}] ${message}`);
    }

    function escapeHtml(str) {
        return String(str ?? '')
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    function highlight(text, term) {
        const raw = String(text ?? '');
        if (!term || !term.trim() || !raw) return escapeHtml(raw);
        const safe = term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const regex = new RegExp(`(${safe})`, 'gi');
        return escapeHtml(raw).replace(regex, '<mark class="rpt-hl">$1</mark>');
    }

    function today() { return new Date().toISOString().split('T')[0]; }

    function formatDateTime(ds) {
        try {
            return new Date(ds).toLocaleString('en-IN', {
                year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
            });
        } catch {
            return String(ds ?? '');
        }
    }

    function triggerDownload(blob, filename) {
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);
    }

    // Filters
    async function loadFilterOptions() {
        const citySelect = $('filter-city');
        const branchSelect = $('filter-branch');
        const officerSelect = $('filter-officer');
        if (!citySelect || !branchSelect || !officerSelect) return;

        try {
            const [citiesRes, branchesRes, officersRes] = await Promise.all([
                fetch(`${API_BASE}/cities/`),
                fetch(`${API_BASE}/branches/`),
                fetch(`${API_BASE}/officers/`),
            ]);
            const [cities, branches, officers] = await Promise.all([
                citiesRes.json(),
                branchesRes.json(),
                officersRes.json(),
            ]);

            citySelect.innerHTML = '<option value="">All Cities</option>' + (Array.isArray(cities)
                ? cities.map(c => `<option value="${escapeHtml(c.city_name)}">${escapeHtml(c.city_name)}</option>`).join('')
                : '');

            // Branches show with city label
            const cityById = new Map((Array.isArray(cities) ? cities : []).map(c => [c.id, c.city_name]));
            branchSelect.innerHTML = '<option value="">All Branches</option>' + (Array.isArray(branches)
                ? branches.map(b => {
                    const city = cityById.get(b.city_id) || 'Unknown';
                    return `<option value="${escapeHtml(b.branch_name)}">${escapeHtml(b.branch_name)} (${escapeHtml(city)})</option>`;
                }).join('')
                : '');

            officerSelect.innerHTML = '<option value="">All Officers</option>' + (Array.isArray(officers)
                ? officers.map(o => `<option value="${o.id}">${escapeHtml(o.first_name)} ${escapeHtml(o.last_name)}</option>`).join('')
                : '');
        } catch (e) {
            console.error(e);
            notify('Error loading report filters', 'error');
        }
    }

    function getFilterValues() {
        return {
            city_name: $('filter-city')?.value || '',
            branch_name: $('filter-branch')?.value || '',
            officer_id: $('filter-officer')?.value || '',
            date_from: ($('filter-start-date')?.value || '').split('T')[0],
            date_to: ($('filter-end-date')?.value || '').split('T')[0],
            social_media: $('filter-social-media')?.value || '',
            username: $('filter-username')?.value || '',
            global_search: $('filter-global-search')?.value || '',
        };
    }

    function buildQueryParams(f) {
        const qp = new URLSearchParams();
        if (f.officer_id) qp.append('officer_id', f.officer_id);
        if (f.city_name) qp.append('city_name', f.city_name);
        if (f.branch_name) qp.append('branch_name', f.branch_name);
        if (f.social_media) qp.append('social_media', f.social_media);
        if (f.username) qp.append('username', f.username);
        if (f.date_from) qp.append('date_from', f.date_from);
        if (f.date_to) qp.append('date_to', f.date_to);
        if (f.global_search) qp.append('global_search', f.global_search);
        return qp.toString();
    }

    // Table rendering + pagination
    function showLoadingState() {
        const tbody = $('reports-tbody');
        if (!tbody) return;
        tbody.innerHTML = `
            <tr>
                <td colspan="9" class="empty-cell">
                    <div class="empty-state">
                        <div class="spinner"></div>
                        <p>Generating report…</p>
                    </div>
                </td>
            </tr>`;
    }

    function updateReportCount(n) {
        const el = $('report-count');
        if (el) el.textContent = `${n} search${n !== 1 ? 'es' : ''}`;
    }

    function updatePagination() {
        const totalPages = Math.ceil(_filteredData.length / PAGE_SIZE) || 1;
        const pag = $('rpt-pagination');
        const info = $('rpt-page-info');
        const prev = $('rpt-prev');
        const next = $('rpt-next');
        if (!pag || !info || !prev || !next) return;

        if (_filteredData.length > PAGE_SIZE) {
            pag.style.display = 'flex';
            info.textContent = `Page ${_currentPage} of ${totalPages}`;
            prev.disabled = _currentPage <= 1;
            next.disabled = _currentPage >= totalPages;
        } else {
            pag.style.display = 'none';
        }
    }

    function renderPage(page) {
        const start = (page - 1) * PAGE_SIZE;
        const end = start + PAGE_SIZE;
        const slice = _filteredData.slice(start, end);
        const term = ($('rpt-search')?.value || '').trim();
        displayReportData(slice, term);
        updatePagination();
    }

    function getRiskBadgeHtml(level) {
        const v = String(level ?? 'N/A').toLowerCase();
        if (v === 'high') return '<span class="risk-high">High</span>';
        if (v === 'medium') return '<span class="risk-medium">Medium</span>';
        if (v === 'low') return '<span class="risk-low">Low</span>';
        return `<span>${escapeHtml(level ?? 'N/A')}</span>`;
    }

    function buildRow(record, result, searchTerm) {
        const row = document.createElement('tr');

        const platform = result?.platform || record?.file_data?.platform || 'N/A';
        const username = result?.username || record?.file_data?.username || record?.search_query || 'N/A';
        const risk = result?.cybercrime_analysis?.risk_level
            || result?.instagram_data?.cybercrime_analysis?.risk_level
            || record?.file_data?.risk_level
            || 'N/A';

        row.innerHTML = `
            <td>${highlight(record?.officer_name || 'N/A', searchTerm)}</td>
            <td>${highlight(record?.branch_name || 'N/A', searchTerm)}</td>
            <td>${highlight(record?.city_name || 'N/A', searchTerm)}</td>
            <td>${highlight(record?.search_query || 'N/A', searchTerm)}</td>
            <td>${highlight(username, searchTerm)}</td>
            <td>${highlight(platform, searchTerm)}</td>
            <td>${formatDateTime(record?.searched_at)}</td>
            <td>${getRiskBadgeHtml(risk)}</td>
            <td>
                <button class="btn-modern btn-sm btn-secondary rpt-view-btn" type="button" title="View JSON">
                    <svg viewBox="0 0 24 24" fill="none" width="13" height="13">
                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" stroke="currentColor" stroke-width="2"/>
                        <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="2"/>
                    </svg>
                    View
                </button>
            </td>
        `;

        const btn = row.querySelector('.rpt-view-btn');
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            openResultViewerData(record, result);
        });

        return row;
    }

    function displayReportData(data, searchTerm = '') {
        const tbody = $('reports-tbody');
        if (!tbody) return;
        tbody.innerHTML = '';

        if (!data || data.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="9" class="empty-cell">
                        <div class="empty-state">
                            <p>${currentReportData.length ? 'No results match your search.' : 'No reports loaded. Apply filters and generate report.'}</p>
                        </div>
                    </td>
                </tr>`;
            updateReportCount(0);
            return;
        }

        let totalRows = 0;
        for (const record of data) {
            const fileData = record?.file_data || {};
            let results = [];

            if (Array.isArray(fileData.results)) {
                results = fileData.results;
            } else if (fileData.result) {
                results = [{
                    platform: fileData.platform || 'N/A',
                    username: fileData.username || record.search_query,
                    found: fileData.result?.found || false,
                    instagram_data: {
                        profile: fileData.result?.profile || {},
                        cybercrime_analysis: fileData.result?.cybercrime_analysis || {}
                    }
                }];
            }

            if (!results.length) {
                tbody.appendChild(buildRow(record, null, searchTerm));
                totalRows++;
                continue;
            }

            for (const r of results) {
                tbody.appendChild(buildRow(record, r, searchTerm));
                totalRows++;
            }
        }

        updateReportCount(totalRows);
    }

    // Global search over all fields + highlight
    function applyTableSearch(term) {
        const t = (term || '').trim();
        if (!t) {
            _filteredData = currentReportData;
            _currentPage = 1;
            return renderPage(_currentPage);
        }
        const lo = t.toLowerCase();
        _filteredData = currentReportData.filter(record => {
            const hay = [
                record?.officer_name, record?.branch_name, record?.city_name, record?.search_query,
                record?.search_type, record?.result_file_path
            ].filter(Boolean).join(' ').toLowerCase();
            if (hay.includes(lo)) return true;
            try {
                const json = record?.file_data ? JSON.stringify(record.file_data).toLowerCase() : '';
                return json.includes(lo);
            } catch {
                return false;
            }
        });
        _currentPage = 1;
        renderPage(_currentPage);
    }

    // Result Viewer (modal with searchable collapsible JSON tree)
    function buildJsonTree(data, filterText) {
        const container = $('rv-json-tree');
        if (!container) return;
        container.innerHTML = '';
        container.appendChild(renderJsonNode(data, (filterText || '').toLowerCase(), true));
    }

    function renderJsonNode(value, filterTerm, expanded, key) {
        const wrapper = document.createElement('div');
        wrapper.className = 'jt-node';

        if (value !== null && typeof value === 'object') {
            const isArr = Array.isArray(value);
            const entries = isArr ? value.map((v, i) => [i, v]) : Object.entries(value);
            const open = expanded !== false;

            const header = document.createElement('span');
            if (key !== undefined) {
                const keySpan = document.createElement('span');
                keySpan.className = 'jt-key';
                keySpan.textContent = JSON.stringify(key) + ': ';
                header.appendChild(keySpan);
            }

            const toggle = document.createElement('span');
            toggle.className = 'jt-toggle';
            toggle.textContent = open ? '▾' : '▸';
            header.appendChild(toggle);
            header.appendChild(document.createTextNode(isArr ? '[' : '{'));

            const preview = document.createElement('span');
            preview.className = 'jt-collapsed-preview';
            preview.textContent = ` ${entries.length} ${isArr ? 'item' : 'key'}${entries.length !== 1 ? 's' : ''} `;
            preview.style.display = open ? 'none' : 'inline';
            header.appendChild(preview);
            wrapper.appendChild(header);

            const children = document.createElement('div');
            children.className = 'jt-children' + (open ? '' : ' jt-hidden');
            for (const [k, v] of entries) {
                children.appendChild(renderJsonNode(v, filterTerm, true, k));
            }
            children.appendChild(document.createTextNode(isArr ? ']' : '}'));
            wrapper.appendChild(children);

            toggle.addEventListener('click', (e) => {
                e.stopPropagation();
                const collapsed = children.classList.contains('jt-hidden');
                children.classList.toggle('jt-hidden', !collapsed);
                toggle.textContent = collapsed ? '▾' : '▸';
                preview.style.display = collapsed ? 'none' : 'inline';
            });

            if (filterTerm) {
                let ok = false;
                try { ok = JSON.stringify(value).toLowerCase().includes(filterTerm); } catch { ok = false; }
                wrapper.style.display = ok ? '' : 'none';
            }
        } else {
            const line = document.createElement('span');
            if (key !== undefined) {
                const keySpan = document.createElement('span');
                keySpan.className = 'jt-key';
                keySpan.textContent = JSON.stringify(key) + ': ';
                line.appendChild(keySpan);
            }

            const valSpan = document.createElement('span');
            if (value === null) { valSpan.className = 'jt-null'; valSpan.textContent = 'null'; }
            else if (typeof value === 'boolean') { valSpan.className = 'jt-bool'; valSpan.textContent = String(value); }
            else if (typeof value === 'number') { valSpan.className = 'jt-number'; valSpan.textContent = String(value); }
            else { valSpan.className = 'jt-string'; valSpan.textContent = JSON.stringify(value); }
            line.appendChild(valSpan);
            wrapper.appendChild(line);

            if (filterTerm) {
                const strVal = String(value === null ? 'null' : value).toLowerCase();
                const strKey = key !== undefined ? String(key).toLowerCase() : '';
                if (!strVal.includes(filterTerm) && !strKey.includes(filterTerm)) wrapper.style.display = 'none';
                else wrapper.classList.add('jt-match-line');
            }
        }
        return wrapper;
    }

    function filterJsonView(term) {
        if ($('rv-panel-json')?.style.display !== 'none') buildJsonTree(_rvCurrentJson, term);
    }

    function collapseAllJsonNodes() {
        document.querySelectorAll('#rv-json-tree .jt-children').forEach(el => {
            el.classList.add('jt-hidden');
            const toggle = el.previousElementSibling?.querySelector('.jt-toggle');
            if (toggle) toggle.textContent = '▸';
            const preview = el.previousElementSibling?.querySelector('.jt-collapsed-preview');
            if (preview) preview.style.display = 'inline';
        });
    }

    function expandAllJsonNodes() {
        document.querySelectorAll('#rv-json-tree .jt-children').forEach(el => {
            el.classList.remove('jt-hidden');
            const toggle = el.previousElementSibling?.querySelector('.jt-toggle');
            if (toggle) toggle.textContent = '▾';
            const preview = el.previousElementSibling?.querySelector('.jt-collapsed-preview');
            if (preview) preview.style.display = 'none';
        });
    }

    function switchRvTab(tab) {
        const summaryPanel = $('rv-panel-summary');
        const jsonPanel = $('rv-panel-json');
        const tSum = $('rv-tab-summary');
        const tJson = $('rv-tab-json');
        if (!summaryPanel || !jsonPanel || !tSum || !tJson) return;

        if (tab === 'summary') {
            summaryPanel.style.display = 'block';
            jsonPanel.style.display = 'none';
            tSum.classList.add('rv-tab-active');
            tJson.classList.remove('rv-tab-active');
        } else {
            summaryPanel.style.display = 'none';
            jsonPanel.style.display = 'block';
            tSum.classList.remove('rv-tab-active');
            tJson.classList.add('rv-tab-active');
            buildJsonTree(_rvCurrentJson, $('rv-json-search')?.value || '');
        }
    }

    function closeResultViewer() {
        const modal = $('result-viewer-modal');
        if (modal) modal.style.display = 'none';
        document.body.style.overflow = '';
    }

    function copyRvJson() {
        if (!_rvCurrentJson) return;
        const text = JSON.stringify(_rvCurrentJson, null, 2);
        navigator.clipboard.writeText(text)
            .then(() => notify('JSON copied to clipboard!', 'success'))
            .catch(() => notify('Failed to copy JSON', 'error'));
    }

    function openResultViewerData(record, result) {
        const platform =
            result?.platform ||
            record?.file_data?.platform ||
            (record?.file_data?.results?.[0]?.platform) ||
            'N/A';
        const username =
            result?.username ||
            record?.file_data?.username ||
            record?.search_query ||
            'unknown';

        // Normalize a few common shapes we see in JSON.
        const found =
            (typeof result?.found === 'boolean' ? result.found : undefined) ??
            (typeof record?.file_data?.result?.found === 'boolean' ? record.file_data.result.found : undefined) ??
            null;

        const profile =
            result?.instagram_data?.profile ||
            result?.profile ||
            record?.file_data?.result?.profile ||
            record?.file_data?.profile ||
            {};

        const cyber =
            result?.instagram_data?.cybercrime_analysis ||
            result?.cybercrime_analysis ||
            record?.file_data?.result?.cybercrime_analysis ||
            record?.file_data?.cybercrime_analysis ||
            {};

        _rvCurrentJson = {
            record_id: record?.id,
            officer: record?.officer_name,
            branch: record?.branch_name,
            city: record?.city_name,
            search_query: record?.search_query,
            searched_at: record?.searched_at,
            result_file_path: record?.result_file_path,
            file_data: record?.file_data ?? null,
            result: result ?? null,
        };

        const title = $('rv-title');
        if (title) title.textContent = `Result — @${username} on ${platform}`;

        const summary = $('rv-summary-content');
        if (summary) {
            const riskLevel = cyber?.risk_level ?? 'N/A';
            const riskScore = cyber?.risk_score ?? 'N/A';
            const categories = Array.isArray(cyber?.categories) ? cyber.categories : [];
            const indicators = Array.isArray(cyber?.indicators) ? cyber.indicators : [];

            summary.innerHTML = `
                <div class="rv-card">
                    <h4>Result</h4>
                    <dl class="rv-kv">
                        <dt>Officer</dt><dd>${escapeHtml(record?.officer_name || 'N/A')}</dd>
                        <dt>Branch</dt><dd>${escapeHtml(record?.branch_name || 'N/A')}</dd>
                        <dt>City</dt><dd>${escapeHtml(record?.city_name || 'N/A')}</dd>
                        <dt>Search Query</dt><dd><strong>${escapeHtml(record?.search_query || 'N/A')}</strong></dd>
                        <dt>Searched At</dt><dd>${formatDateTime(record?.searched_at)}</dd>
                        <dt>Platform</dt><dd>${escapeHtml(platform)}</dd>
                        <dt>Username</dt><dd>@${escapeHtml(username)}</dd>
                        <dt>Found</dt><dd>${found === null ? 'N/A' : (found ? '<span class="risk-low">Yes</span>' : '<span class="risk-high">No</span>')}</dd>
                    </dl>
                </div>

                ${(profile && (profile.username || profile.full_name || profile.biography))
                    ? `<div class="rv-card">
                        <h4>Profile</h4>
                        <dl class="rv-kv">
                            <dt>Full Name</dt><dd>${escapeHtml(profile.full_name || 'N/A')}</dd>
                            <dt>Username</dt><dd>${escapeHtml(profile.username ? '@' + profile.username : 'N/A')}</dd>
                            <dt>Bio</dt><dd style="white-space:pre-wrap;">${escapeHtml(profile.biography || '—')}</dd>
                            <dt>Followers</dt><dd>${escapeHtml(profile.followers ?? 'N/A')}</dd>
                            <dt>Following</dt><dd>${escapeHtml(profile.following ?? 'N/A')}</dd>
                            <dt>Posts</dt><dd>${escapeHtml(profile.posts_count ?? 'N/A')}</dd>
                        </dl>
                    </div>` : ''}

                ${(cyber && (cyber.risk_level || cyber.summary || indicators.length || categories.length))
                    ? `<div class="rv-card">
                        <h4>Risk Summary</h4>
                        <dl class="rv-kv">
                            <dt>Risk Level</dt><dd>${getRiskBadgeHtml(riskLevel)}</dd>
                            <dt>Risk Score</dt><dd><strong>${escapeHtml(riskScore)}</strong></dd>
                            <dt>Categories</dt><dd>${escapeHtml(categories.join(', ') || 'None')}</dd>
                            <dt>Summary</dt><dd style="white-space:pre-wrap;">${escapeHtml(cyber.summary || 'N/A')}</dd>
                        </dl>
                        ${indicators.length ? `<div style="margin-top:.6rem;">
                            ${indicators.map(i => `<span class="rv-indicator">${escapeHtml(i)}</span>`).join('')}
                        </div>` : ''}
                    </div>` : ''}
            `;
        }

        // Simple modal: summary only
        const modal = $('result-viewer-modal');
        if (modal) modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }

    // API actions
    async function generateReport() {
        try {
            showLoadingState();
            const filters = getFilterValues();
            const qp = buildQueryParams(filters);

            const [dataRes, statsRes] = await Promise.all([
                fetch(`${API_BASE}/reports/filter?${qp}&page_size=1000`),
                fetch(`${API_BASE}/reports/statistics?${qp}`),
            ]);
            if (!dataRes.ok) throw new Error(`${dataRes.status} ${dataRes.statusText}`);

            const data = await dataRes.json();
            const stats = await statsRes.json();

            currentReportData = Array.isArray(data.results) ? data.results : [];
            _filteredData = currentReportData;
            _currentPage = 1;

            renderPage(_currentPage);
            displayStatistics(stats);

            const exportBtns = $('export-buttons');
            if (exportBtns) exportBtns.style.display = currentReportData.length ? 'flex' : 'none';
            const searchWrap = $('rpt-search-wrap');
            if (searchWrap) searchWrap.style.display = currentReportData.length ? 'block' : 'none';
            const search = $('rpt-search');
            if (search) search.value = '';

            notify(`Report generated: ${currentReportData.length} record${currentReportData.length !== 1 ? 's' : ''}`, 'success');
        } catch (e) {
            console.error(e);
            notify(`Error generating report: ${e.message}`, 'error');
        }
    }

    function displayStatistics(s) {
        const empty = $('stats-empty');
        const grid = $('stats-grid');
        if (empty) empty.style.display = 'none';
        if (grid) grid.style.display = 'grid';
        if ($('stat-total-reports')) $('stat-total-reports').textContent = s?.total_searches || 0;
        if ($('stat-unique-officers')) $('stat-unique-officers').textContent = s?.unique_officers || 0;
        if ($('stat-platforms-covered')) $('stat-platforms-covered').textContent = s?.platforms_covered || 0;
        if ($('stat-cities-covered')) $('stat-cities-covered').textContent = s?.unique_cities || 0;
    }

    async function exportToCSV() {
        if (!currentReportData.length) return notify('No data to export', 'warning');
        try {
            const qp = buildQueryParams(getFilterValues());
            const res = await fetch(`${API_BASE}/reports/export/csv?${qp}`);
            if (!res.ok) throw new Error('Failed to export CSV');
            triggerDownload(await res.blob(), `search_results_${today()}.csv`);
            notify('Exported to CSV', 'success');
        } catch (e) {
            console.error(e);
            notify(`Export error: ${e.message}`, 'error');
        }
    }

    async function exportToPDF() {
        if (!currentReportData.length) return notify('No data to export', 'warning');
        try {
            const qp = buildQueryParams(getFilterValues());
            const res = await fetch(`${API_BASE}/reports/export/pdf?${qp}`);
            if (!res.ok) throw new Error('Failed to export PDF');
            triggerDownload(await res.blob(), `search_results_${today()}.pdf`);
            notify('Exported to PDF', 'success');
        } catch (e) {
            console.error(e);
            notify(`Export error: ${e.message}`, 'error');
        }
    }

    function clearFilters() {
        ['filter-city', 'filter-branch', 'filter-officer', 'filter-social-media'].forEach(id => { const el = $(id); if (el) el.value = ''; });
        ['filter-start-date', 'filter-end-date', 'filter-username', 'filter-global-search'].forEach(id => { const el = $(id); if (el) el.value = ''; });
        currentReportData = [];
        _filteredData = [];
        _currentPage = 1;
        displayReportData([], '');
        const exportBtns = $('export-buttons');
        if (exportBtns) exportBtns.style.display = 'none';
        const searchWrap = $('rpt-search-wrap');
        if (searchWrap) searchWrap.style.display = 'none';
        const pag = $('rpt-pagination');
        if (pag) pag.style.display = 'none';
        const empty = $('stats-empty');
        const grid = $('stats-grid');
        if (empty) empty.style.display = '';
        if (grid) grid.style.display = 'none';
        updateReportCount(0);
    }

    function changePage(delta) {
        const totalPages = Math.ceil(_filteredData.length / PAGE_SIZE) || 1;
        _currentPage = Math.min(Math.max(1, _currentPage + delta), totalPages);
        renderPage(_currentPage);
    }

    // Init
    function init() {
        // prevent double init when switching sections
        if (_isInitialized && $('reports')) {
            // still refresh filter options (in case data changed)
            loadFilterOptions();
            return;
        }
        _isInitialized = true;

        // modal close behaviors
        const modal = $('result-viewer-modal');
        if (modal) {
            modal.addEventListener('click', function (e) {
                if (e.target === this) closeResultViewer();
            });
        }
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') closeResultViewer();
        });

        loadFilterOptions();

        // Make deep keyword search feel responsive: Enter triggers generation.
        const deep = $('filter-global-search');
        if (deep && !deep.dataset.bound) {
            deep.dataset.bound = '1';
            deep.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    generateReport();
                }
            });
        }
    }

    // Expose public API for admin/script.js
    window.AdminReports = { init };

    // Expose functions for onclick handlers inside reports.html
    window.generateReport = generateReport;
    window.clearFilters = clearFilters;
    window.exportToCSV = exportToCSV;
    window.exportToPDF = exportToPDF;
    window.applyTableSearch = applyTableSearch;
    window.changePage = changePage;
    window.openResultViewerData = openResultViewerData;
    window.closeResultViewer = closeResultViewer;
    window.switchRvTab = switchRvTab;
    window.copyRvJson = copyRvJson;
    window.filterJsonView = filterJsonView;
    window.collapseAllJsonNodes = collapseAllJsonNodes;
    window.expandAllJsonNodes = expandAllJsonNodes;
})();
