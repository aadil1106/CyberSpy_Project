const API_BASE = '/api';

console.log('🚀 Admin script.js loaded successfully');


// Sidebar Toggle Logic
function initSidebar() {
    const toggleBtn = document.getElementById('sidebar-toggle');
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    const sidebar = document.getElementById('sidebar');
    const body = document.body;
    
    // Check local storage for preference
    const isCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
    if (isCollapsed) {
        body.classList.add('sidebar-collapsed');
    }
    
    // Desktop sidebar toggle
    if (toggleBtn) {
        toggleBtn.addEventListener('click', () => {
            body.classList.toggle('sidebar-collapsed');
            localStorage.setItem('sidebarCollapsed', body.classList.contains('sidebar-collapsed'));
        });
    }

    // Mobile menu button toggle
    if (mobileMenuBtn) {
        mobileMenuBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            body.classList.toggle('mobile-menu-open');
        });
    }

    // Close mobile menu when clicking outside
    document.addEventListener('click', (e) => {
        if (window.innerWidth <= 768) {
            const isClickInsideSidebar = sidebar && sidebar.contains(e.target);
            const isClickOnMenuBtn = mobileMenuBtn && mobileMenuBtn.contains(e.target);
            
            if (!isClickInsideSidebar && !isClickOnMenuBtn && body.classList.contains('mobile-menu-open')) {
                body.classList.remove('mobile-menu-open');
            }
        }
    });

    // Close mobile menu when clicking on nav items
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        item.addEventListener('click', () => {
            if (window.innerWidth <= 768) {
                body.classList.remove('mobile-menu-open');
            }
        });
    });

    initTheme();
}

function initTheme() {
    const themeToggle = document.getElementById('theme-toggle');
    const themeIconSvg = document.getElementById('theme-icon-svg');
    const themeLabel = document.getElementById('theme-label');
    const body = document.body;

    // Display username from session
    const username = sessionStorage.getItem('username');
    const userNameElement = document.getElementById('user-name');
    if (userNameElement && username) {
        userNameElement.textContent = username.charAt(0).toUpperCase() + username.slice(1);
    }

    // Check local storage or system preference
    const savedTheme = localStorage.getItem('theme');
    const systemDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    
    let isDark = savedTheme === 'dark' || (!savedTheme && systemDark);

    // Apply initial theme
    if (isDark) {
        body.setAttribute('data-theme', 'dark');
        updateThemeUI(true);
    }

    if (themeToggle) {
        themeToggle.addEventListener('click', (e) => {
            e.preventDefault();
            isDark = !isDark;
            if (isDark) {
                body.setAttribute('data-theme', 'dark');
                localStorage.setItem('theme', 'dark');
            } else {
                body.removeAttribute('data-theme');
                localStorage.setItem('theme', 'light');
            }
            updateThemeUI(isDark);
        });
    }

    function updateThemeUI(dark) {
        if (themeIconSvg) {
            if (dark) {
                // Sun icon for light mode
                themeIconSvg.innerHTML = `
                    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="12" cy="12" r="5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        <path d="M12 1V3M12 21V23M4.22 4.22L5.64 5.64M18.36 18.36L19.78 19.78M1 12H3M21 12H23M4.22 19.78L5.64 18.36M18.36 5.64L19.78 4.22" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                `;
            } else {
                // Moon icon for dark mode
                themeIconSvg.innerHTML = `
                    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                `;
            }
        }
        if (themeLabel) {
            themeLabel.textContent = dark ? 'Light Mode' : 'Dark Mode';
        }
    }
}

// Close Modal Function for Modern Modals
function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('show');
        // Also support old modal style
        modal.style.display = 'none';
    }
}

// Toast Notification System
function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    // Simple icon based on type
    const icon = type === 'success' ? '✓' : '✕';
    
    toast.innerHTML = `
        <span class="toast-icon">${icon}</span>
        <span class="toast-message">${message}</span>
    `;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = 'fadeOut 0.3s ease-out forwards';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Animate number counting
function animateValue(element, start, end, duration) {
    if (end === 0 || end === start) {
        element.textContent = end;
        return;
    }
    
    const range = Math.abs(end - start);
    const increment = end > start ? 1 : -1;
    const minStepTime = 10;
    const maxSteps = 100;
    const stepTime = Math.max(minStepTime, Math.floor(duration / Math.min(range, maxSteps)));
    let current = start;
    
    const timer = setInterval(() => {
        current += increment;
        if ((increment > 0 && current >= end) || (increment < 0 && current <= end)) {
            current = end;
            element.textContent = current;
            clearInterval(timer);
        } else {
            element.textContent = Math.max(0, current);
        }
    }, stepTime);
}

// Loading spinner
function showLoading(element) {
    if (!element) return;
    element.innerHTML = `
        <div class="loading">
            <div class="spinner"></div>
            <div class="loading-text">Loading...</div>
        </div>
    `;
}

// Navigation + dynamic view loading
async function loadView(sectionName) {
    const container = document.getElementById('main-view');
    if (!container) {
        console.error('❌ main-view container not found');
        return false;
    }

    console.log(`🔄 Loading view: ${sectionName}`);
    showLoading(container);

    try {
        // Use absolute path from /static/admin/ to ensure correct resolution on all environments
        // Add cache-busting parameter to prevent stale cached views
        const cacheBuster = new Date().getTime();
        const viewPath = `/static/admin/views/${sectionName}.html?v=${cacheBuster}`;
        console.log(`📂 Fetching view from: ${viewPath}`);
        
        const res = await fetch(viewPath, {
            cache: 'no-store', // Disable caching for view files
            headers: {
                'Cache-Control': 'no-cache, no-store, must-revalidate',
                'Pragma': 'no-cache'
            }
        });
        console.log(`📡 Response status: ${res.status} ${res.statusText}`);
        
        if (!res.ok) {
            throw new Error(`View not found: ${res.status} ${res.statusText}`);
        }
        
        const html = await res.text();
        console.log(`✅ View loaded successfully, content length: ${html.length} bytes`);
        container.innerHTML = html;
        
        // Force a reflow to ensure the content is rendered
        container.offsetHeight;
        
        return true;
    } catch (err) {
        console.error('❌ Error loading view', sectionName, err);
        container.innerHTML = `<div class="loading-text" style="color:red">Error loading view: ${sectionName}<br>Please check console for details.</div>`;
        return false;
    }
}

async function showSection(sectionName) {
    console.log(`🎯 Switching to section: ${sectionName}`);
    
    // Update nav state
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    const activeNav = document.querySelector(`[data-section="${sectionName}"]`);
    if (activeNav) {
        activeNav.classList.add('active');
        console.log(`✅ Nav item activated: ${sectionName}`);
    } else {
        console.warn(`⚠️ No nav item found for section: ${sectionName}`);
    }

    const loaded = await loadView(sectionName);
    if (!loaded) {
        console.error(`❌ Failed to load view: ${sectionName}`);
        return;
    }

    console.log(`📊 Initializing section data: ${sectionName}`);
    
    // Load data / scripts for the section
    if (sectionName === 'dashboard') {
        loadDashboard();
    } else if (sectionName === 'officers') {
        initOfficerFormHandlers();
        loadOfficers();
    } else if (sectionName === 'branches') {
        initBranchFormHandlers();
        loadBranches();
    } else if (sectionName === 'cities') {
        initCityFormHandlers();
        loadCities();
    } else if (sectionName === 'search') {
        initSearchHandlers();
    } else if (sectionName === 'reports') {
        await initAdminReportsSection();
    } else if (sectionName === 'mass-report') {
        // Initialize mass reporting functionality
        if (typeof initMassReporting === 'function') {
            initMassReporting();
        }
    } else if (sectionName === 'chatbot') {
        // Initialize chatbot
        if (typeof initChatbot === 'function') {
            initChatbot();
        }
    }
    
    console.log(`✅ Section loaded: ${sectionName}`);
}

// ─────────────────────────────────────────────
// Dynamic view scripts (views loaded via innerHTML
// do NOT execute their <script> tags).
// ─────────────────────────────────────────────
const _loadedViewScripts = new Set();

function _loadScriptOnce(src) {
    return new Promise((resolve, reject) => {
        if (_loadedViewScripts.has(src)) return resolve(true);
        const s = document.createElement('script');
        s.src = src;
        s.async = true;
        s.onload = () => {
            _loadedViewScripts.add(src);
            resolve(true);
        };
        s.onerror = () => reject(new Error(`Failed to load script: ${src}`));
        document.body.appendChild(s);
    });
}

async function initAdminReportsSection() {
    try {
        // Cache bust to avoid stale JS during development
        const cacheBuster = new Date().getTime();
        await _loadScriptOnce(`/static/admin/js/reports.js?v=${cacheBuster}`);

        if (window.AdminReports && typeof window.AdminReports.init === 'function') {
            window.AdminReports.init();
        } else {
            console.error('AdminReports.init() not found after loading reports.js');
            showToast('Reports failed to initialize (missing script)', 'error');
        }
    } catch (e) {
        console.error('Failed to init admin reports section:', e);
        showToast('Failed to load reports scripts', 'error');
    }
}

document.addEventListener('DOMContentLoaded', () => {
    initSidebar(); // Initialize sidebar toggle

    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const section = item.getAttribute('data-section');
            if (section) {
                showSection(section);
            }
        });
    });

    // Logout handler
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', (e) => {
            e.preventDefault();
            // Clear session
            sessionStorage.clear();
            // Redirect to login
            window.location.href = './login.html';
        });
    }

    // Initialize default view
    showSection('dashboard');
});

// Dashboard
async function loadDashboard() {
    try {
        let stats = null;
        try {
            const response = await fetch(`${API_BASE}/admin/dashboard-stats`);
            if (response.ok) {
                stats = await response.json();
            }
        } catch (e) {
            console.warn('Could not load dashboard statistics from new endpoint:', e);
        }
        
        let officersCount = 0, branchesCount = 0, citiesCount = 0, totalReportsCount = 0;
        
        if (stats && stats.current) {
            officersCount = stats.current.officers;
            branchesCount = stats.current.branches;
            citiesCount = stats.current.cities;
            totalReportsCount = stats.current.reports;
        } else {
            // Fallback if the new API fails
            const [officers, branches, cities] = await Promise.all([
                fetch(`${API_BASE}/officers`).then(r => r.json()),
                fetch(`${API_BASE}/branches`).then(r => r.json()),
                fetch(`${API_BASE}/cities`).then(r => r.json())
            ]);
            let reportsData = { total_reports: 0 };
            try {
                reportsData = await fetch(`${API_BASE}/admin/reports/statistics`).then(r => r.json());
            } catch (e) {}
            
            officersCount = Array.isArray(officers) ? officers.length : 0;
            branchesCount = Array.isArray(branches) ? branches.length : 0;
            citiesCount = Array.isArray(cities) ? cities.length : 0;
            totalReportsCount = reportsData.total_reports || 0;
        }
        
        // Animate numbers
        const officersEl = document.getElementById('stat-officers');
        const branchesEl = document.getElementById('stat-branches');
        const citiesEl = document.getElementById('stat-cities');
        const reportsEl = document.getElementById('stat-reports');
        
        if (officersEl) animateValue(officersEl, 0, Math.max(0, officersCount), 1000);
        if (branchesEl) animateValue(branchesEl, 0, Math.max(0, branchesCount), 1000);
        if (citiesEl) animateValue(citiesEl, 0, Math.max(0, citiesCount), 1000);
        if (reportsEl) animateValue(reportsEl, 0, Math.max(0, totalReportsCount), 1000);
        
        // Update trend percentages
        if (typeof window.updateDashboardTrends === 'function') {
            if (stats && stats.previous) {
                window.updateDashboardTrends(stats.current, stats.previous);
            } else {
                // Pass current as previous to show neutral if fallback
                window.updateDashboardTrends(
                    { officers: officersCount, branches: branchesCount, cities: citiesCount, reports: totalReportsCount },
                    { officers: officersCount, branches: branchesCount, cities: citiesCount, reports: totalReportsCount }
                );
            }
        }
        
        // Update dashboard time
        updateDashboardTime();
    } catch (error) {
        console.error('Error loading dashboard:', error);
        showToast('Error loading dashboard data', 'error');
    }
}

// Update time immediately and every minute
function updateDashboardTime() {
    const timeElement = document.getElementById('current-time');
    if (timeElement) {
        const now = new Date();
        const options = { 
            weekday: 'short', 
            year: 'numeric', 
            month: 'short', 
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        };
        timeElement.textContent = now.toLocaleDateString('en-US', options);
    }
}
setInterval(updateDashboardTime, 60000);

// Calculate and update trend percentages
function updateTrendPercentage(elementId, current, previous) {
    const element = document.getElementById(elementId);
    if (!element) return;
    
    if (previous === 0) {
        if (current > 0) {
            element.innerHTML = '↑ 100%';
            element.className = 'trend-indicator positive';
        } else {
            element.innerHTML = '— 0%';
            element.className = 'trend-indicator neutral';
        }
        return;
    }
    
    const percentChange = Math.round(((current - previous) / previous) * 100);
    const absChange = Math.abs(percentChange);
    
    if (percentChange > 0) {
        element.innerHTML = `↑ ${absChange}%`;
        element.className = 'trend-indicator positive';
    } else if (percentChange < 0) {
        element.innerHTML = `↓ ${absChange}%`;
        element.className = 'trend-indicator negative';
    } else {
        element.innerHTML = '— 0%';
        element.className = 'trend-indicator neutral';
    }
}

// Enhanced dashboard load with trend calculation
window.updateDashboardTrends = function(current, previous) {
    if (previous) {
        updateTrendPercentage('trend-officers', current.officers, previous.officers);
        updateTrendPercentage('trend-branches', current.branches, previous.branches);
        updateTrendPercentage('trend-cities', current.cities, previous.cities);
        updateTrendPercentage('trend-reports', current.reports, previous.reports);
    } else {
        // First time or recent data - show neutral
        ['trend-officers', 'trend-branches', 'trend-cities', 'trend-reports'].forEach(id => {
            const element = document.getElementById(id);
            if (element) {
                element.innerHTML = '— New';
                element.className = 'trend-indicator neutral';
            }
        });
    }
};

// Officers
let officersData = [];
let branchesData = [];
let citiesData = [];

// Make data globally accessible for view scripts
window.officersData = officersData;
window.branchesData = branchesData;
window.citiesData = citiesData;

async function loadOfficers() {
    console.log('📋 loadOfficers() called');
    const tbody = document.getElementById('officers-tbody');
    if (!tbody) {
        console.warn('loadOfficers: officers tbody element not found. Make sure the Officers view is loaded.');
        return;
    }
    showLoading(tbody);
    
    try {
        console.log('🔄 Fetching officers and branches data...');
        // Load both officers and branches data in parallel
        const [officersResponse, branchesResponse] = await Promise.all([
            fetch(`${API_BASE}/officers`),
            fetch(`${API_BASE}/branches`)
        ]);
        
        officersData = await officersResponse.json();
        branchesData = await branchesResponse.json();
        
        console.log('📊 Data loaded:', { 
            officers: officersData.length, 
            branches: branchesData.length 
        });
        
        // Update window references for view scripts
        window.officersData = officersData;
        window.branchesData = branchesData;
        
        // Now display officers (branches data is already loaded)
        displayOfficers();
        
        // Update the branch select dropdown
        updateBranchSelect();
    } catch (error) {
        console.error('Error loading officers:', error);
        tbody.innerHTML = '<tr><td colspan="7">Error loading officers</td></tr>';
        showToast('Error loading officers', 'error');
    }
}

function displayOfficers() {
    console.log('🖼️ displayOfficers() called, data count:', officersData.length);
    const tbody = document.getElementById('officers-tbody');
    if (officersData.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7">No officers found</td></tr>';
        return;
    }

    tbody.innerHTML = officersData.map(officer => {
        const branch = branchesData.find(b => b.id === officer.branch_id);
        return `
            <tr>
                <td>${officer.id}</td>
                <td>${officer.first_name} ${officer.last_name}</td>
                <td>${officer.email}</td>
                <td>${officer.phone_no}</td>
                <td>${branch ? branch.branch_name : 'N/A'}</td>
                <td><span class="status-badge ${officer.is_active ? 'status-active' : 'status-inactive'}">${officer.is_active ? 'Active' : 'Inactive'}</span></td>
                <td>
                    <button class="btn btn-sm btn-primary" onclick="editOfficer(${officer.id})">Edit</button>
                    <button class="btn btn-sm btn-danger margin-left-sm" onclick="deleteOfficer(${officer.id})" style="margin-left: 8px;">Delete</button>
                </td>
            </tr>
        `;
    }).join('');
    
    console.log('📋 Table rendered, calling updateOfficerCounts()...');
    // Update mini stats directly
    updateOfficerCounts();
}

function updateOfficerCounts() {
    console.log('📊 updateOfficerCounts() called');
    console.log('   - officersData:', officersData);
    console.log('   - Is array?', Array.isArray(officersData));
    
    if (officersData && Array.isArray(officersData)) {
        const total = officersData.length;
        const active = officersData.filter(o => o.is_active).length;
        const inactive = total - active;
        
        const totalEl = document.getElementById('total-officers-count');
        const activeEl = document.getElementById('active-officers-count');
        const inactiveEl = document.getElementById('inactive-officers-count');
        
        if (totalEl) totalEl.textContent = total;
        if (activeEl) activeEl.textContent = active;
        if (inactiveEl) inactiveEl.textContent = inactive;
        
        console.log('✅ Officer stats updated:', { total, active, inactive });
    }
}

function updateBranchSelect() {
    const select = document.getElementById('officer-branch-id');
    if (select) {
        select.innerHTML = '<option value="">Select Branch</option>' + 
            branchesData.map(b => `<option value="${b.id}">${b.branch_name}</option>`).join('');
    }
    const exportSelect = document.getElementById('export-officer-branch');
    if (exportSelect) {
        exportSelect.innerHTML = '<option value="">All Branches</option>' + 
            branchesData.map(b => `<option value="${b.id}">${b.branch_name}</option>`).join('');
    }
}

async function loadBranchesForSelect() {
    try {
        const response = await fetch(`${API_BASE}/branches`);
        branchesData = await response.json();
        updateBranchSelect();
    } catch (error) {
        console.error('Error loading branches:', error);
    }
}

// ========================================
// UNIFIED REPORTS MODAL
// ========================================

let currentReportData = [];
let currentSortCol = null;
let currentSortAsc = true;

function handleSort(column) {
    if (currentSortCol === column) {
        currentSortAsc = !currentSortAsc;
    } else {
        currentSortCol = column;
        currentSortAsc = true;
    }
    
    currentReportData.sort((a, b) => {
        let valA, valB;
        const type = document.getElementById('report-type-select').value;
        
        if (type === 'cities') {
            if (column === 'ID') { valA = a.id; valB = b.id; }
            else if (column === 'City Name') { valA = a.city_name; valB = b.city_name; }
            else if (column === 'Branches') { valA = a.branch_count || 0; valB = b.branch_count || 0; }
            else if (column === 'Status') { valA = a.is_active ? 1 : 0; valB = b.is_active ? 1 : 0; }
        } else if (type === 'branches') {
            if (column === 'ID') { valA = a.id; valB = b.id; }
            else if (column === 'Branch Name') { valA = a.branch_name; valB = b.branch_name; }
            else if (column === 'Pincode') { valA = a.pincode; valB = b.pincode; }
            else if (column === 'Officers') { valA = a.officer_count || 0; valB = b.officer_count || 0; }
            else if (column === 'Status') { valA = a.is_active ? 1 : 0; valB = b.is_active ? 1 : 0; }
        } else if (type === 'officers') {
            if (column === 'ID') { valA = a.id; valB = b.id; }
            else if (column === 'Name') { valA = (a.first_name + ' ' + a.last_name); valB = (b.first_name + ' ' + b.last_name); }
            else if (column === 'Email') { valA = a.email; valB = b.email; }
            else if (column === 'Phone') { valA = a.phone_no; valB = b.phone_no; }
            else if (column === 'Status') { valA = a.is_active ? 1 : 0; valB = b.is_active ? 1 : 0; }
        } else if (type === 'login-logs') {
            if (column === 'Log ID') { valA = a.id; valB = b.id; }
            else if (column === 'Officer ID') { 
                const oA = officersData.find(off => off.id === a.officer_id);
                const oB = officersData.find(off => off.id === b.officer_id);
                valA = oA ? `${oA.first_name} ${oA.last_name}` : `Officer #${a.officer_id}`;
                valB = oB ? `${oB.first_name} ${oB.last_name}` : `Officer #${b.officer_id}`;
            }
            else if (column === 'Login Time') { valA = new Date(a.loggedin_at).getTime(); valB = new Date(b.loggedin_at).getTime(); }
        } else if (type === 'mass-reports') {
            if (column === 'ID') { valA = a.id; valB = b.id; }
            else if (column === 'Officer') { valA = a.officer_name; valB = b.officer_name; }
            else if (column === 'Platform') { valA = a.platform; valB = b.platform; }
            else if (column === 'Target User') { valA = a.target_username; valB = b.target_username; }
            else if (column === 'Status') { valA = a.status; valB = b.status; }
            else if (column === 'Report Date') { valA = new Date(a.reported_at).getTime(); valB = new Date(b.reported_at).getTime(); }
        }
        
        if (typeof valA === 'string') valA = valA.toLowerCase();
        if (typeof valB === 'string') valB = valB.toLowerCase();
        
        if (valA < valB) return currentSortAsc ? -1 : 1;
        if (valA > valB) return currentSortAsc ? 1 : -1;
        return 0;
    });
    
    renderReportTable();
}

function renderReportTable() {
    const type = document.getElementById('report-type-select').value;
    const tbody = document.getElementById('report-preview-tbody');
    const thead = document.getElementById('report-preview-thead');
    
    if (!currentReportData || currentReportData.length === 0) {
        tbody.innerHTML = '<tr><td colspan="100%" class="text-center" style="padding: 32px 0;">No records found for this criteria.</td></tr>';
        thead.innerHTML = '';
        return;
    }

    const renderHeader = (colName) => {
        let icon = `<svg style="width:14px;height:14px;opacity:0.3;margin-left:4px;" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4"/></svg>`;
        if (currentSortCol === colName) {
            if (currentSortAsc) {
                icon = `<svg style="width:14px;height:14px;color:#3b82f6;margin-left:4px;" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 15l7-7 7 7"/></svg>`;
            } else {
                icon = `<svg style="width:14px;height:14px;color:#3b82f6;margin-left:4px;" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>`;
            }
        }
        return `<th onclick="handleSort('${colName}')" style="cursor:pointer; user-select:none; white-space:nowrap; transition: background-color 0.2s;" onmouseover="this.style.backgroundColor='rgba(0,0,0,0.05)'" onmouseout="this.style.backgroundColor='transparent'">
            <div style="display:flex; align-items:center;">${colName}${icon}</div>
        </th>`;
    };

    if (type === 'cities') {
        thead.innerHTML = `<tr>
            ${renderHeader('ID')}
            ${renderHeader('City Name')}
            ${renderHeader('Branches')}
            ${renderHeader('Status')}
        </tr>`;
        tbody.innerHTML = currentReportData.map(c => `<tr>
            <td>${c.id}</td>
            <td>${c.city_name}</td>
            <td>${c.branch_count || 0}</td>
            <td><span class="status-badge ${c.is_active ? 'status-active' : 'status-inactive'}">${c.is_active ? 'Active' : 'Inactive'}</span></td>
        </tr>`).join('');
    } else if (type === 'branches') {
        thead.innerHTML = `<tr>
            ${renderHeader('ID')}
            ${renderHeader('Branch Name')}
            ${renderHeader('Pincode')}
            ${renderHeader('Officers')}
            ${renderHeader('Status')}
        </tr>`;
        tbody.innerHTML = currentReportData.map(b => `<tr>
            <td>${b.id}</td>
            <td>${b.branch_name}</td>
            <td>${b.pincode}</td>
            <td>${b.officer_count || 0}</td>
            <td><span class="status-badge ${b.is_active ? 'status-active' : 'status-inactive'}">${b.is_active ? 'Active' : 'Inactive'}</span></td>
        </tr>`).join('');
    } else if (type === 'officers') {
        thead.innerHTML = `<tr>
            ${renderHeader('ID')}
            ${renderHeader('Name')}
            ${renderHeader('Email')}
            ${renderHeader('Phone')}
            ${renderHeader('Status')}
        </tr>`;
        tbody.innerHTML = currentReportData.map(o => `<tr>
            <td>${o.id}</td>
            <td>${o.first_name} ${o.last_name}</td>
            <td>${o.email}</td>
            <td>${o.phone_no}</td>
            <td><span class="status-badge ${o.is_active ? 'status-active' : 'status-inactive'}">${o.is_active ? 'Active' : 'Inactive'}</span></td>
        </tr>`).join('');
    } else if (type === 'login-logs') {
        thead.innerHTML = `<tr>
            ${renderHeader('Log ID')}
            ${renderHeader('Officer ID')}
            ${renderHeader('Login Time')}
            <th>Action</th>
        </tr>`;
        tbody.innerHTML = currentReportData.map(l => {
            const o = officersData.find(off => off.id === l.officer_id);
            const name = o ? `${o.first_name} ${o.last_name}` : `Officer #${l.officer_id}`;
            return `<tr>
                <td>${l.id}</td>
                <td>${name}</td>
                <td>${new Date(l.loggedin_at).toLocaleString()}</td>
                <td><span class="badge badge-success">Success</span></td>
            </tr>`;
        }).join('');
    } else if (type === 'mass-reports') {
        thead.innerHTML = `<tr>
            ${renderHeader('ID')}
            ${renderHeader('Officer')}
            ${renderHeader('Platform')}
            ${renderHeader('Target User')}
            ${renderHeader('Status')}
            ${renderHeader('Report Date')}
        </tr>`;
        tbody.innerHTML = currentReportData.map(r => `<tr>
            <td>${r.id}</td>
            <td>${r.officer_name}</td>
            <td><span class="badge badge-primary" style="text-transform: capitalize;">${r.platform}</span></td>
            <td>${r.target_username}</td>
            <td><span class="status-badge ${r.status === 'Success' ? 'status-active' : 'status-inactive'}">${r.status}</span></td>
            <td>${new Date(r.reported_at).toLocaleString()}</td>
        </tr>`).join('');
    }
}

function openReportModal(type = 'cities') {
    reparentModal('report-modal');
    const modal = document.getElementById('report-modal');
    const typeHidden = document.getElementById('report-type-select');
    const title = document.getElementById('report-modal-display-title');
    
    typeHidden.value = type;
    
    // Set appropriate modal title
    if (title) {
        if (type === 'cities') title.textContent = 'Generate Cities Report';
        else if (type === 'branches') title.textContent = 'Generate Branches Report';
        else if (type === 'officers') title.textContent = 'Generate Officers Report';
        else if (type === 'login-logs') title.textContent = 'Generate Login Logs Report';
        else if (type === 'mass-reports') title.textContent = 'Generate Mass Reports History Report';
        else title.textContent = 'Generate System Report';
    }
    
    // reset filters
    const filterCityStatus = document.getElementById('report-filter-city-status');
    const filterBranchStatus = document.getElementById('report-filter-branch-status');
    const filterCityOfficer = document.getElementById('report-filter-city-officer');
    const filterGender = document.getElementById('report-filter-gender');
    const filterMinAge = document.getElementById('report-filter-min-age');
    const filterMaxAge = document.getElementById('report-filter-max-age');
    const filterSelect = document.getElementById('report-filter-select');
    const filterMassOfficer = document.getElementById('report-filter-mass-officer');
    const filterMassPlatform = document.getElementById('report-filter-mass-platform');
    
    if (filterCityStatus) filterCityStatus.value = '';
    if (filterBranchStatus) filterBranchStatus.value = '';
    if (filterCityOfficer) filterCityOfficer.value = '';
    if (filterGender) filterGender.value = '';
    if (filterMinAge) filterMinAge.value = '';
    if (filterMaxAge) filterMaxAge.value = '';
    if (filterSelect) filterSelect.value = '';
    if (filterMassOfficer) filterMassOfficer.value = '';
    if (filterMassPlatform) filterMassPlatform.value = '';
    
    handleReportTypeChange();
    
    modal.classList.add('show');
    modal.style.display = 'block';
}

function handleReportTypeChange() {
    const type = document.getElementById('report-type-select').value;
    const filterContainer = document.getElementById('report-filter-container');
    const filterLabel = document.getElementById('report-filter-label');
    const filterSelect = document.getElementById('report-filter-select');
    
    const advancedOfficers = document.getElementById('advanced-filters-officers');
    const advancedCities = document.getElementById('advanced-filters-cities');
    const advancedBranches = document.getElementById('advanced-filters-branches');
    const advancedMassReports = document.getElementById('advanced-filters-mass-reports');
    const citySelect = document.getElementById('report-filter-city-officer');
    
    filterContainer.style.display = 'none';
    if (advancedOfficers) advancedOfficers.style.display = 'none';
    if (advancedCities) advancedCities.style.display = 'none';
    if (advancedBranches) advancedBranches.style.display = 'none';
    if (advancedMassReports) advancedMassReports.style.display = 'none';
    filterSelect.innerHTML = '<option value="">All</option>';
    
    // Depending on type, configure secondary filters
    if (type === 'cities') {
        if (advancedCities) advancedCities.style.display = 'block';
    } else if (type === 'branches') {
        filterContainer.style.display = 'block';
        filterLabel.textContent = 'Filter by City';
        citiesData.forEach(c => {
            filterSelect.innerHTML += `<option value="${c.id}">${c.city_name}</option>`;
        });
        if (advancedBranches) advancedBranches.style.display = 'block';
    } else if (type === 'officers') {
        filterContainer.style.display = 'block';
        filterLabel.textContent = 'Filter by Branch';
        branchesData.forEach(b => {
            filterSelect.innerHTML += `<option value="${b.id}">${b.branch_name}</option>`;
        });
        if (advancedOfficers) advancedOfficers.style.display = 'block';
        if (citySelect) {
            citySelect.innerHTML = '<option value="">All Cities</option>';
            citiesData.forEach(c => {
                citySelect.innerHTML += `<option value="${c.id}">${c.city_name}</option>`;
            });
        }
    } else if (type === 'login-logs') {
        filterContainer.style.display = 'block';
        filterLabel.textContent = 'Filter by Officer';
        officersData.forEach(o => {
            filterSelect.innerHTML += `<option value="${o.id}">${o.first_name} ${o.last_name}</option>`;
        });
    } else if (type === 'mass-reports') {
        filterContainer.style.display = 'none';
        if (advancedMassReports) {
            advancedMassReports.style.display = 'block';
            const massOfficerSelect = document.getElementById('report-filter-mass-officer');
            if (massOfficerSelect) {
                massOfficerSelect.innerHTML = '<option value="">All Officers</option>';
                officersData.forEach(o => {
                    massOfficerSelect.innerHTML += `<option value="${o.id}">${o.first_name} ${o.last_name}</option>`;
                });
            }
        }
    }
    
    runReportPreview();
}

async function runReportPreview() {
    const type = document.getElementById('report-type-select').value;
    const filterId = document.getElementById('report-filter-select').value;
    const tbody = document.getElementById('report-preview-tbody');
    const thead = document.getElementById('report-preview-thead');
    
    tbody.innerHTML = '<tr><td colspan="100%" class="loading-cell text-center" style="padding: 32px 0;">Loading preview data...</td></tr>';
    
    try {
        let url = '';
        if (type === 'cities') {
            const cityStatus = document.getElementById('report-filter-city-status')?.value;
            url = `${API_BASE}/cities${cityStatus ? '?is_active=' + cityStatus : ''}`;
        } else if (type === 'branches') {
            const branchStatus = document.getElementById('report-filter-branch-status')?.value;
            let params = new URLSearchParams();
            if (filterId) params.append('city_id', filterId);
            if (branchStatus) params.append('is_active', branchStatus);
            url = `${API_BASE}/branches${params.toString() ? '?' + params.toString() : ''}`;
        } else if (type === 'officers') {
            let params = new URLSearchParams();
            if (filterId) params.append('branch_id', filterId);
            const cityId = document.getElementById('report-filter-city-officer')?.value;
            const gender = document.getElementById('report-filter-gender')?.value;
            const minAge = document.getElementById('report-filter-min-age')?.value;
            const maxAge = document.getElementById('report-filter-max-age')?.value;
            if (cityId) params.append('city_id', cityId);
            if (gender) params.append('gender', gender);
            if (minAge) params.append('min_age', minAge);
            if (maxAge) params.append('max_age', maxAge);
            url = `${API_BASE}/officers${params.toString() ? '?' + params.toString() : ''}`;
        } else if (type === 'login-logs') {
            url = filterId ? `${API_BASE}/officers/${filterId}/login-log` : `${API_BASE}/officers/reports/login-logs`;
        } else if (type === 'mass-reports') {
            let params = new URLSearchParams();
            params.append('page_size', '1000');
            const massOfficerId = document.getElementById('report-filter-mass-officer')?.value;
            const massPlatform = document.getElementById('report-filter-mass-platform')?.value;
            if (massOfficerId) params.append('officer_id', massOfficerId);
            if (massPlatform) params.append('social_media', massPlatform);
            url = `${API_BASE}/mass-report/history?${params.toString()}`;
        }

        const response = await fetch(url);
        if (!response.ok) throw new Error('Failed to fetch report data');
        const data = await response.json();
        currentReportData = data.results || data;
        
        currentSortCol = null;
        currentSortAsc = true;
        
        let defaultCol = 'ID';
        if (type === 'login-logs') defaultCol = 'Log ID';
        handleSort(defaultCol);
        
    } catch (err) {
        console.error(err);
        tbody.innerHTML = '<tr><td colspan="100%" class="text-center text-danger" style="padding: 32px 0;">Error loading report data.</td></tr>';
    }
}

function exportCurrentReport() {
    const type = document.getElementById('report-type-select').value;
    if (!currentReportData || currentReportData.length === 0) {
        showToast('No data to export', 'error');
        return;
    }
    
    let csvContent = "";
    
    if (type === 'cities') {
        csvContent = ["ID", "City Name", "Branches Count", "Status"].join(",") + "\n" + 
            currentReportData.map(c => [c.id, `"${c.city_name}"`, (c.branch_count || 0), c.is_active ? 'Active' : 'Inactive'].join(",")).join("\n");
    } else if (type === 'branches') {
        csvContent = ["ID", "Branch Name", "City ID", "Pincode", "Officers Count", "Status"].join(",") + "\n" + 
            currentReportData.map(b => [b.id, `"${b.branch_name}"`, b.city_id, b.pincode, (b.officer_count || 0), b.is_active ? 'Active' : 'Inactive'].join(",")).join("\n");
    } else if (type === 'officers') {
        csvContent = ["ID", "Name", "Email", "Phone", "Branch ID", "Status"].join(",") + "\n" + 
            currentReportData.map(o => [o.id, `"${o.first_name} ${o.last_name}"`, o.email, o.phone_no, o.branch_id, o.is_active ? 'Active' : 'Inactive'].join(",")).join("\n");
    } else if (type === 'login-logs') {
        csvContent = ["Log ID", "Officer Name", "Officer ID", "Login Time"].join(",") + "\n" + 
            currentReportData.map(l => {
                const o = officersData.find(off => off.id === l.officer_id);
                const name = o ? `${o.first_name} ${o.last_name}` : `Officer #${l.officer_id}`;
                return [l.id, `"${name}"`, l.officer_id, `"${new Date(l.loggedin_at).toLocaleString()}"`].join(",");
            }).join("\n");
    } else if (type === 'mass-reports') {
        csvContent = ["ID", "Officer Name", "Original Query", "Target Platform", "Target Username", "Status", "System Message", "Date"].join(",") + "\n" + 
            currentReportData.map(r => [
                r.id, 
                `"${r.officer_name}"`, 
                `"${(r.search_query || '').replace(/"/g, '""')}"`, 
                r.platform, 
                `"${r.target_username}"`, 
                r.status, 
                `"${(r.message || '').replace(/"/g, '""')}"`, 
                `"${new Date(r.reported_at).toLocaleString()}"`
            ].join(",")).join("\n");
    }
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const encodedUri = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `${type}_report_${new Date().getTime()}.csv`);
    document.body.appendChild(link);
    link.click();
    link.remove();
}

// Helper to move modal to body to ensure it's not trapped in overflow/transform contexts
function reparentModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal && modal.parentElement !== document.body) {
        document.body.appendChild(modal);
    }
}

function showOfficerModal(officerId = null) {
    reparentModal('officer-modal');
    const modal = document.getElementById('officer-modal');
    const form = document.getElementById('officer-form');
    const title = document.getElementById('officer-modal-title');
    
    if (officerId) {
        const officer = officersData.find(o => o.id === officerId);
        if (officer) {
            title.textContent = 'Edit Officer';
            document.getElementById('officer-id').value = officer.id;
            document.getElementById('officer-branch-id').value = officer.branch_id;
            document.getElementById('officer-first-name').value = officer.first_name;
            document.getElementById('officer-last-name').value = officer.last_name;
            document.getElementById('officer-gender').value = officer.gender;
            document.getElementById('officer-dob').value = officer.dob;
            document.getElementById('officer-phone').value = officer.phone_no;
            document.getElementById('officer-email').value = officer.email;
            document.getElementById('officer-password').required = false;
            document.getElementById('officer-is-active').checked = officer.is_active;
        }
    } else {
        title.textContent = 'Add Officer';
        form.reset();
        document.getElementById('officer-id').value = '';
        document.getElementById('officer-password').required = true;
    }
    
    modal.classList.add('show');
    modal.style.display = 'block';
}

function initOfficerFormHandlers() {
    const form = document.getElementById('officer-form');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        // Get form values
        const branchId = document.getElementById('officer-branch-id').value;
        const firstName = document.getElementById('officer-first-name').value.trim();
        const lastName = document.getElementById('officer-last-name').value.trim();
        const gender = document.getElementById('officer-gender').value;
        const dob = document.getElementById('officer-dob').value;
        const phoneNo = document.getElementById('officer-phone').value.trim();
        const email = document.getElementById('officer-email').value.trim();
        const isActive = document.getElementById('officer-is-active').checked;
        const password = document.getElementById('officer-password').value;
        const officerId = document.getElementById('officer-id').value;

        // Validate required fields
        if (!branchId || !firstName || !lastName || !gender || !dob || !phoneNo || !email) {
            showToast('Please fill in all required fields', 'error');
            return;
        }

        if (!officerId && !password) {
            showToast('Password is required for new officers', 'error');
            return;
        }

        // Build form data
        const formData = {
            branch_id: parseInt(branchId),
            first_name: firstName,
            last_name: lastName,
            gender: gender,
            dob: dob, // Send as YYYY-MM-DD string (HTML date input format)
            phone_no: phoneNo,
            email: email,
            is_active: isActive
        };

        // Log the data being sent for debugging
        console.log('Submitting officer data:', { ...formData, password: password ? '***' : undefined });

        try {
            let response;
            if (officerId) {
                const updateData = { ...formData };
                if (password) updateData.password = password;
                response = await fetch(`${API_BASE}/officers/${officerId}`, {
                    method: 'PATCH',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(updateData)
                });
            } else {
                response = await fetch(`${API_BASE}/officers/`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ ...formData, password })
                });
            }

            if (response.ok) {
                closeModal('officer-modal');
                showToast(officerId ? 'Officer updated successfully!' : 'Officer created successfully!', 'success');
                loadOfficers();
                if (!officerId) loadDashboard();
            } else {
                const error = await response.json();
                console.error('API Error Response:', error);
                
                // Handle validation errors
                let errorMessage = 'Failed to save officer';
                if (error.detail) {
                    if (Array.isArray(error.detail)) {
                        // Pydantic validation errors
                        errorMessage = error.detail.map(err => {
                            const field = err.loc ? err.loc.join('.') : 'unknown';
                            return `${field}: ${err.msg}`;
                        }).join(', ');
                    } else if (typeof error.detail === 'string') {
                        errorMessage = error.detail;
                    } else {
                        errorMessage = JSON.stringify(error.detail);
                    }
                }
                
                showToast('Error: ' + errorMessage, 'error');
            }
        } catch (error) {
            console.error('Error saving officer:', error);
            showToast('Error saving officer: ' + error.message, 'error');
        }
    });
}

function editOfficer(id) {
    showOfficerModal(id);
}

async function deleteOfficer(id) {
    if (!confirm('🛑 WARNING: Are you sure you want to delete this officer?\\n\\nThis will PERMANENTLY DELETE all login and activity logs associated with this officer! This action cannot be undone.')) return;
    try {
        const response = await fetch(`${API_BASE}/officers/${id}`, { method: 'DELETE' });
        if (response.ok) {
            showToast('Officer deleted successfully', 'success');
            loadOfficers();
            loadDashboard();
        } else {
            const data = await response.json().catch(() => ({}));
            showToast(data.detail || 'Error deleting officer', 'error');
        }
    } catch (e) {
        showToast('Error deleting officer', 'error');
    }
}

async function exportOfficers() {
    const branchId = document.getElementById('export-officer-branch')?.value || '';
    const url = branchId ? `${API_BASE}/officers?branch_id=${branchId}` : `${API_BASE}/officers`;
    try {
        const response = await fetch(url);
        const data = await response.json();
        
        let headerRow = ["ID", "Name", "Email", "Phone", "Branch", "Status"];
        let csvContent = headerRow.join(",") + "\\n" + data.map(o => {
            const branch = branchesData.find(b => b.id === o.branch_id);
            const branchName = branch ? branch.branch_name : 'N/A';
            return [o.id, `"${o.first_name} ${o.last_name}"`, o.email, o.phone_no, `"${branchName}"`, o.is_active ? 'Active' : 'Inactive'].join(",");
        }).join("\\n");
        
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const encodedUri = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "officers.csv");
        document.body.appendChild(link);
        link.click();
        link.remove();
    } catch (e) {
        showToast('Error exporting officers', 'error');
    }
}

// Branches
async function loadBranches() {
    const tbody = document.getElementById('branches-tbody');
    if (!tbody) {
        console.warn('loadBranches: branches tbody element not found. Make sure the Branches view is loaded.');
        return;
    }
    showLoading(tbody);
    
    try {
        // Load both branches and cities data in parallel
        const [branchesResponse, citiesResponse] = await Promise.all([
            fetch(`${API_BASE}/branches`),
            fetch(`${API_BASE}/cities`)
        ]);
        
        branchesData = await branchesResponse.json();
        citiesData = await citiesResponse.json();
        
        // Update window references for view scripts
        window.branchesData = branchesData;
        window.citiesData = citiesData;
        
        // Now display branches (cities data is already loaded)
        displayBranches();
        
        // Update the city select dropdown
        updateCitySelect();
    } catch (error) {
        console.error('Error loading branches:', error);
        tbody.innerHTML = '<tr><td colspan="6">Error loading branches</td></tr>';
        showToast('Error loading branches', 'error');
    }
}

function displayBranches() {
    const tbody = document.getElementById('branches-tbody');
    if (branchesData.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6">No branches found</td></tr>';
        return;
    }

    tbody.innerHTML = branchesData.map(branch => {
        const city = citiesData.find(c => c.id === branch.city_id);
        return `
            <tr>
                <td>${branch.id}</td>
                <td>${branch.branch_name}</td>
                <td>${city ? city.city_name : 'N/A'}</td>
                <td>${branch.pincode}</td>
                <td><span class="badge badge-info">${branch.officer_count || 0}</span></td>
                <td><span class="status-badge ${branch.is_active ? 'status-active' : 'status-inactive'}">${branch.is_active ? 'Active' : 'Inactive'}</span></td>
                <td>
                    <button class="btn btn-sm btn-primary" onclick="editBranch(${branch.id})">Edit</button>
                    <button class="btn btn-sm btn-danger margin-left-sm" onclick="deleteBranch(${branch.id})" style="margin-left: 8px;">Delete</button>
                </td>
            </tr>
        `;
    }).join('');
    
    // Update mini stats directly
    updateBranchCounts();
}

function updateBranchCounts() {
    if (branchesData && Array.isArray(branchesData)) {
        const total = branchesData.length;
        const active = branchesData.filter(b => b.is_active).length;
        const inactive = total - active;
        
        const totalEl = document.getElementById('total-branches-count');
        const activeEl = document.getElementById('active-branches-count');
        const inactiveEl = document.getElementById('inactive-branches-count');
        
        if (totalEl) totalEl.textContent = total;
        if (activeEl) activeEl.textContent = active;
        if (inactiveEl) inactiveEl.textContent = inactive;
        
        console.log('✅ Branch stats updated:', { total, active, inactive });
    }
}

function updateCitySelect() {
    const select = document.getElementById('branch-city-id');
    if (select) {
        select.innerHTML = '<option value="">Select City</option>' + 
            citiesData.map(c => `<option value="${c.id}">${c.city_name}</option>`).join('');
    }
    const exportSelect = document.getElementById('export-branch-city');
    if (exportSelect) {
        exportSelect.innerHTML = '<option value="">All Cities</option>' + 
            citiesData.map(c => `<option value="${c.id}">${c.city_name}</option>`).join('');
    }
}

async function loadCitiesForSelect() {
    try {
        const response = await fetch(`${API_BASE}/cities`);
        citiesData = await response.json();
        updateCitySelect();
    } catch (error) {
        console.error('Error loading cities:', error);
    }
}

function showBranchModal(branchId = null) {
    reparentModal('branch-modal');
    const modal = document.getElementById('branch-modal');
    const form = document.getElementById('branch-form');
    const title = document.getElementById('branch-modal-title');
    
    if (branchId) {
        const branch = branchesData.find(b => b.id === branchId);
        if (branch) {
            title.textContent = 'Edit Branch';
            document.getElementById('branch-id').value = branch.id;
            document.getElementById('branch-city-id').value = branch.city_id;
            document.getElementById('branch-name').value = branch.branch_name;
            document.getElementById('branch-pincode').value = branch.pincode;
            document.getElementById('branch-is-active').checked = branch.is_active;
        }
    } else {
        title.textContent = 'Add Branch';
        form.reset();
        document.getElementById('branch-id').value = '';
    }
    
    modal.classList.add('show');
    modal.style.display = 'block';
}

function initBranchFormHandlers() {
    const form = document.getElementById('branch-form');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = {
            city_id: parseInt(document.getElementById('branch-city-id').value),
            branch_name: document.getElementById('branch-name').value,
            pincode: parseInt(document.getElementById('branch-pincode').value),
            is_active: document.getElementById('branch-is-active').checked
        };

        const branchId = document.getElementById('branch-id').value;

        try {
            let response;
            if (branchId) {
                response = await fetch(`${API_BASE}/branches/${branchId}`, {
                    method: 'PATCH',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(formData)
                });
            } else {
                response = await fetch(`${API_BASE}/branches`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(formData)
                });
            }

            if (response.ok) {
                closeModal('branch-modal');
                showToast(branchId ? 'Branch updated successfully!' : 'Branch created successfully!', 'success');
                loadBranches();
                if (!branchId) loadDashboard();
            } else {
                const error = await response.json();
                showToast('Error: ' + (error.detail || 'Failed to save branch'), 'error');
            }
        } catch (error) {
            console.error('Error saving branch:', error);
            showToast('Error saving branch', 'error');
        }
    });
}

function editBranch(id) {
    showBranchModal(id);
}

async function deleteBranch(id) {
    if (!confirm('🛑 WARNING: Are you sure you want to delete this branch?\\n\\nThis will PERMANENTLY DELETE all officers and their logs associated with this branch! This action cannot be undone.')) return;
    try {
        const response = await fetch(`${API_BASE}/branches/${id}`, { method: 'DELETE' });
        if (response.ok) {
            showToast('Branch deleted successfully', 'success');
            loadBranches();
            loadDashboard();
        } else {
            const data = await response.json().catch(() => ({}));
            showToast(data.detail || 'Error deleting branch', 'error');
        }
    } catch (e) {
        showToast('Error deleting branch', 'error');
    }
}

async function exportBranches() {
    const cityId = document.getElementById('export-branch-city')?.value || '';
    const url = cityId ? `${API_BASE}/branches?city_id=${cityId}` : `${API_BASE}/branches`;
    try {
        const response = await fetch(url);
        const data = await response.json();
        
        let headerRow = ["ID", "Branch Name", "City", "Pincode", "Status"];
        let csvContent = headerRow.join(",") + "\\n" + data.map(b => {
            const city = citiesData.find(c => c.id === b.city_id);
            const cityName = city ? city.city_name : 'N/A';
            return [b.id, `"${b.branch_name}"`, `"${cityName}"`, b.pincode, b.is_active ? 'Active' : 'Inactive'].join(",");
        }).join("\\n");
        
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const encodedUri = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "branches.csv");
        document.body.appendChild(link);
        link.click();
        link.remove();
    } catch (e) {
        showToast('Error exporting branches', 'error');
    }
}

// Cities
async function loadCities() {
    const tbody = document.getElementById('cities-tbody');
    if (!tbody) {
        console.warn('loadCities: cities tbody element not found. Make sure the Cities view is loaded.');
        return;
    }
    showLoading(tbody);
    
    try {
        const response = await fetch(`${API_BASE}/cities`);
        citiesData = await response.json();
        
        // Update window reference for view scripts
        window.citiesData = citiesData;
        
        displayCities();
    } catch (error) {
        console.error('Error loading cities:', error);
        tbody.innerHTML = '<tr><td colspan="4">Error loading cities</td></tr>';
        showToast('Error loading cities', 'error');
    }
}

function displayCities() {
    const tbody = document.getElementById('cities-tbody');
    if (citiesData.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4">No cities found</td></tr>';
        return;
    }

    tbody.innerHTML = citiesData.map(city => `
        <tr>
            <td>${city.id}</td>
            <td>${city.city_name}</td>
            <td><span class="badge badge-info">${city.branch_count || 0}</span></td>
            <td><span class="status-badge ${city.is_active ? 'status-active' : 'status-inactive'}">${city.is_active ? 'Active' : 'Inactive'}</span></td>
            <td>
                <button class="btn btn-sm btn-primary" onclick="editCity(${city.id})">Edit</button>
                <button class="btn btn-sm btn-danger margin-left-sm" onclick="deleteCity(${city.id})" style="margin-left: 8px;">Delete</button>
            </td>
        </tr>
    `).join('');
    
    // Update mini stats directly
    updateCityCounts();
}

function updateCityCounts() {
    if (citiesData && Array.isArray(citiesData)) {
        const total = citiesData.length;
        const active = citiesData.filter(c => c.is_active).length;
        const inactive = total - active;
        
        const totalEl = document.getElementById('total-cities-count');
        const activeEl = document.getElementById('active-cities-count');
        const inactiveEl = document.getElementById('inactive-cities-count');
        
        if (totalEl) totalEl.textContent = total;
        if (activeEl) activeEl.textContent = active;
        if (inactiveEl) inactiveEl.textContent = inactive;
        
        console.log('✅ City stats updated:', { total, active, inactive });
    }
}

function showCityModal(cityId = null) {
    reparentModal('city-modal');
    const modal = document.getElementById('city-modal');
    const form = document.getElementById('city-form');
    const title = document.getElementById('city-modal-title');
    
    if (cityId) {
        const city = citiesData.find(c => c.id === cityId);
        if (city) {
            title.textContent = 'Edit City';
            document.getElementById('city-id').value = city.id;
            document.getElementById('city-name').value = city.city_name;
            document.getElementById('city-is-active').checked = city.is_active;
        }
    } else {
        title.textContent = 'Add City';
        form.reset();
        document.getElementById('city-id').value = '';
    }
    
    modal.classList.add('show');
    modal.style.display = 'block';
}

function initCityFormHandlers() {
    const form = document.getElementById('city-form');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = {
            city_name: document.getElementById('city-name').value,
            is_active: document.getElementById('city-is-active').checked
        };

        const cityId = document.getElementById('city-id').value;

        try {
            let response;
            if (cityId) {
                response = await fetch(`${API_BASE}/cities/${cityId}`, {
                    method: 'PATCH',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(formData)
                });
            } else {
                response = await fetch(`${API_BASE}/cities`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(formData)
                });
            }

            if (response.ok) {
                closeModal('city-modal');
                showToast(cityId ? 'City updated successfully!' : 'City created successfully!', 'success');
                loadCities();
                if (!cityId) loadDashboard();
            } else {
                const error = await response.json();
                showToast('Error: ' + (error.detail || 'Failed to save city'), 'error');
            }
        } catch (error) {
            console.error('Error saving city:', error);
            showToast('Error saving city', 'error');
        }
    });
}

function editCity(id) {
    showCityModal(id);
}

async function deleteCity(id) {
    if (!confirm('🛑 WARNING: Are you sure you want to delete this city?\\n\\nThis will PERMANENTLY DELETE all associated branches and officers within this city! This action cannot be undone.')) return;
    try {
        const response = await fetch(`${API_BASE}/cities/${id}`, { method: 'DELETE' });
        if (response.ok) {
            showToast('City deleted successfully', 'success');
            loadCities();
            loadDashboard();
        } else {
            const data = await response.json().catch(() => ({}));
            showToast(data.detail || 'Error deleting city', 'error');
        }
    } catch (e) {
        showToast('Error deleting city', 'error');
    }
}

async function exportCities() {
    try {
        const response = await fetch(`${API_BASE}/cities`);
        const data = await response.json();
        
        let headerRow = ["ID", "City Name", "Status"];
        let csvContent = headerRow.join(",") + "\\n" + data.map(c => {
            return [c.id, `"${c.city_name}"`, c.is_active ? 'Active' : 'Inactive'].join(",");
        }).join("\\n");
        
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const encodedUri = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "cities.csv");
        document.body.appendChild(link);
        link.click();
        link.remove();
    } catch (e) {
        showToast('Error exporting cities', 'error');
    }
}

// Reports
// Legacy reports initializer (kept for backward compatibility).
// The current Reports view is powered by static/admin/js/reports.js and initAdminReportsSection().
async function loadReportsFilters() {
    try {
        const [cities, branches, officers] = await Promise.all([
            fetch(`${API_BASE}/cities`).then(r => r.json()),
            fetch(`${API_BASE}/branches`).then(r => r.json()),
            fetch(`${API_BASE}/officers`).then(r => r.json())
        ]);

        citiesData = cities;
        branchesData = branches;
        officersData = officers;

        // Populate filter dropdowns
        const citySelect = document.getElementById('filter-city');
        const branchSelect = document.getElementById('filter-branch');
        const officerSelect = document.getElementById('filter-officer');

        if (citySelect) {
            // Use city_name as value (not ID) because API expects names
            citySelect.innerHTML = '<option value="">All Cities</option>' + 
                cities.map(c => `<option value="${c.city_name}">${c.city_name}</option>`).join('');
        } else {
            console.warn('Report filter: filter-city element not found');
        }

        if (branchSelect) {
            // Use branch_name as value (not ID) because API expects names
            branchSelect.innerHTML = '<option value="">All Branches</option>' + 
                branches.map(b => `<option value="${b.branch_name}">${b.branch_name}</option>`).join('');
        } else {
            console.warn('Report filter: filter-branch element not found');
        }

        if (officerSelect) {
            // Use officer ID as value (API expects officer_id)
            officerSelect.innerHTML = '<option value="">All Officers</option>' + 
                officers.map(o => `<option value="${o.id}">${o.first_name} ${o.last_name}</option>`).join('');
        } else {
            console.warn('Report filter: filter-officer element not found');
        }

        // Update branch filter when city changes
        if (citySelect && branchSelect) {
            citySelect.addEventListener('change', () => {
                const selectedCityName = citySelect.value;
                branchSelect.innerHTML = '<option value="">All Branches</option>';
                if (selectedCityName) {
                    // Find city ID from name
                    const selectedCity = cities.find(c => c.city_name === selectedCityName);
                    if (selectedCity) {
                        branches.filter(b => b.city_id == selectedCity.id).forEach(b => {
                            branchSelect.innerHTML += `<option value="${b.branch_name}">${b.branch_name}</option>`;
                        });
                    }
                } else {
                    branches.forEach(b => {
                        branchSelect.innerHTML += `<option value="${b.branch_name}">${b.branch_name}</option>`;
                    });
                }
            });
        }
    } catch (error) {
        console.error('Error loading filters:', error);
    }
}

function buildReportQuery() {
    const params = new URLSearchParams();
    
    const cityId = document.getElementById('filter-city').value;
    const branchId = document.getElementById('filter-branch').value;
    const officerId = document.getElementById('filter-officer').value;
    const startDate = document.getElementById('filter-start-date').value;
    const endDate = document.getElementById('filter-end-date').value;
    const socialMedia = document.getElementById('filter-social-media').value;
    const username = document.getElementById('filter-username').value;

    if (cityId) params.append('city_id', cityId);
    if (branchId) params.append('branch_id', branchId);
    if (officerId) params.append('officer_id', officerId);
    if (startDate) params.append('start_date', new Date(startDate).toISOString());
    if (endDate) params.append('end_date', new Date(endDate).toISOString());
    if (socialMedia) params.append('social_media', socialMedia);
    if (username) params.append('username', username);

    return params.toString();
}

async function generateReport() {
    const tbody = document.getElementById('reports-tbody');
    if (!tbody) {
        console.warn('generateReport: reports tbody not found. Make sure the Reports view is loaded.');
        return;
    }
    showLoading(tbody);

    try {
        // Build query parameters
        const params = new URLSearchParams();
        
        const cityName = document.getElementById('filter-city')?.value;
        const branchName = document.getElementById('filter-branch')?.value;
        const officerId = document.getElementById('filter-officer')?.value;
        const startDate = document.getElementById('filter-start-date')?.value;
        const endDate = document.getElementById('filter-end-date')?.value;
        const socialMedia = document.getElementById('filter-social-media')?.value;
        const username = document.getElementById('filter-username')?.value;

        if (officerId) params.append('officer_id', officerId);
        if (cityName) params.append('city_name', cityName);
        if (branchName) params.append('branch_name', branchName);
        if (socialMedia) params.append('social_media', socialMedia);
        if (username) params.append('username', username);
        if (startDate) {
            const dateFrom = startDate.split('T')[0];
            params.append('date_from', dateFrom);
        }
        if (endDate) {
            const dateTo = endDate.split('T')[0];
            params.append('date_to', dateTo);
        }
        params.append('page_size', '1000');

        console.log('🔍 Generating report with filters:', Object.fromEntries(params));

        // Fetch reports and statistics
        const [reportsResponse, statsResponse] = await Promise.all([
            fetch(`${API_BASE}/reports/filter?${params.toString()}`),
            fetch(`${API_BASE}/reports/statistics?${params.toString()}`)
        ]);

        if (!reportsResponse.ok) {
            throw new Error(`Failed to fetch reports: ${reportsResponse.status}`);
        }

        const reportsData = await reportsResponse.json();
        const statsData = await statsResponse.json();

        console.log('📦 Received data:', {
            total: reportsData.total,
            results_count: reportsData.results.length
        });

        displayReports(reportsData.results);
        displayStatistics(statsData);
        
        showToast(`Report generated successfully! Found ${reportsData.total} record${reportsData.total !== 1 ? 's' : ''}.`, 'success');
    } catch (error) {
        console.error('❌ Error generating report:', error);
        tbody.innerHTML = '<tr><td colspan="9">Error loading reports</td></tr>';
        showToast('Error generating report: ' + error.message, 'error');
    }
}


function displayReports(reports) {
    const tbody = document.getElementById('reports-tbody');
    
    console.log('📊 displayReports called with', reports.length, 'database records');
    
    if (reports.length === 0) {
        tbody.innerHTML = '<tr><td colspan="9">No reports found</td></tr>';
        return;
    }

    let html = '';
    let totalRows = 0;
    
    // Iterate through each database record
    reports.forEach((record, recordIndex) => {
        console.log(`  Record ${recordIndex + 1}:`, {
            id: record.id,
            query: record.search_query,
            officer: record.officer_name,
            search_type: record.search_type
        });
        
        const fileData = record.file_data || {};
        
        // Handle both single-platform and multi-platform structures
        let resultsToDisplay = [];
        
        if (fileData.results && Array.isArray(fileData.results)) {
            // Multi-platform: has 'results' array
            resultsToDisplay = fileData.results;
            console.log(`    - Multi-platform with ${resultsToDisplay.length} platform result(s)`);
        } else if (fileData.result) {
            // Single-platform: has 'result' object
            // Convert to array format for consistent processing
            resultsToDisplay = [{
                platform: fileData.platform || 'N/A',
                username: fileData.username || record.search_query,
                found: fileData.result.found || false,
                profile_url: `https://${fileData.platform}.com/${fileData.username}`,
                instagram_data: {
                    profile: fileData.result.profile || {},
                    cybercrime_analysis: fileData.result.cybercrime_analysis || {}
                }
            }];
            console.log(`    - Single-platform: ${fileData.platform}`);
        } else {
            console.log(`    - No results data found`);
        }
        
        // If no results, show one row with "No Results"
        if (resultsToDisplay.length === 0) {
            html += `
                <tr style="animation-delay: ${totalRows * 0.05}s">
                    <td><small>${record.result_file_path}</small></td>
                    <td>${record.officer_name}</td>
                    <td>${record.branch_name}</td>
                    <td>${record.city_name}</td>
                    <td>${record.search_query}</td>
                    <td>N/A</td>
                    <td><span class="badge badge-secondary">N/A</span></td>
                    <td>${new Date(record.searched_at).toLocaleString()}</td>
                    <td><span class="badge badge-warning">No Results</span></td>
                </tr>
            `;
            totalRows++;
            return;
        }
        
        // Create one row for EACH platform result
        resultsToDisplay.forEach((result, resultIndex) => {
            const platform = result.platform || 'N/A';
            const username = result.username || record.search_query;
            const found = result.found ? 'Yes' : 'No';
            
            const instagramData = result.instagram_data || {};
            const profile = instagramData.profile || {};
            const cybercrime = instagramData.cybercrime_analysis || {};
            
            const followers = profile.followers || 'N/A';
            const riskLevel = cybercrime.risk_level || 'N/A';
            const riskScore = cybercrime.risk_score || 'N/A';
            
            let summary = '';
            if (found === 'Yes') {
                summary = `<br><small>👥 ${followers} followers | 🎯 Risk: ${riskLevel} (${riskScore})</small>`;
            }
            
            html += `
                <tr style="animation-delay: ${totalRows * 0.05}s; cursor: pointer;">
                    <td><small>${record.result_file_path.split('/').pop().split('\\\\').pop()}</small></td>
                    <td>${record.officer_name}</td>
                    <td>${record.branch_name}</td>
                    <td>${record.city_name}</td>
                    <td><strong>${record.search_query}</strong></td>
                    <td>${username}</td>
                    <td><span class="badge badge-primary">${platform}</span></td>
                    <td>${new Date(record.searched_at).toLocaleString()}</td>
                    <td>
                        <span class="badge ${found === 'Yes' ? 'badge-success' : 'badge-secondary'}">${found}</span>
                        ${summary}
                    </td>
                </tr>
            `;
            totalRows++;
            console.log(`    ✓ Added row for ${platform}: ${username} (found: ${found})`);
        });
    });
    
    tbody.innerHTML = html;
    console.log(`✅ Total rows added to table: ${totalRows}`);
}


function displayStatistics(stats) {
    // Hide empty state and show stats grid
    const statsEmpty = document.getElementById('stats-empty');
    const statsGrid = document.getElementById('stats-grid');
    
    if (statsEmpty) statsEmpty.style.display = 'none';
    if (statsGrid) statsGrid.style.display = 'grid';
    
    // Update stat cards
    const totalReportsEl = document.getElementById('stat-total-reports');
    const uniqueOfficersEl = document.getElementById('stat-unique-officers');
    const platformsCoveredEl = document.getElementById('stat-platforms-covered');
    const citiesCoveredEl = document.getElementById('stat-cities-covered');
    
    if (totalReportsEl) totalReportsEl.textContent = stats.total_searches || 0;
    if (uniqueOfficersEl) uniqueOfficersEl.textContent = stats.unique_officers || 0;
    if (platformsCoveredEl) platformsCoveredEl.textContent = stats.platforms_covered || 0;
    if (citiesCoveredEl) citiesCoveredEl.textContent = stats.unique_cities || 0;
    
    console.log('📈 Statistics updated:', {
        total_searches: stats.total_searches,
        unique_officers: stats.unique_officers,
        platforms_covered: stats.platforms_covered,
        unique_cities: stats.unique_cities
    });
}

function applyFilters() {
    generateReport();
}

function clearFilters() {
    document.getElementById('filter-city').value = '';
    document.getElementById('filter-branch').value = '';
    document.getElementById('filter-officer').value = '';
    document.getElementById('filter-start-date').value = '';
    document.getElementById('filter-end-date').value = '';
    document.getElementById('filter-social-media').value = '';
    document.getElementById('filter-username').value = '';
    document.getElementById('reports-tbody').innerHTML = '<tr><td colspan="9">No reports loaded. Apply filters and generate report.</td></tr>';
    document.getElementById('stats-content').innerHTML = 'Click "Generate Report" to see statistics';
}


// Modal functions - closeModal is now in modal-functions.js


window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        event.target.classList.remove('show');
        setTimeout(() => {
            event.target.style.display = 'none';
        }, 300);
    }
}

// Initialization handled in DOMContentLoaded above.


// Search functionality
let currentSearchType = null;

function initSearchHandlers() {
    console.log('🔍 Initializing search handlers');
    
    // Initialize form handlers for all three types
    const form1 = document.getElementById('search-form-type-1');
    const form2 = document.getElementById('search-form-type-2');
    const form3 = document.getElementById('search-form-type-3');
    
    if (form1) {
        form1.addEventListener('submit', handleSearchType1);
    }
    if (form2) {
        form2.addEventListener('submit', handleSearchType2);
    }
    if (form3) {
        form3.addEventListener('submit', handleSearchType3);
    }
}

function selectSearchType(type) {
    console.log('📋 Search type selected:', type);
    currentSearchType = type;
    
    // Show form container
    const formContainer = document.getElementById('search-form-container');
    formContainer.style.display = 'block';
    
    // Hide all forms
    document.getElementById('search-form-type-1').style.display = 'none';
    document.getElementById('search-form-type-2').style.display = 'none';
    document.getElementById('search-form-type-3').style.display = 'none';
    
    // Show selected form
    const selectedForm = document.getElementById(`search-form-type-${type}`);
    selectedForm.style.display = 'block';
    
    // Update title
    const titles = {
        1: 'Type 1: Keyword Search',
        2: 'Type 2: Single Platform Search',
        3: 'Type 3: Continuous Tracking Setup'
    };
    document.getElementById('search-form-title').textContent = titles[type];
    
    // Hide results
    document.getElementById('search-results-container').style.display = 'none';
    
    // Scroll to form
    formContainer.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function resetSearchForm() {
    currentSearchType = null;
    document.getElementById('search-form-container').style.display = 'none';
    document.getElementById('search-results-container').style.display = 'none';
    
    // Reset all forms
    document.getElementById('search-form-type-1').reset();
    document.getElementById('search-form-type-2').reset();
    document.getElementById('search-form-type-3').reset();
    
    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

async function handleSearchType1(e) {
    e.preventDefault();
    const keyword = document.getElementById('keyword-type1').value.trim();
    const checkboxes = document.querySelectorAll('input[name="platform-type1"]:checked');
    const platforms = Array.from(checkboxes).map(cb => cb.value);

    if (platforms.length === 0) {
        showToast('Please select at least one platform', 'error');
        return;
    }

    showSearchResults('loading', { keyword, platforms });

    const submitBtn = e.target.querySelector('button[type="submit"]');
    const originalText = submitBtn ? submitBtn.innerHTML : '';
    if (submitBtn) { submitBtn.disabled = true; submitBtn.innerHTML = '<span class="spinner"></span> Searching...'; }

    try {
        const response = await fetch(`${API_BASE}/search/multi-platform`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${localStorage.getItem('token')}` },
            body: JSON.stringify({ keyword, platforms })
        });
        if (!response.ok) throw new Error('Search failed: ' + response.status);
        const results = await response.json();
        showSearchResults('type1', { keyword, platforms, results });
        showToast('Search completed!', 'success');
    } catch (error) {
        showSearchResults('error', { message: error.message });
        showToast('Search failed: ' + error.message, 'error');
    } finally {
        if (submitBtn) { submitBtn.disabled = false; submitBtn.innerHTML = originalText; }
    }
}


async function handleSearchType2(e) {
    e.preventDefault();
    const username = document.getElementById('username-type2').value.trim();
    const platform = document.querySelector('input[name="platform-type2"]:checked')?.value;

    if (!platform) {
        showToast('Please select a platform', 'error');
        return;
    }

    showSearchResults('loading', { username, platform });

    const submitBtn = e.target.querySelector('button[type="submit"]');
    const originalText = submitBtn ? submitBtn.innerHTML : '';
    if (submitBtn) { submitBtn.disabled = true; submitBtn.innerHTML = '<span class="spinner"></span> Loading...'; }

    try {
        const response = await fetch(`${API_BASE}/search/single-platform`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${localStorage.getItem('token')}` },
            body: JSON.stringify({ username, platform })
        });
        if (!response.ok) {
            const err = await response.json();
            throw new Error(err.detail || 'Search failed');
        }
        const result = await response.json();
        showSearchResults('type2', { username, platform, result });
        showToast('Profile loaded!', 'success');
    } catch (error) {
        showSearchResults('error', { message: error.message });
        showToast('Search failed: ' + error.message, 'error');
    } finally {
        if (submitBtn) { submitBtn.disabled = false; submitBtn.innerHTML = originalText; }
    }
}

async function handleSearchType3(e) {
    e.preventDefault();
    const username = document.getElementById('username-type3').value.trim();
    const platform = document.querySelector('input[name="platform-type3"]:checked')?.value;
    const durationValue = document.getElementById('duration-value').value;
    const durationUnit = document.getElementById('duration-unit').value;
    const frequency = document.getElementById('tracking-frequency').value;

    if (!platform) { showToast('Please select a platform', 'error'); return; }
    if (!durationUnit) { showToast('Please select duration unit', 'error'); return; }

    showSearchResults('loading', { username, platform });

    // Build a rich simulated tracking response
    await new Promise(resolve => setTimeout(resolve, 1200));
    const trackingData = {
        tracking_id: 'TRK-' + Math.random().toString(36).substring(2,8).toUpperCase(),
        username,
        platform,
        duration: `${durationValue} ${durationUnit}`,
        frequency,
        start_time: new Date().toISOString(),
        end_time: calculateEndTime(durationValue, durationUnit),
        status: 'active'
    };
    showSearchResults('type3', trackingData);
    showToast('Monitoring started!', 'success');
}

function calculateEndTime(value, unit) {
    const now = new Date();
    const multipliers = {
        hours: 60 * 60 * 1000,
        days: 24 * 60 * 60 * 1000,
        weeks: 7 * 24 * 60 * 60 * 1000,
        months: 30 * 24 * 60 * 60 * 1000
    };
    
    const endTime = new Date(now.getTime() + (value * multipliers[unit]));
    return endTime.toISOString();
}

function showSearchResults(type, data) {
    const container = document.getElementById('search-results-container');
    const content = document.getElementById('search-results-content');
    const subtitle = document.getElementById('results-subtitle');

    container.style.display = 'block';

    if (type === 'loading') {
        content.innerHTML = `
            <div style="text-align:center;padding:48px;">
                <div class="loading-spinner"></div>
                <p style="margin-top:16px;color:var(--text-secondary);font-size:1.1rem;">Searching across platforms and analyzing with AI...</p>
            </div>`;
        subtitle.textContent = 'Please wait...';
        container.scrollIntoView({ behavior: 'smooth', block: 'start' });
        return;
    }

    if (type === 'error') {
        content.innerHTML = `
            <div class="error-message">
                <div class="error-icon">⚠️</div>
                <h3>Search Failed</h3>
                <p>${data.message}</p>
            </div>`;
        subtitle.textContent = 'An error occurred';
        container.scrollIntoView({ behavior: 'smooth', block: 'start' });
        return;
    }

    if (type === 'type1') {
        subtitle.textContent = `Results for "${data.keyword}" across ${data.platforms.length} platform(s)`;
        content.innerHTML = renderMultiPlatformResults(data);
    } else if (type === 'type2') {
        subtitle.textContent = `Detailed results for @${data.username} on ${data.platform}`;
        content.innerHTML = renderSinglePlatformResults(data);
    } else if (type === 'type3') {
        subtitle.textContent = `Monitoring active for @${data.username}`;
        content.innerHTML = renderTrackingResults(data);
    }

    container.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function getPlatformIcon(platform) {
    const icons = {
        facebook: '📘',
        twitter: '🐦',
        instagram: '📷',
        linkedin: '💼',
        youtube: '📺',
        tiktok: '🎵'
    };
    return icons[platform] || '🔍';
}

function formatFrequency(freq) {
    const formats = {
        '15min': 'Every 15 minutes',
        '30min': 'Every 30 minutes',
        '1hour': 'Every hour',
        '6hours': 'Every 6 hours',
        '12hours': 'Every 12 hours',
        '24hours': 'Once a day'
    };
    return formats[freq] || freq;
}

// Add CSS for search results
// searchStyles definition removed to avoid conflict with search-functions.js
// Styles are now handled by search-styles.css


// ========================================
// INLINE RESULTS DISPLAY FUNCTIONS
// ========================================

function displayInstagramResults(data) {
    console.log('📊 Displaying Instagram results inline');
    
    const container = document.getElementById('search-results-container');
    const content = document.getElementById('search-results-content');
    const subtitle = document.getElementById('results-subtitle');
    
    if (!container || !content) {
        console.error('Results container not found!');
        return;
    }
    
    const profile = data.profile;
    const posts = data.recent_posts || [];
    const isPrivate = profile.is_private;
    
    subtitle.textContent = `Profile: @${profile.username}`;
    
    content.innerHTML = `
        <div class="instagram-results">
            <!-- Profile Header -->
            <div class="result-profile-header">
                <img src="${profile.profile_pic_url || 'https://via.placeholder.com/100'}" 
                     alt="${profile.username}" 
                     class="result-profile-pic"
                     onerror="this.src='https://via.placeholder.com/100'">
                <div class="result-profile-info">
                    <h3 class="result-username">
                        @${profile.username}
                        ${profile.is_verified ? '<span class="result-verified">✓</span>' : ''}
                    </h3>
                    ${profile.full_name ? `<p class="result-fullname">${profile.full_name}</p>` : ''}
                    ${profile.biography ? `<p class="result-bio">${profile.biography}</p>` : ''}
                    ${profile.external_url ? `<a href="${profile.external_url}" target="_blank" class="result-link">🔗 ${profile.external_url}</a>` : ''}
                </div>
            </div>
            
            <!-- Stats -->
            <div class="result-stats-grid">
                <div class="result-stat">
                    <div class="result-stat-value">${formatNumber(profile.followers)}</div>
                    <div class="result-stat-label">Followers</div>
                </div>
                <div class="result-stat">
                    <div class="result-stat-value">${formatNumber(profile.following)}</div>
                    <div class="result-stat-label">Following</div>
                </div>
                <div class="result-stat">
                    <div class="result-stat-value">${formatNumber(profile.posts_count)}</div>
                    <div class="result-stat-label">Posts</div>
                </div>
            </div>
            
            ${!isPrivate && posts.length > 0 ? `
                <!-- Engagement -->
                <div class="result-engagement">
                    <h4>📊 Engagement Analytics</h4>
                    <div class="result-engagement-grid">
                        <div class="result-engagement-item">
                            <span class="result-engagement-value">${data.engagement_rate}%</span>
                            <span class="result-engagement-label">Engagement Rate</span>
                        </div>
                        <div class="result-engagement-item">
                            <span class="result-engagement-value">${formatNumber(data.avg_likes)}</span>
                            <span class="result-engagement-label">Avg Likes</span>
                        </div>
                        <div class="result-engagement-item">
                            <span class="result-engagement-value">${formatNumber(data.avg_comments)}</span>
                            <span class="result-engagement-label">Avg Comments</span>
                        </div>
                    </div>
                </div>
                
                <!-- Posts -->
                <div class="result-posts">
                    <h4>📸 Recent Posts (${posts.length})</h4>
                    <div class="result-posts-grid">
                        ${posts.map(post => `
                            <div class="result-post-card" onclick="window.open('${post.post_url}', '_blank')">
                                <div class="result-post-placeholder">
                                    ${post.is_video ? '<div class="result-video-badge">▶</div>' : ''}
                                </div>
                                <div class="result-post-info">
                                    <div class="result-post-stats">
                                        <span>❤️ ${formatNumber(post.likes)}</span>
                                        <span>💬 ${formatNumber(post.comments)}</span>
                                    </div>
                                    ${post.caption ? `<p class="result-post-caption">${post.caption.substring(0, 80)}${post.caption.length > 80 ? '...' : ''}</p>` : ''}
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            ` : isPrivate ? `
                <div class="result-private">
                    <div class="result-private-icon">🔒</div>
                    <h4>Private Account</h4>
                    <p>This account is private. Follow to see their photos and videos.</p>
                </div>
            ` : ''}
            
            <!-- AI ANALYSIS SECTION -->
            ${renderAIAnalysisInline(data)}
        </div>
    `;
    
    container.style.display = 'block';
    container.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// Helper function to render AI analysis inline
function renderAIAnalysisInline(data) {
    console.log('🤖 renderAIAnalysisInline called with:', {
        has_cybercrime_analysis: !!data.cybercrime_analysis,
        has_ai_summary: !!data.ai_summary,
        data: data
    });
    
    if (!data.cybercrime_analysis && !data.ai_summary) {
        console.warn('⚠️ No AI data available');
        return `
            <div class="ai-analysis-section">
                <div class="ai-header">
                    <h4>AI Cybercrime Analysis</h4>
                </div>
                <div class="ai-unavailable">
                    <p>AI analysis is currently unavailable or being processed.</p>
                </div>
            </div>
        `;
    }
    
    const analysis = data.cybercrime_analysis || {};
    const summary = data.ai_summary;
    const riskLevel = (analysis.risk_level || 'unknown').toString().toLowerCase();
    const riskScore = analysis.risk_score || 0;
    
    // Get risk color
    const riskColors = {
        'low': '#10b981',
        'medium': '#f59e0b',
        'high': '#ef4444',
        'critical': '#dc2626',
        'unknown': '#6b7280'
    };
    const riskColor = riskColors[riskLevel] || riskColors.unknown;
    
    // Get risk icon
    const riskIcons = {
        'low': '✅',
        'medium': '⚠️',
        'high': '🚨',
        'critical': '🔴',
        'unknown': '❓'
    };
    const riskIcon = riskIcons[riskLevel] || riskIcons.unknown;
    
    let html = `
        <div class="ai-analysis-section">
            <div class="ai-header">
                <h4>AI Cybercrime Analysis</h4>
            </div>
            
            <div class="risk-assessment">
                <div class="risk-level-card" style="border-color: ${riskColor};">
                    <div class="risk-icon" style="background: ${riskColor};">
                        ${riskIcon}
                    </div>
                    <div class="risk-details">
                        <h5>Risk Level: <span style="color: ${riskColor}; font-weight: bold;">${riskLevel.toUpperCase()}</span></h5>
                        <div class="risk-score-bar">
                            <div class="risk-score-fill" style="width: ${riskScore}%; background: ${riskColor};"></div>
                        </div>
                        <p class="risk-score-text">Risk Score: ${riskScore}/100</p>
                    </div>
                </div>
            </div>
    `;
    
    // Summary
    const finalSummary = summary || analysis.summary;
    if (finalSummary) {
        html += `
            <div class="ai-summary">
                <h5>Summary</h5>
                <p>${finalSummary.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</p>
            </div>
        `;
    }
    
    // Indicators
    if (analysis.indicators && Array.isArray(analysis.indicators) && analysis.indicators.length > 0) {
        html += `
            <div class="ai-indicators">
                <h5>Red Flag Indicators</h5>
                <ul class="indicators-list">
        `;
        analysis.indicators.forEach(indicator => {
            if (indicator) {
                html += `<li>${indicator.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</li>`;
            }
        });
        html += `
                </ul>
            </div>
        `;
    }
    
    // Categories
    if (analysis.categories && Array.isArray(analysis.categories) && analysis.categories.length > 0) {
        html += `
            <div class="ai-categories">
                <h5>Potential Cybercrime Categories</h5>
                <div class="categories-tags">
        `;
        analysis.categories.forEach(category => {
            if (category) {
                html += `<span class="category-tag">${category.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</span>`;
            }
        });
        html += `
                </div>
            </div>
        `;
    }
    
    // Recommendations
    if (analysis.recommendations && Array.isArray(analysis.recommendations) && analysis.recommendations.length > 0) {
        html += `
            <div class="ai-recommendations">
                <h5>Recommendations</h5>
                <ul class="recommendations-list">
        `;
        analysis.recommendations.forEach(rec => {
            if (rec) {
                html += `<li>${rec.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</li>`;
            }
        });
        html += `
                </ul>
            </div>
        `;
    }
    
    html += '</div>';
    return html;
}

function displayErrorResults(error) {
    console.log('❌ Displaying error results');
    
    const container = document.getElementById('search-results-container');
    const content = document.getElementById('search-results-content');
    const subtitle = document.getElementById('results-subtitle');
    
    if (!container || !content) {
        console.error('Results container not found!');
        return;
    }
    
    subtitle.textContent = 'Search Error';
    
    content.innerHTML = `
        <div class="result-error">
            <div class="result-error-icon">⚠️</div>
            <h3>Search Failed</h3>
            <p>${error}</p>
        </div>
    `;
    
    container.style.display = 'block';
    container.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function formatNumber(num) {
    if (!num) return '0';
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
}
