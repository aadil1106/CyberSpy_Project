// Static credentials
const VALID_CREDENTIALS = {
    username: 'admin',
    password: 'admin123'
};

// Check if already logged in
if (sessionStorage.getItem('isLoggedIn') === 'true') {
    window.location.href = './index.html';
}

// Toggle password visibility
const togglePassword = document.getElementById('toggle-password');
const passwordInput = document.getElementById('password');

togglePassword.addEventListener('click', () => {
    const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
    passwordInput.setAttribute('type', type);
    
    // Toggle eye icon
    const eyeIcon = togglePassword.querySelector('.eye-icon');
    if (type === 'text') {
        eyeIcon.innerHTML = `
            <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <line x1="1" y1="1" x2="23" y2="23" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        `;
    } else {
        eyeIcon.innerHTML = `
            <path d="M1 12S5 4 12 4s11 8 11 8-4 8-11 8S1 12 1 12z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        `;
    }
});

// Handle form submission
const loginForm = document.getElementById('login-form');
const errorMessage = document.getElementById('error-message');
const loginButton = loginForm.querySelector('.login-button');

loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;
    const rememberMe = document.getElementById('remember-me').checked;
    
    // Hide previous error
    errorMessage.classList.remove('show');
    
    // Add loading state
    loginButton.classList.add('loading');
    loginButton.querySelector('.button-text').textContent = 'Signing in';
    
    // Simulate network delay for better UX
    await new Promise(resolve => setTimeout(resolve, 800));
    
    // Validate credentials
    if (username === VALID_CREDENTIALS.username && password === VALID_CREDENTIALS.password) {
        // Success - store login state
        sessionStorage.setItem('isLoggedIn', 'true');
        sessionStorage.setItem('username', username);
        
        if (rememberMe) {
            localStorage.setItem('rememberMe', 'true');
            localStorage.setItem('username', username);
        }
        
        // Show success state
        loginButton.querySelector('.button-text').textContent = 'Success!';
        loginButton.style.background = 'linear-gradient(135deg, #10b981 0%, #059669 100%)';
        
        // Redirect to dashboard
        setTimeout(() => {
            window.location.href = './index.html';
        }, 500);
    } else {
        // Error - invalid credentials
        loginButton.classList.remove('loading');
        loginButton.querySelector('.button-text').textContent = 'Sign In';
        
        errorMessage.textContent = '❌ Invalid username or password. Please try again.';
        errorMessage.classList.add('show');
        
        // Shake the form
        loginForm.style.animation = 'none';
        setTimeout(() => {
            loginForm.style.animation = 'shake 0.5s ease';
        }, 10);
        
        // Clear password field
        passwordInput.value = '';
        passwordInput.focus();
    }
});

// Auto-fill if remember me was checked
window.addEventListener('DOMContentLoaded', () => {
    if (localStorage.getItem('rememberMe') === 'true') {
        const savedUsername = localStorage.getItem('username');
        if (savedUsername) {
            document.getElementById('username').value = savedUsername;
            document.getElementById('remember-me').checked = true;
            document.getElementById('password').focus();
        }
    }
});

// Add enter key support for inputs
document.getElementById('username').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        e.preventDefault();
        document.getElementById('password').focus();
    }
});
