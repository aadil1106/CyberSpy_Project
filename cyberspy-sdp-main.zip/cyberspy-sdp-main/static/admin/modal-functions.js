
// ========================================
// SEARCH RESULTS MODAL FUNCTIONS
// ========================================

function showInstagramProfileModal(data) {
    console.log('🎨 Showing Instagram profile modal');
    console.log('   Data received:', data);
    
    const profile = data.profile;
    const posts = data.recent_posts || [];
    const isPrivate = profile.is_private;
    
    console.log('   Profile:', {
        username: profile.username,
        followers: profile.followers,
        posts_count: profile.posts_count,
        is_private: isPrivate,
        is_verified: profile.is_verified
    });
    console.log('   Posts count:', posts.length);
    console.log('   Engagement rate:', data.engagement_rate + '%');
    
    const modalHTML = `
        <div class="modal-overlay" onclick="closeModal(event)">
            <div class="modal-container" style="background: #ffffff !important; background-color: #ffffff !important;" onclick="event.stopPropagation()">
                <div class="modal-header">
                    <h2>📷 Instagram Profile</h2>
                    <button class="modal-close" id="modal-close-btn">&times;</button>
                </div>
                <div class="modal-body">
                    <!-- Profile Header -->
                    <div class="profile-header">
                        <img src="${profile.profile_pic_url || 'https://via.placeholder.com/120'}" 
                             alt="${profile.username}" 
                             class="profile-pic"
                             onerror="this.src='https://via.placeholder.com/120'">
                        <div class="profile-info">
                            <div class="profile-username">
                                @${profile.username}
                                ${profile.is_verified ? '<span class="verified-badge">✓ Verified</span>' : ''}
                            </div>
                            ${profile.full_name ? `<div class="profile-fullname">${profile.full_name}</div>` : ''}
                            ${profile.biography ? `<div class="profile-bio">${profile.biography}</div>` : ''}
                            ${profile.external_url ? `<a href="${profile.external_url}" target="_blank" class="profile-link">🔗 ${profile.external_url}</a>` : ''}
                            ${profile.is_business_account ? `<div class="business-badge">💼 Business Account${profile.business_category ? ` - ${profile.business_category}` : ''}</div>` : ''}
                        </div>
                    </div>
                    
                    <!-- Stats Grid -->
                    <div class="stats-grid">
                        <div class="stat-card">
                            <span class="stat-value">${formatNumber(profile.followers)}</span>
                            <span class="stat-label">Followers</span>
                        </div>
                        <div class="stat-card">
                            <span class="stat-value">${formatNumber(profile.following)}</span>
                            <span class="stat-label">Following</span>
                        </div>
                        <div class="stat-card">
                            <span class="stat-value">${formatNumber(profile.posts_count)}</span>
                            <span class="stat-label">Posts</span>
                        </div>
                    </div>
                    
                    ${!isPrivate && posts.length > 0 ? `
                        <!-- Engagement Section -->
                        <div class="engagement-section">
                            <h3>📊 Engagement Analytics</h3>
                            <div class="engagement-stats">
                                <div class="engagement-item">
                                    <span class="engagement-value">${data.engagement_rate}%</span>
                                    <span class="engagement-label">Engagement Rate</span>
                                </div>
                                <div class="engagement-item">
                                    <span class="engagement-value">${formatNumber(data.avg_likes)}</span>
                                    <span class="engagement-label">Avg Likes</span>
                                </div>
                                <div class="engagement-item">
                                    <span class="engagement-value">${formatNumber(data.avg_comments)}</span>
                                    <span class="engagement-label">Avg Comments</span>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Posts Section -->
                        <div class="posts-section">
                            <h3>📸 Recent Posts (${posts.length})</h3>
                            <div class="posts-grid">
                                ${posts.map(post => `
                                    <div class="post-card" onclick="window.open('${post.post_url}', '_blank')">
                                        <div style="position: relative;">
                                            <div class="post-image"></div>
                                            ${post.is_video ? '<div class="video-badge">▶ Video</div>' : ''}
                                        </div>
                                        <div class="post-info">
                                            <div class="post-stats">
                                                <span class="post-stat">❤️ ${formatNumber(post.likes)}</span>
                                                <span class="post-stat">💬 ${formatNumber(post.comments)}</span>
                                                ${post.is_video && post.video_views ? `<span class="post-stat">👁️ ${formatNumber(post.video_views)}</span>` : ''}
                                            </div>
                                            ${post.caption ? `<div class="post-caption">${post.caption}</div>` : ''}
                                            <div class="post-date">${formatDate(post.date)}</div>
                                        </div>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    ` : isPrivate ? `
                        <!-- Private Account -->
                        <div class="private-account">
                            <div class="private-icon">🔒</div>
                            <h3>Private Account</h3>
                            <p>This account is private. Follow to see their photos and videos.</p>
                        </div>
                    ` : ''}
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    document.body.style.overflow = 'hidden';
    
    // Add click event listener to close button
    const closeBtn = document.getElementById('modal-close-btn');
    if (closeBtn) {
        console.log('✅ Close button found, adding event listener');
        closeBtn.addEventListener('click', function(e) {
            console.log('🚪 Close button clicked!');
            e.stopPropagation();
            closeModal();
        });
    } else {
        console.error('❌ Close button not found!');
    }
}

function showHashtagResultsModal(keyword, profiles, posts) {
    const modalHTML = `
        <div class="modal-overlay" onclick="closeModal(event)">
            <div class="modal-container" style="background: #ffffff !important; background-color: #ffffff !important;" onclick="event.stopPropagation()">
                <div class="modal-header">
                    <h2>🔍 Hashtag Search Results</h2>
                    <button class="modal-close" onclick="closeModal()">&times;</button>
                </div>
                <div class="modal-body">
                    <!-- Hashtag Header -->
                    <div class="hashtag-header">
                        <div class="hashtag-title">#${keyword}</div>
                        <div class="hashtag-count">${posts.length} posts found • ${profiles.length} unique profiles</div>
                    </div>
                    
                    ${profiles.length > 0 ? `
                        <!-- Profiles Section -->
                        <div class="profiles-section">
                            <h3>👥 Top Profiles (${profiles.length})</h3>
                            <div class="profiles-grid">
                                ${profiles.map(profile => `
                                    <div class="profile-mini-card" onclick="searchSingleProfile('${profile.username}')">
                                        <img src="${profile.profile_pic_url || 'https://via.placeholder.com/80'}" 
                                             alt="${profile.username}" 
                                             class="profile-mini-pic"
                                             onerror="this.src='https://via.placeholder.com/80'">
                                        <div class="profile-mini-username">
                                            @${profile.username}
                                            ${profile.is_verified ? ' ✓' : ''}
                                        </div>
                                        ${profile.full_name ? `<div style="font-size: 0.875rem; color: var(--text-secondary); margin-top: 4px;">${profile.full_name}</div>` : ''}
                                        <div class="profile-mini-stats">
                                            <span>${formatNumber(profile.followers)} followers</span>
                                            <span>${formatNumber(profile.posts_count)} posts</span>
                                        </div>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    ` : ''}
                    
                    ${posts.length > 0 ? `
                        <!-- Posts Section -->
                        <div class="posts-section">
                            <h3>📸 Top Posts (${posts.length})</h3>
                            <div class="posts-grid">
                                ${posts.map(post => `
                                    <div class="post-card" onclick="window.open('${post.post_url}', '_blank')">
                                        <div style="position: relative;">
                                            <div class="post-image"></div>
                                            ${post.is_video ? '<div class="video-badge">▶ Video</div>' : ''}
                                        </div>
                                        <div class="post-info">
                                            <div class="post-stats">
                                                <span class="post-stat">❤️ ${formatNumber(post.likes)}</span>
                                                <span class="post-stat">💬 ${formatNumber(post.comments)}</span>
                                                ${post.is_video && post.video_views ? `<span class="post-stat">👁️ ${formatNumber(post.video_views)}</span>` : ''}
                                            </div>
                                            ${post.caption ? `<div class="post-caption">${post.caption}</div>` : ''}
                                            <div class="post-date">${formatDate(post.date)}</div>
                                        </div>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    ` : ''}
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    document.body.style.overflow = 'hidden';
}

function showLoadingModal(message = 'Searching...') {
    const modalHTML = `
        <div class="modal-overlay">
            <div class="modal-container" style="background: #ffffff !important; background-color: #ffffff !important;">
                <div class="modal-header">
                    <h2>🔍 Search in Progress</h2>
                </div>
                <div class="modal-body">
                    <div class="modal-loading">
                        <div class="loading-spinner-large"></div>
                        <p style="font-size: 1.125rem; color: var(--text-secondary);">${message}</p>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    document.body.style.overflow = 'hidden';
}

function showErrorModal(error) {
    const modalHTML = `
        <div class="modal-overlay" onclick="closeModal(event)">
            <div class="modal-container" style="background: #ffffff !important; background-color: #ffffff !important;" onclick="event.stopPropagation()">
                <div class="modal-header">
                    <h2>❌ Search Error</h2>
                    <button class="modal-close" id="modal-close-btn">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="modal-error">
                        <div class="error-icon">⚠️</div>
                        <h3>Search Failed</h3>
                        <p>${error}</p>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    document.body.style.overflow = 'hidden';
    
    // Add click event listener to close button
    const closeBtn = document.getElementById('modal-close-btn');
    if (closeBtn) {
        console.log('✅ Error modal close button found');
        closeBtn.addEventListener('click', function(e) {
            console.log('🚪 Error modal close button clicked!');
            e.stopPropagation();
            closeModal();
        });
    }
}

function closeModal(event) {
    console.log('🚪 closeModal called', event);
    
    // If event is passed and it's a click on the overlay (not the close button)
    // Only close if clicking directly on the overlay background
    if (event && event.type === 'click' && event.target !== event.currentTarget) {
        console.log('   ❌ Click was not on overlay, ignoring');
        return;
    }
    
    const modal = document.querySelector('.modal-overlay');
    console.log('   Modal found:', modal ? 'Yes' : 'No');
    
    if (modal) {
        console.log('   ✅ Closing modal...');
        modal.style.animation = 'fadeOut 0.3s ease';
        setTimeout(() => {
            modal.remove();
            document.body.style.overflow = '';
            console.log('   ✅ Modal removed');
        }, 300);
    } else {
        console.log('   ⚠️ No modal to close');
    }
}


// Helper function to search a single profile from hashtag results
async function searchSingleProfile(username) {
    closeModal();
    showLoadingModal(`Fetching @${username}...`);
    
    try {
        const response = await fetch(`${API_BASE}/search/single-platform`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                username: username,
                platform: 'instagram'
            })
        });
        
        if (!response.ok) throw new Error('Failed to fetch profile');
        
        const data = await response.json();
        closeModal();
        showInstagramProfileModal(data);
    } catch (error) {
        closeModal();
        showErrorModal(error.message);
    }
}

// Utility functions
function formatNumber(num) {
    if (!num) return '0';
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
}

function formatDate(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now - date;
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    
    if (days === 0) return 'Today';
    if (days === 1) return 'Yesterday';
    if (days < 7) return `${days} days ago`;
    if (days < 30) return `${Math.floor(days / 7)} weeks ago`;
    if (days < 365) return `${Math.floor(days / 30)} months ago`;
    return `${Math.floor(days / 365)} years ago`;
}

// Add fadeOut animation
const style = document.createElement('style');
style.textContent = `
    @keyframes fadeOut {
        from {
            opacity: 1;
        }
        to {
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);
