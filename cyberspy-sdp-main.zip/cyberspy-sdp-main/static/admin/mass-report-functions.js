// Mass Reporting Functions
let currentLogId = null;
let currentSearchData = null;

// Load recent searches
async function loadRecentSearches() {
    const searchTypeFilter = document.getElementById('search-type-filter')?.value || '';
    const limitFilter = document.getElementById('limit-filter')?.value || '50';
    
    const loadingEl = document.getElementById('loading-searches');
    const gridEl = document.getElementById('recent-searches-grid');
    const noSearchesEl = document.getElementById('no-searches-message');
    
    if (loadingEl) loadingEl.style.display = 'block';
    if (gridEl) gridEl.innerHTML = '';
    if (noSearchesEl) noSearchesEl.style.display = 'none';
    
    try {
        let url = `/api/mass-report/recent-searches?limit=${limitFilter}`;
        if (searchTypeFilter) {
            url += `&search_type=${searchTypeFilter}`;
        }
        
        const response = await fetch(url);
        
        if (!response.ok) {
            throw new Error('Failed to load recent searches');
        }
        
        const searches = await response.json();
        
        if (loadingEl) loadingEl.style.display = 'none';
        
        if (searches.length === 0) {
            if (noSearchesEl) noSearchesEl.style.display = 'block';
            return;
        }
        
        displayRecentSearches(searches);
    } catch (error) {
        console.error('Error loading recent searches:', error);
        if (loadingEl) loadingEl.style.display = 'none';
        if (noSearchesEl) {
            noSearchesEl.style.display = 'block';
            noSearchesEl.querySelector('h3').textContent = 'Error Loading Searches';
            noSearchesEl.querySelector('p').textContent = error.message;
        }
        showToast('Failed to load recent searches', 'error');
    }
}

// Display recent searches in grid
function displayRecentSearches(searches) {
    const gridEl = document.getElementById('recent-searches-grid');
    if (!gridEl) return;
    
    gridEl.innerHTML = '';
    
    searches.forEach(search => {
        const card = createSearchCard(search);
        gridEl.appendChild(card);
    });
}

// Create a search card element
function createSearchCard(search) {
    const card = document.createElement('div');
    card.className = 'search-card';
    card.onclick = () => openSearchResult(search.id);
    
    const searchDate = new Date(search.searched_at);
    const formattedDate = searchDate.toLocaleDateString() + ' ' + searchDate.toLocaleTimeString();
    
    const badgeColor = search.search_type === 'multi-platform' ? '#6366f1' : '#8b5cf6';
    
    card.innerHTML = `
        <div class="search-card-header">
            <span class="search-type-badge" style="background: ${badgeColor};">
                ${search.search_type}
            </span>
            <span class="search-date">${formattedDate}</span>
        </div>
        <div class="search-query">${escapeHtml(search.search_query)}</div>
        <div class="search-officer">
            <svg viewBox="0 0 24 24" fill="none">
                <path d="M20 21V19C20 17.9391 19.5786 16.9217 18.8284 16.1716C18.0783 15.4214 17.0609 15 16 15H8C6.93913 15 5.92172 15.4214 5.17157 16.1716C4.42143 16.9217 4 17.9391 4 19V21" stroke="currentColor" stroke-width="2"/>
                <circle cx="12" cy="7" r="4" stroke="currentColor" stroke-width="2"/>
            </svg>
            <span>${escapeHtml(search.officer_name)}</span>
        </div>
    `;
    
    return card;
}

// Open search result modal
async function openSearchResult(logId) {
    currentLogId = logId;
    const modal = document.getElementById('search-result-modal');
    const loadingEl = document.getElementById('modal-loading');
    const contentEl = document.getElementById('search-result-content');
    const massReportSection = document.getElementById('mass-report-section');
    
    if (!modal) return;
    
    modal.style.display = 'flex';
    if (loadingEl) loadingEl.style.display = 'block';
    if (contentEl) contentEl.innerHTML = '';
    if (massReportSection) massReportSection.style.display = 'none';
    
    try {
        const response = await fetch(`/api/mass-report/search-result/${logId}`);
        
        if (!response.ok) {
            throw new Error('Failed to load search result');
        }
        
        const data = await response.json();
        currentSearchData = data;
        
        console.log('Loaded search data:', data);
        
        if (loadingEl) loadingEl.style.display = 'none';
        
        displaySearchResult(data);
        displayReportableAccounts(data);
        
        if (massReportSection) massReportSection.style.display = 'block';
    } catch (error) {
        console.error('Error loading search result:', error);
        if (loadingEl) loadingEl.style.display = 'none';
        if (contentEl) {
            contentEl.innerHTML = `
                <div class="empty-state">
                    <h3>Error Loading Results</h3>
                    <p>${escapeHtml(error.message)}</p>
                </div>
            `;
        }
        showToast('Failed to load search result', 'error');
    }
}

// Display search result details
function displaySearchResult(data) {
    const contentEl = document.getElementById('search-result-content');
    if (!contentEl) return;
    
    const searchDate = new Date(data.searched_at);
    const formattedDate = searchDate.toLocaleDateString() + ' ' + searchDate.toLocaleTimeString();
    
    let resultHtml = `
        <div class="search-result-header">
            <h3>Search Query: ${escapeHtml(data.search_query)}</h3>
            <p>Type: ${escapeHtml(data.search_type)} | Date: ${formattedDate}</p>
        </div>
    `;
    
    // Display results based on search type
    if (data.search_type === 'multi-platform') {
        resultHtml += displayMultiPlatformResults(data.result_data);
    } else if (data.search_type === 'single-platform') {
        resultHtml += displaySinglePlatformResults(data.result_data);
    } else {
        resultHtml += '<p>Unknown search type</p>';
    }
    
    contentEl.innerHTML = resultHtml;
}

// Display multi-platform results (results is a list of platform results)
function displayMultiPlatformResults(resultData) {
    console.log('Multi-platform data:', resultData);
    let html = '<div class="platform-results">';
    
    // Check if results is an array
    if (resultData.results && Array.isArray(resultData.results)) {
        resultData.results.forEach(platformResult => {
            const platform = platformResult.platform;
            const platformData = platformResult.instagram_data || platformResult.facebook_data || 
                               platformResult.reddit_data || platformResult.telegram_data;
            
            if (platformData && !platformResult.error) {
                html += `
                    <div class="platform-result">
                        <div class="platform-result-header">
                            <div class="platform-name">${capitalizeFirst(platform)}</div>
                        </div>
                        <div class="platform-result-content">
                            ${formatPlatformData(platform, platformData)}
                        </div>
                    </div>
                `;
            } else if (platformResult.error) {
                html += `
                    <div class="platform-result">
                        <div class="platform-result-header">
                            <div class="platform-name">${capitalizeFirst(platform)}</div>
                        </div>
                        <div class="platform-result-content">
                            <p class="result-detail">Error: ${escapeHtml(platformResult.error)}</p>
                        </div>
                    </div>
                `;
            }
        });
    } else {
        html += '<p class="result-detail">No platform results available</p>';
    }
    
    html += '</div>';
    return html;
}

// Display single platform results (result contains profile, recent_posts, etc.)
function displaySinglePlatformResults(resultData) {
    console.log('Single-platform data:', resultData);
    let html = '<div class="platform-results">';
    
    // Check if result exists
    if (resultData.result) {
        const result = resultData.result;
        const platform = resultData.platform || 'Unknown';
        
        // Display profile data
        if (result.profile) {
            html += `
                <div class="platform-result">
                    <div class="platform-result-header">
                        <div class="platform-name">${capitalizeFirst(platform)} Profile</div>
                    </div>
                    <div class="platform-result-content">
                        ${formatProfileData(result.profile)}
                    </div>
                </div>
            `;
        }
        
        // Display recent posts if available
        if (result.recent_posts && Array.isArray(result.recent_posts) && result.recent_posts.length > 0) {
            html += `
                <div class="platform-result">
                    <div class="platform-result-header">
                        <div class="platform-name">Recent Posts (${result.recent_posts.length})</div>
                    </div>
                    <div class="platform-result-content">
                        <p class="result-detail">${result.recent_posts.length} posts found</p>
                    </div>
                </div>
            `;
        }
        
        // Display error if exists
        if (result.error) {
            html += `<p class="result-detail">Error: ${escapeHtml(result.error)}</p>`;
        }
    } else {
        html += '<p class="result-detail">No result data available</p>';
    }
    
    html += '</div>';
    return html;
}

// Format profile data
function formatProfileData(profile) {
    let html = '';
    
    if (profile.username) {
        html += `<p class="result-detail"><strong>Username:</strong> @${escapeHtml(profile.username)}</p>`;
    }
    
    if (profile.full_name) {
        html += `<p class="result-detail"><strong>Full Name:</strong> ${escapeHtml(profile.full_name)}</p>`;
    }
    
    if (profile.bio || profile.biography) {
        html += `<p class="result-detail"><strong>Bio:</strong> ${escapeHtml(profile.bio || profile.biography)}</p>`;
    }
    
    if (profile.followers_count !== undefined && profile.followers_count !== null) {
        html += `<p class="result-detail"><strong>Followers:</strong> ${formatNumber(profile.followers_count)}</p>`;
    }
    
    if (profile.following_count !== undefined && profile.following_count !== null) {
        html += `<p class="result-detail"><strong>Following:</strong> ${formatNumber(profile.following_count)}</p>`;
    }
    
    if (profile.posts_count !== undefined && profile.posts_count !== null) {
        html += `<p class="result-detail"><strong>Posts:</strong> ${formatNumber(profile.posts_count)}</p>`;
    }
    
    if (profile.is_verified !== undefined) {
        html += `<p class="result-detail"><strong>Verified:</strong> ${profile.is_verified ? 'Yes ✓' : 'No'}</p>`;
    }
    
    if (profile.is_private !== undefined) {
        html += `<p class="result-detail"><strong>Account Type:</strong> ${profile.is_private ? 'Private 🔒' : 'Public'}</p>`;
    }
    
    if (profile.is_business_account) {
        html += `<p class="result-detail"><strong>Business Account:</strong> Yes</p>`;
        if (profile.business_category) {
            html += `<p class="result-detail"><strong>Category:</strong> ${escapeHtml(profile.business_category)}</p>`;
        }
    }
    
    if (profile.external_url) {
        html += `<p class="result-detail"><strong>Website:</strong> <a href="${escapeHtml(profile.external_url)}" target="_blank">${escapeHtml(profile.external_url)}</a></p>`;
    }
    
    if (!html) {
        html = '<p class="result-detail">Limited profile information available</p>';
    }
    
    return html;
}

// Format platform data (for multi-platform)
function formatPlatformData(platform, data) {
    if (!data) {
        return '<p class="result-detail">No data available</p>';
    }
    
    // If data has a profile key, use it
    if (data.profile) {
        return formatProfileData(data.profile);
    }
    
    // Otherwise try to format the data directly
    return formatProfileData(data);
}

// Extract reportable accounts
function extractReportableAccounts(resultData) {
    const accounts = [];
    
    console.log('Extracting accounts from:', resultData);
    
    // Handle multi-platform
    if (resultData.results && Array.isArray(resultData.results)) {
        resultData.results.forEach(platformResult => {
            const platform = platformResult.platform;
            const platformData = platformResult.instagram_data || platformResult.facebook_data || 
                               platformResult.reddit_data || platformResult.telegram_data;
            
            let username = platformResult.username;
            
            // Try to get username from platform data if not in result
            if (!username && platformData) {
                if (platformData.profile && platformData.profile.username) {
                    username = platformData.profile.username;
                } else if (platformData.username) {
                    username = platformData.username;
                }
            }
            
            if (username && !platformResult.error) {
                accounts.push({
                    platform: platform,
                    username: username
                });
            }
        });
    }
    // Handle single-platform
    else if (resultData.result && resultData.result.profile) {
        const username = resultData.result.profile.username || resultData.username;
        const platform = resultData.platform || 'unknown';
        
        if (username) {
            accounts.push({
                platform: platform,
                username: username
            });
        }
    }
    
    console.log('Extracted accounts:', accounts);
    return accounts;
}

// Display reportable accounts
function displayReportableAccounts(data) {
    const accountsEl = document.getElementById('reportable-accounts');
    if (!accountsEl) return;
    
    accountsEl.innerHTML = '';
    
    const accounts = extractReportableAccounts(data.result_data);
    
    if (accounts.length === 0) {
        accountsEl.innerHTML = '<p>No reportable accounts found in this search result.</p>';
        return;
    }
    
    accounts.forEach((account, index) => {
        const accountDiv = document.createElement('label');
        accountDiv.className = 'account-checkbox';
        
        accountDiv.innerHTML = `
            <input type="checkbox" class="report-account-checkbox" value="${account.platform}:${account.username}" id="account-${index}">
            <div class="account-info">
                <div class="account-platform">${capitalizeFirst(account.platform)}</div>
                <div class="account-username">@${escapeHtml(account.username)}</div>
            </div>
        `;
        
        accountsEl.appendChild(accountDiv);
    });
}

// Select all accounts
function selectAllAccounts() {
    const checkboxes = document.querySelectorAll('.report-account-checkbox');
    checkboxes.forEach(cb => cb.checked = true);
}

// Deselect all accounts
function deselectAllAccounts() {
    const checkboxes = document.querySelectorAll('.report-account-checkbox');
    checkboxes.forEach(cb => cb.checked = false);
}

// Submit mass report
async function submitMassReport() {
    const checkboxes = document.querySelectorAll('.report-account-checkbox:checked');
    
    if (checkboxes.length === 0) {
        showToast('Please select at least one account to report', 'warning');
        return;
    }
    
    const platforms = Array.from(checkboxes).map(cb => cb.value);
    
    const confirmMsg = `Are you sure you want to report ${platforms.length} account(s)?`;
    if (!confirm(confirmMsg)) {
        return;
    }
    
    try {
        const response = await fetch('/api/mass-report/mass-report', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                log_id: currentLogId,
                platforms: platforms
            })
        });
        
        if (!response.ok) {
            throw new Error('Failed to submit mass report');
        }
        
        const result = await response.json();
        
        closeMassReportModal();
        showReportResults(result);
        
        showToast('Mass report submitted successfully', 'success');
    } catch (error) {
        console.error('Error submitting mass report:', error);
        showToast('Failed to submit mass report: ' + error.message, 'error');
    }
}

// Show report results
function showReportResults(result) {
    const modal = document.getElementById('report-results-modal');
    const contentEl = document.getElementById('report-results-content');
    
    if (!modal || !contentEl) return;
    
    let html = `
        <div class="report-summary">
            <h3>Report Summary</h3>
            <div class="summary-stats">
                <div class="summary-stat">
                    <div class="summary-stat-value">${result.reported_count}</div>
                    <div class="summary-stat-label">Successful</div>
                </div>
                <div class="summary-stat">
                    <div class="summary-stat-value">${result.failed_count}</div>
                    <div class="summary-stat-label">Failed</div>
                </div>
            </div>
        </div>
        <div class="report-details">
            <h3>Detailed Results</h3>
    `;
    
    result.details.forEach(detail => {
        html += `
            <div class="report-result-item ${detail.status}">
                <div class="report-result-header">
                    <span class="report-result-platform">${capitalizeFirst(detail.platform)} - @${escapeHtml(detail.username)}</span>
                    <span class="report-result-status ${detail.status}">${detail.status}</span>
                </div>
                <div class="report-result-message">${escapeHtml(detail.message)}</div>
            </div>
        `;
    });
    
    html += '</div>';
    
    contentEl.innerHTML = html;
    modal.style.display = 'flex';
}

// Close mass report modal
function closeMassReportModal() {
    const modal = document.getElementById('search-result-modal');
    if (modal) modal.style.display = 'none';
    currentLogId = null;
    currentSearchData = null;
}

// Close report results modal
function closeReportResultsModal() {
    const modal = document.getElementById('report-results-modal');
    if (modal) modal.style.display = 'none';
}

// Utility functions
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function capitalizeFirst(str) {
    if (!str) return '';
    return str.charAt(0).toUpperCase() + str.slice(1);
}

function formatNumber(num) {
    if (num === undefined || num === null) return '0';
    return num.toLocaleString();
}

// Initialize mass reporting page
function initMassReporting() {
    // Load recent searches on page load
    loadRecentSearches();
    
    // Apply filters button
    const applyFiltersBtn = document.getElementById('apply-filters-btn');
    if (applyFiltersBtn) {
        applyFiltersBtn.addEventListener('click', loadRecentSearches);
    }
    
    // Select all button
    const selectAllBtn = document.getElementById('select-all-btn');
    if (selectAllBtn) {
        selectAllBtn.addEventListener('click', selectAllAccounts);
    }
    
    // Deselect all button
    const deselectAllBtn = document.getElementById('deselect-all-btn');
    if (deselectAllBtn) {
        deselectAllBtn.addEventListener('click', deselectAllAccounts);
    }
    
    // Submit mass report button
    const submitBtn = document.getElementById('submit-mass-report-btn');
    if (submitBtn) {
        submitBtn.addEventListener('click', submitMassReport);
    }
    
    // Close modal when clicking outside
    const modals = document.querySelectorAll('.modal-overlay');
    modals.forEach(modal => {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.style.display = 'none';
            }
        });
    });
}

// Export functions for global use
if (typeof window !== 'undefined') {
    window.initMassReporting = initMassReporting;
    window.closeMassReportModal = closeMassReportModal;
    window.closeReportResultsModal = closeReportResultsModal;
}
