// Officer Portal Main Script

// Global state
let currentSection = 'dashboard';
let officerData = null;

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    console.log('🚀 Officer Portal initializing...');
    
    // Check authentication
    if (sessionStorage.getItem('isLoggedIn') !== 'true' || sessionStorage.getItem('userRole') !== 'officer') {
        window.location.href = './login.html';
        return;
    }
    
    // Load officer data
    loadOfficerData();
    
    // Initialize event listeners
    initializeEventListeners();
    
    // Load default section
    loadSection('dashboard');
    
    // Initialize theme
    initializeTheme();
});

// Load officer data from session storage
function loadOfficerData() {
    const storedData = sessionStorage.getItem('officerData');
    if (storedData) {
        officerData = JSON.parse(storedData);
        updateProfileDisplay();
    }
}

// Update profile display in navigation
function updateProfileDisplay() {
    if (officerData) {
        const profileName = document.getElementById('profile-name');
        if (profileName) {
            profileName.textContent = `${officerData.first_name} ${officerData.last_name}`;
        }
    }
}

// Initialize event listeners
function initializeEventListeners() {
    // Navigation links
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const section = link.getAttribute('data-section');
            loadSection(section);
        });
    });
    
    // Profile dropdown
    const profileBtn = document.getElementById('profile-btn');
    const profileDropdown = document.querySelector('.profile-dropdown');
    
    profileBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        profileDropdown.classList.toggle('active');
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', () => {
        profileDropdown.classList.remove('active');
    });
    
    // Dropdown items
    const dropdownItems = document.querySelectorAll('.dropdown-item[data-section]');
    dropdownItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const section = item.getAttribute('data-section');
            loadSection(section);
            profileDropdown.classList.remove('active');
        });
    });
    
    // Theme toggle
    const themeToggle = document.getElementById('theme-toggle');
    themeToggle.addEventListener('click', toggleTheme);
    
    // Logout button
    const logoutBtn = document.getElementById('logout-btn');
    logoutBtn.addEventListener('click', handleLogout);
    
    // Mobile menu toggle
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    const navLinksContainer = document.getElementById('nav-links');
    
    mobileMenuBtn.addEventListener('click', () => {
        navLinksContainer.classList.toggle('active');
    });
}

// Load section content
async function loadSection(section) {
    console.log(`📄 Loading section: ${section}`);
    
    currentSection = section;
    
    // Update active nav link
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        if (link.getAttribute('data-section') === section) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });
    
    // Close mobile menu
    document.getElementById('nav-links').classList.remove('active');
    
    // Load section content
    const mainView = document.getElementById('main-view');
    mainView.innerHTML = '<div class="loading-container"><div class="loading-spinner"></div><p>Loading...</p></div>';
    
    try {
        const response = await fetch(`./views/${section}.html`);
        if (!response.ok) {
            throw new Error(`Failed to load ${section}`);
        }
        
        const html = await response.text();
        mainView.innerHTML = html;
        
        // Initialize section-specific functionality
        initializeSection(section);
        
        // Scroll to top
        window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (error) {
        console.error('Error loading section:', error);
        mainView.innerHTML = `
            <div class="error-container">
                <h2>Error Loading Section</h2>
                <p>${error.message}</p>
            </div>
        `;
    }
}

// Initialize section-specific functionality
function initializeSection(section) {
    switch (section) {
        case 'dashboard':
            initializeDashboard();
            break;
        case 'search':
            initSearchHandlers();
            break;
        case 'profile':
            initializeProfile();
            break;
        case 'reports':
            initializeReports();
            break;
        case 'chatbot':
            // Initialize chatbot when view is loaded
            if (typeof initChatbot === 'function') {
                initChatbot();
            }
            if (typeof initFloatingChatWidget === 'function') {
                initFloatingChatWidget();
            }
            break;
    }
}

// Initialize dashboard
async function initializeDashboard() {
    if (!officerData) return;
    
    try {
        const response = await fetch(`/api/dashboard/${officerData.id}`);
        if (!response.ok) throw new Error('Failed to load dashboard data');
        
        const data = await response.json();
        console.log('📊 Dashboard data:', data);
        
        // Update dashboard stats
        updateDashboardStats(data);
    } catch (error) {
        console.error('Error loading dashboard:', error);
        showToast('Failed to load dashboard data', 'error');
    }
}

// Update dashboard statistics
function updateDashboardStats(data) {
    // Update stat cards
    const stats = {
        'total-searches': data.activity_stats.total_searches,
        'total-reports': data.activity_stats.total_reports,
        'searches-week': data.activity_stats.searches_this_week,
        'searches-month': data.activity_stats.searches_this_month
    };
    
    Object.entries(stats).forEach(([id, value]) => {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = value;
        }
    });
    
    // Update recent searches
    const recentSearchesList = document.getElementById('recent-searches-list');
    if (recentSearchesList && data.recent_searches) {
        recentSearchesList.innerHTML = data.recent_searches.map(search => `
            <div class="recent-search-item">
                <div class="search-info">
                    <span class="search-query">${escapeHtml(search.search_query)}</span>
                    <span class="search-type">${search.search_type}</span>
                </div>
                <span class="search-date">${formatDate(search.searched_at)}</span>
            </div>
        `).join('');
    }
    
    // Update search type breakdown
    const searchTypeChart = document.getElementById('search-type-chart');
    if (searchTypeChart && data.search_type_breakdown) {
        renderSearchTypeChart(searchTypeChart, data.search_type_breakdown);
    }
}

// Render search type chart
function renderSearchTypeChart(container, data) {
    const total = data.reduce((sum, item) => sum + item.count, 0);
    
    container.innerHTML = data.map(item => {
        const percentage = ((item.count / total) * 100).toFixed(1);
        return `
            <div class="chart-bar">
                <div class="bar-label">${item.search_type}</div>
                <div class="bar-container">
                    <div class="bar-fill" style="width: ${percentage}%"></div>
                </div>
                <div class="bar-value">${item.count}</div>
            </div>
        `;
    }).join('');
}

// Initialize profile
function initializeProfile() {
    if (!officerData) return;
    
    // Populate profile form
    const fields = {
        'profile-first-name': officerData.first_name,
        'profile-last-name': officerData.last_name,
        'profile-email': officerData.email,
        'profile-phone': officerData.phone_no,
        'profile-gender': officerData.gender,
        'profile-dob': officerData.dob
    };
    
    Object.entries(fields).forEach(([id, value]) => {
        const element = document.getElementById(id);
        if (element) {
            element.value = value || '';
        }
    });
    
    // Handle profile form submission
    const profileForm = document.getElementById('profile-form');
    if (profileForm) {
        profileForm.addEventListener('submit', handleProfileUpdate);
    }
}

// Handle profile update
async function handleProfileUpdate(e) {
    e.preventDefault();
    
    const formData = {
        first_name: document.getElementById('profile-first-name').value,
        last_name: document.getElementById('profile-last-name').value,
        email: document.getElementById('profile-email').value,
        phone_no: document.getElementById('profile-phone').value,
        gender: document.getElementById('profile-gender').value,
        dob: document.getElementById('profile-dob').value
    };
    
    try {
        const response = await fetch(`/api/officers/${officerData.id}`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${sessionStorage.getItem('accessToken')}`
            },
            body: JSON.stringify(formData)
        });
        
        if (!response.ok) throw new Error('Failed to update profile');
        
        const data = await response.json();
        
        // Update stored officer data
        officerData = data.officer;
        sessionStorage.setItem('officerData', JSON.stringify(officerData));
        sessionStorage.setItem('accessToken', data.access_token);
        
        // Update profile display
        updateProfileDisplay();
        
        showToast('Profile updated successfully!', 'success');
    } catch (error) {
        console.error('Error updating profile:', error);
        showToast('Failed to update profile', 'error');
    }
}

// Initialize reports
function initializeReports() {
    // Reports functionality will be similar to admin panel
    // Load search logs, implement filtering, etc.
}

// Theme management
function initializeTheme() {
    const savedTheme = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', savedTheme);
    updateThemeIcon(savedTheme);
}

function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    updateThemeIcon(newTheme);
}

function updateThemeIcon(theme) {
    const themeIcon = document.getElementById('theme-icon');
    if (themeIcon) {
        if (theme === 'dark') {
            themeIcon.innerHTML = `
                <path d="M12 3V4M12 20V21M4 12H3M6.31412 6.31412L5.5 5.5M17.6859 6.31412L18.5 5.5M6.31412 17.69L5.5 18.5M17.6859 17.69L18.5 18.5M21 12H20M16 12C16 14.2091 14.2091 16 12 16C9.79086 16 8 14.2091 8 12C8 9.79086 9.79086 8 12 8C14.2091 8 16 9.79086 16 12Z" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
            `;
        } else {
            themeIcon.innerHTML = `
                <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" stroke="currentColor" stroke-width="2"/>
            `;
        }
    }
}

// Logout handler
function handleLogout(e) {
    e.preventDefault();
    
    // Clear session storage
    sessionStorage.clear();
    
    // Redirect to login
    window.location.href = './login.html';
}

// Toast notification system
function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;
    
    const toast = document.createElement('div');
    toast.className = 'toast';
    
    const icons = {
        success: '✅',
        error: '❌',
        warning: '⚠️',
        info: 'ℹ️'
    };
    
    toast.innerHTML = `
        <div class="toast-icon">${icons[type] || icons.info}</div>
        <div class="toast-content">
            <div class="toast-title">${type.charAt(0).toUpperCase() + type.slice(1)}</div>
            <div class="toast-message">${escapeHtml(message)}</div>
        </div>
        <button class="toast-close">×</button>
    `;
    
    container.appendChild(toast);
    
    // Close button
    toast.querySelector('.toast-close').addEventListener('click', () => {
        toast.remove();
    });
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        toast.remove();
    }, 5000);
}

// Utility functions
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function formatDate(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now - date;
    
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    
    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    if (days < 7) return `${days}d ago`;
    
    return date.toLocaleDateString();
}

function formatNumber(num) {
    if (num >= 1000000) {
        return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
        return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
}

// Loading spinner styles
const style = document.createElement('style');
style.textContent = `
    .loading-container {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 60px 20px;
    }
    
    .loading-spinner {
        width: 48px;
        height: 48px;
        border: 4px solid var(--border-color);
        border-top-color: var(--primary-teal);
        border-radius: 50%;
        animation: spin 0.8s linear infinite;
    }
    
    @keyframes spin {
        to { transform: rotate(360deg); }
    }
    
    .loading-container p {
        margin-top: 16px;
        color: var(--text-secondary);
        font-size: 14px;
    }
    
    .error-container {
        padding: 40px;
        text-align: center;
    }
    
    .error-container h2 {
        color: var(--danger-color);
        margin-bottom: 12px;
    }
    
    .error-container p {
        color: var(--text-secondary);
    }
`;
document.head.appendChild(style);
