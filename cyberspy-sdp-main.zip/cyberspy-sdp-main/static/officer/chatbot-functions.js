// Chatbot Functions
let conversationId = null;
let messageHistory = [];

const CHATBOT_API_BASE = '/api/chatbot';

// Initialize chatbot
function initChatbot() {
    const input = document.getElementById('chatbot-input');
    const sendBtn = document.getElementById('send-btn');
    const clearBtn = document.getElementById('clear-chat-btn');
    const messagesContainer = document.getElementById('chatbot-messages');

    // Auto-resize textarea
    if (input) {
        input.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = Math.min(this.scrollHeight, 120) + 'px';
            updateCharCount();
        });

        // Send on Enter (Shift+Enter for new line)
        input.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
            }
        });
    }

    // Send button
    if (sendBtn) {
        sendBtn.addEventListener('click', sendMessage);
    }

    // Clear chat button
    if (clearBtn) {
        clearBtn.addEventListener('click', clearChat);
    }

    // Load conversation history if exists
    loadConversationHistory();
}

function updateCharCount() {
    const input = document.getElementById('chatbot-input');
    const charCount = document.getElementById('char-count');
    if (!input || !charCount) return;

    const length = input.value.length;
    charCount.textContent = `${length} / 2000`;

    if (length > 1800) {
        charCount.classList.add('error');
        charCount.classList.remove('warning');
    } else if (length > 1500) {
        charCount.classList.add('warning');
        charCount.classList.remove('error');
    } else {
        charCount.classList.remove('warning', 'error');
    }
}

async function sendMessage() {
    const input = document.getElementById('chatbot-input');
    const sendBtn = document.getElementById('send-btn');
    const messagesContainer = document.getElementById('chatbot-messages');
    const typingIndicator = document.getElementById('typing-indicator');

    if (!input || !messagesContainer) return;

    const message = input.value.trim();
    if (!message) return;

    // Disable input
    input.disabled = true;
    if (sendBtn) sendBtn.disabled = true;

    // Remove welcome message if exists
    const welcomeMsg = messagesContainer.querySelector('.welcome-message');
    if (welcomeMsg) {
        welcomeMsg.remove();
    }

    // Add user message
    addMessage('user', message);

    // Clear input
    input.value = '';
    input.style.height = 'auto';
    updateCharCount();

    // Show typing indicator
    if (typingIndicator) {
        typingIndicator.style.display = 'block';
    }

    try {
        // Get user ID from session if available
        const userId = sessionStorage.getItem('userId') || null;

        // Show loading state on send button
        if (sendBtn) sendBtn.classList.add('loading');

        const response = await fetch(`${CHATBOT_API_BASE}/chat`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                message: message,
                conversation_id: conversationId,
                user_id: userId,
                user_type: 'officer'
            })
        });

        // Parse response safely (it might not always be valid JSON)
        let data;
        try {
            data = await response.json();
        } catch (e) {
            const text = await response.text();
            throw new Error(text || 'Failed to parse response from server');
        }

        if (!response.ok) {
            const detailMsg = data?.detail?.message || data?.detail?.error || data?.detail || data?.error || JSON.stringify(data);
            throw new Error(detailMsg || 'Failed to get response from server');
        }

        // Update conversation ID
        if (data.conversation_id) {
            conversationId = data.conversation_id;
        }

        // Add assistant message
        addMessage('assistant', data.answer, {
            sources: data.sources,
            warnings: data.warnings,
            timestamp: data.timestamp
        });

        // Save to history
        messageHistory.push({
            question: message,
            answer: data.answer,
            timestamp: data.timestamp
        });

        // Save conversation
        saveConversationHistory();

    } catch (error) {
        console.error('Chat error:', error);
        addMessage('assistant', `Error: ${error.message}`, { isError: true });
    } finally {
        // Re-enable input
        input.disabled = false;
        if (sendBtn) {
            sendBtn.disabled = false;
            sendBtn.classList.remove('loading');
        }
        if (typingIndicator) typingIndicator.style.display = 'none';
        input.focus();

        // Scroll to bottom
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
}

function addMessage(role, text, options = {}) {
    const messagesContainer = document.getElementById('chatbot-messages');
    if (!messagesContainer) return;

    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${role}${options.isError ? ' error' : ''}`;

    const avatar = document.createElement('div');
    avatar.className = 'message-avatar';
    avatar.textContent = role === 'user' ? 'U' : 'AI';

    const content = document.createElement('div');
    content.className = 'message-content';

    const bubble = document.createElement('div');
    bubble.className = 'message-bubble';

    const textDiv = document.createElement('p');
    textDiv.className = 'message-text';
    textDiv.textContent = text;

    bubble.appendChild(textDiv);

    // Add timestamp
    if (options.timestamp) {
        const timeDiv = document.createElement('div');
        timeDiv.className = 'message-time';
        const date = new Date(options.timestamp);
        timeDiv.textContent = date.toLocaleTimeString();
        bubble.appendChild(timeDiv);
    }

    // Add sources if available
    if (options.sources && options.sources.length > 0) {
        const sourcesDiv = document.createElement('div');
        sourcesDiv.className = 'message-sources';
        const sourcesTitle = document.createElement('div');
        sourcesTitle.className = 'message-sources-title';
        sourcesTitle.textContent = 'Sources:';
        const sourcesList = document.createElement('ul');
        sourcesList.className = 'message-sources-list';
        options.sources.forEach(source => {
            const li = document.createElement('li');
            li.textContent = source.split('/').pop() || source;
            sourcesList.appendChild(li);
        });
        sourcesDiv.appendChild(sourcesTitle);
        sourcesDiv.appendChild(sourcesList);
        bubble.appendChild(sourcesDiv);
    }

    // Add warnings if available
    if (options.warnings && options.warnings.length > 0) {
        const warningsDiv = document.createElement('div');
        warningsDiv.className = 'message-warnings';
        warningsDiv.textContent = `⚠️ ${options.warnings.join(', ')}`;
        bubble.appendChild(warningsDiv);
    }

    content.appendChild(bubble);
    messageDiv.appendChild(avatar);
    messageDiv.appendChild(content);
    messagesContainer.appendChild(messageDiv);

    // Scroll to bottom
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

function clearChat() {
    if (!confirm('Are you sure you want to clear the chat history?')) {
        return;
    }

    const messagesContainer = document.getElementById('chatbot-messages');
    if (!messagesContainer) return;

    // Clear messages
    messagesContainer.innerHTML = `
        <div class="welcome-message">
            <div class="welcome-icon">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M21 15C21 15.5304 20.7893 16.0391 20.4142 16.4142C20.0391 16.7893 19.5304 17 19 17H7L3 21V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V15Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
            </div>
            <h2>Welcome to AI Assistant</h2>
            <p>I can help you with:</p>
            <ul class="help-topics">
                <li>Understanding system features</li>
                <li>How to use search functionality</li>
                <li>API documentation</li>
                <li>Troubleshooting issues</li>
                <li>Best practices</li>
            </ul>
            <p class="help-hint">Type your question below to get started!</p>
        </div>
    `;

    // Reset conversation
    conversationId = null;
    messageHistory = [];
    saveConversationHistory();
}

function saveConversationHistory() {
    try {
        const data = {
            conversationId: conversationId,
            messages: messageHistory,
            timestamp: new Date().toISOString()
        };
        sessionStorage.setItem('chatbot_history', JSON.stringify(data));
    } catch (error) {
        console.error('Error saving conversation history:', error);
    }
}

function loadConversationHistory() {
    try {
        const saved = sessionStorage.getItem('chatbot_history');
        if (!saved) return;

        const data = JSON.parse(saved);
        conversationId = data.conversationId;
        messageHistory = data.messages || [];

        // Restore messages if any
        if (messageHistory.length > 0) {
            const messagesContainer = document.getElementById('chatbot-messages');
            if (messagesContainer) {
                messagesContainer.innerHTML = '';
                messageHistory.forEach(msg => {
                    addMessage('user', msg.question);
                    addMessage('assistant', msg.answer, {
                        timestamp: msg.timestamp
                    });
                });
            }
        }
    } catch (error) {
        console.error('Error loading conversation history:', error);
    }
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initChatbot);
} else {
    initChatbot();
}

// ========================================
// FLOATING CHAT WIDGET FUNCTIONALITY
// ========================================

let widgetConversationId = null;
let widgetMessageHistory = [];

function initFloatingChatWidget() {
    const toggleBtn = document.getElementById('ai-chat-toggle');
    const window = document.getElementById('ai-chat-window');
    const minimizeBtn = document.getElementById('ai-chat-minimize');
    const widgetInput = document.getElementById('ai-chat-widget-input');
    const widgetSendBtn = document.getElementById('ai-chat-widget-send');
    const widgetMessages = document.getElementById('ai-chat-widget-messages');

    if (!toggleBtn || !window) return;

    // Toggle window
    toggleBtn.addEventListener('click', () => {
        const isOpen = window.classList.contains('open');
        if (isOpen) {
            closeWidget();
        } else {
            openWidget();
        }
    });

    // Minimize button
    if (minimizeBtn) {
        minimizeBtn.addEventListener('click', () => {
            closeWidget();
        });
    }

    // Auto-resize textarea
    if (widgetInput) {
        widgetInput.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = Math.min(this.scrollHeight, 100) + 'px';
        });

        // Send on Enter (Shift+Enter for new line)
        widgetInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                sendWidgetMessage();
            }
        });
    }

    // Send button
    if (widgetSendBtn) {
        widgetSendBtn.addEventListener('click', sendWidgetMessage);
    }

    // Load conversation history
    loadWidgetConversationHistory();
}

function openWidget() {
    const window = document.getElementById('ai-chat-window');
    const toggleBtn = document.getElementById('ai-chat-toggle');
    if (window && toggleBtn) {
        window.classList.add('open');
        toggleBtn.classList.add('active');
        const input = document.getElementById('ai-chat-widget-input');
        if (input) {
            setTimeout(() => input.focus(), 300);
        }
    }
}

function closeWidget() {
    const window = document.getElementById('ai-chat-window');
    const toggleBtn = document.getElementById('ai-chat-toggle');
    if (window && toggleBtn) {
        window.classList.remove('open');
        toggleBtn.classList.remove('active');
    }
}

async function sendWidgetMessage() {
    const input = document.getElementById('ai-chat-widget-input');
    const sendBtn = document.getElementById('ai-chat-widget-send');
    const messagesContainer = document.getElementById('ai-chat-widget-messages');

    if (!input || !messagesContainer) return;

    const message = input.value.trim();
    if (!message) return;

    // Remove welcome message
    const welcome = messagesContainer.querySelector('.ai-chat-widget-welcome');
    if (welcome) {
        welcome.remove();
    }

    // Add user message
    addWidgetMessage('user', message);

    // Clear input
    input.value = '';
    input.style.height = 'auto';

    // Disable input
    input.disabled = true;
    if (sendBtn) sendBtn.disabled = true;

    try {
        const userId = sessionStorage.getItem('userId') || null;

        if (sendBtn) sendBtn.classList.add('loading');

        const response = await fetch(`${CHATBOT_API_BASE}/chat`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                message: message,
                conversation_id: widgetConversationId,
                user_id: userId,
                user_type: 'officer'
            })
        });

        let data;
        try {
            data = await response.json();
        } catch (e) {
            const text = await response.text();
            throw new Error(text || 'Failed to parse response from server');
        }

        if (!response.ok) {
            const detailMsg = data?.detail?.message || data?.detail?.error || data?.detail || data?.error || JSON.stringify(data);
            throw new Error(detailMsg || 'Failed to get response from server');
        }

        // Update conversation ID
        if (data.conversation_id) {
            widgetConversationId = data.conversation_id;
        }

        // Add assistant message
        addWidgetMessage('assistant', data.answer, {
            timestamp: data.timestamp
        });

        // Save to history
        widgetMessageHistory.push({
            question: message,
            answer: data.answer,
            timestamp: data.timestamp
        });

        // Save conversation
        saveWidgetConversationHistory();

    } catch (error) {
        console.error('Widget chat error:', error);
        addWidgetMessage('assistant', `Error: ${error.message}`, { isError: true });
    } finally {
        // Re-enable input
        input.disabled = false;
        if (sendBtn) {
            sendBtn.disabled = false;
            sendBtn.classList.remove('loading');
        }
        input.focus();

        // Scroll to bottom
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
}

function addWidgetMessage(role, text, options = {}) {
    const messagesContainer = document.getElementById('ai-chat-widget-messages');
    if (!messagesContainer) return;

    const messageDiv = document.createElement('div');
    messageDiv.className = `ai-chat-widget-message ${role}${options.isError ? ' error' : ''}`;

    const avatar = document.createElement('div');
    avatar.className = 'ai-chat-widget-message-avatar';
    avatar.textContent = role === 'user' ? 'U' : 'AI';

    const content = document.createElement('div');
    content.className = 'ai-chat-widget-message-content';

    const bubble = document.createElement('div');
    bubble.className = 'ai-chat-widget-message-bubble';
    bubble.textContent = text;

    content.appendChild(bubble);
    messageDiv.appendChild(avatar);
    messageDiv.appendChild(content);
    messagesContainer.appendChild(messageDiv);

    // Scroll to bottom
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

function saveWidgetConversationHistory() {
    try {
        const data = {
            conversationId: widgetConversationId,
            messages: widgetMessageHistory,
            timestamp: new Date().toISOString()
        };
        sessionStorage.setItem('chatbot_widget_history', JSON.stringify(data));
    } catch (error) {
        console.error('Error saving widget conversation history:', error);
    }
}

function loadWidgetConversationHistory() {
    try {
        const saved = sessionStorage.getItem('chatbot_widget_history');
        if (!saved) return;

        const data = JSON.parse(saved);
        widgetConversationId = data.conversationId;
        widgetMessageHistory = data.messages || [];

        // Restore messages if any
        if (widgetMessageHistory.length > 0) {
            const messagesContainer = document.getElementById('ai-chat-widget-messages');
            if (messagesContainer) {
                const welcome = messagesContainer.querySelector('.ai-chat-widget-welcome');
                if (welcome) welcome.remove();
                
                widgetMessageHistory.forEach(msg => {
                    addWidgetMessage('user', msg.question);
                    addWidgetMessage('assistant', msg.answer, {
                        timestamp: msg.timestamp
                    });
                });
            }
        }
    } catch (error) {
        console.error('Error loading widget conversation history:', error);
    }
}

// Initialize floating widget when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initFloatingChatWidget);
} else {
    initFloatingChatWidget();
}

