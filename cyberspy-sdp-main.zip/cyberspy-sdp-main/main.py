import uvicorn
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def main():
    
    # Configuration
    HOST = os.getenv("HOST", "0.0.0.0")
    PORT = int(os.getenv("PORT", "8000"))
    RELOAD = os.getenv("RELOAD", "True").lower() == "true"
    LOG_LEVEL = os.getenv("LOG_LEVEL", "info")
    
    print("=" * 60)
    print("🚀 Starting Activity Monitoring Backend Server")
    print("=" * 60)
    print(f"📍 Host: {HOST}")
    print(f"🔌 Port: {PORT}")
    print(f"🔄 Auto-reload: {RELOAD}")
    print(f"📊 Log Level: {LOG_LEVEL}")
    print("=" * 60)
    print(f"🌐 Server will be available at: http://localhost:{PORT}")
    print(f"📚 API Documentation: http://localhost:{PORT}/docs")
    print(f"🔍 Alternative Docs: http://localhost:{PORT}/redoc")
    print("=" * 60)
    print("\n💡 TIP: You can now set breakpoints in your IDE and debug!")
    print("Press CTRL+C to stop the server\n")
    
    uvicorn.run(
        "app.main:app",
        host=HOST,
        port=PORT,  
        reload=RELOAD,
        log_level=LOG_LEVEL,
    )


if __name__ == "__main__":
    main()
