# Activity Monitoring Backend

> **AI-Powered Cyber-Crime Investigation Platform**

A comprehensive FastAPI-based backend system for law enforcement officers to search, analyze, and report on social media profiles with AI-driven risk assessment and intelligent chatbot assistance.

## 🌟 Key Features

- **🔍 Multi-Platform Search**: Search across Instagram, Facebook, Reddit, and Telegram
- **🤖 AI Analysis**: Google Gemini-powered cybercrime risk assessment
- **💬 RAG Chatbot**: Intelligent assistant with retrieval-augmented generation
- **📊 Advanced Dashboard**: Real-time analytics and activity tracking
- **📝 Comprehensive Reporting**: Generate and manage investigation reports
- **🎯 Mass Reporting**: Batch reporting across multiple platforms
- **👮 Officer Management**: Secure authentication and role-based access
- **🔐 Security**: JWT authentication, rate limiting, and input validation

## 🚀 Quick Start

### Prerequisites

- Python 3.11 or higher
- pip (Python package manager)
- Google Gemini API key ([Get one here](https://aistudio.google.com))

### Installation

1. **Clone the repository**:
   ```bash
   git clone <repository-url>
   cd activity_monitoring_backend
   ```

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Configure environment**:
   
   Create a `.env` file in the root directory:
   ```env
   APP_NAME=Activity Monitoring Backend
   API_PREFIX=/api
   DATABASE_URL=sqlite:///./activity_monitoring.db
   DEBUG=true
   GEMINI_API_KEY=your_gemini_api_key_here
   SECRET_KEY=your_secret_key_for_jwt_signing
   CHATBOT_ENABLED=true
   CHATBOT_MAX_REQUESTS_PER_MINUTE=10
   CHATBOT_MAX_REQUESTS_PER_HOUR=100
   ```

4. **Run the server**:
   
   **Option 1 - Using uvicorn**:
   ```bash
   uvicorn app.main:app --reload
   ```
   
   **Option 2 - Using main.py (supports debugging)**:
   ```bash
   python main.py
   ```

5. **Access the application**:
   - **Admin Panel**: http://localhost:8000
   - **API Documentation**: http://localhost:8000/docs
   - **Alternative Docs**: http://localhost:8000/redoc
   - **Health Check**: http://localhost:8000/api/health

## 📁 Project Structure

```
activity_monitoring_backend/
├── app/
│   ├── api/
│   │   └── routes/          # API endpoint definitions
│   │       ├── search.py    # Multi-platform search
│   │       ├── chatbot.py   # RAG chatbot
│   │       ├── dashboard.py # Analytics & stats
│   │       ├── officers.py  # Officer management
│   │       ├── reports.py   # Report management
│   │       ├── mass_report.py # Mass reporting
│   │       └── ...
│   ├── core/
│   │   ├── config.py        # Configuration settings
│   │   └── security.py      # Password hashing
│   ├── db/
│   │   └── session.py       # Database connection
│   ├── models/              # SQLAlchemy models
│   ├── schemas/             # Pydantic schemas
│   ├── services/            # Business logic
│   │   ├── gemini_analyzer.py    # AI analysis
│   │   ├── rag_service.py        # RAG chatbot
│   │   ├── guardrails.py         # Safety checks
│   │   ├── platform_search.py    # Social media search
│   │   └── ...
│   └── main.py              # FastAPI application
├── static/                  # Admin panel (HTML/CSS/JS)
├── system_docs/             # Documentation
│   ├── 01_system_overview.md
│   ├── 02_api_documentation.md
│   ├── 03_usage_guide.md
│   └── 04_troubleshooting.md
├── search_results/          # Stored search results (JSON)
├── chroma_db/              # Vector database for RAG
├── main.py                 # Server entry point
├── requirements.txt        # Python dependencies
└── .env                    # Environment variables
```

## 🔧 Core Technologies

### Backend
- **FastAPI**: Modern, high-performance web framework
- **SQLAlchemy**: SQL toolkit and ORM
- **Pydantic**: Data validation using Python type hints
- **Uvicorn**: ASGI server

### AI & ML
- **Google Gemini 2.5 Flash Lite**: Large language model for analysis
- **LangChain**: Framework for RAG implementation
- **Sentence Transformers**: Text embeddings (all-MiniLM-L6-v2)
- **ChromaDB/SQLite**: Vector storage for RAG

### Security
- **JWT**: Token-based authentication
- **bcrypt**: Password hashing
- **Pydantic**: Input validation
- **Custom guardrails**: Rate limiting, content filtering

### Data Collection
- **Instaloader**: Instagram data scraping
- **Custom scrapers**: Other platforms (placeholder)

## 📊 Database Schema

### Core Tables

1. **officers**: User accounts and profiles
2. **cities**: Geographic locations
3. **branches**: Department/station information
4. **search_types**: Investigation categories
5. **result_logs**: Search history and results
6. **report_logs**: Reporting actions and outcomes
7. **officer_login_logs**: Authentication audit trail
8. **document_embeddings**: RAG vector storage

## 🔌 API Endpoints

### Search APIs (`/api/search`)
- `POST /multi-platform` - Search all platforms
- `POST /single-platform` - Deep single platform search
- `POST /hashtag-search` - Instagram hashtag/keyword search
- `POST /tracking` - Start profile tracking
- `GET /tracking/{id}` - Get tracking status
- `GET /recent/{officer_id}` - Recent searches

### Officer APIs (`/api/officers`)
- `GET /` - List officers
- `POST /` - Create officer
- `GET /{id}` - Get officer details
- `PATCH /{id}` - Update officer
- `POST /login` - Authenticate
- `POST /{id}/login-log` - Log login
- `GET /{id}/login-log` - Login history

### Dashboard APIs (`/api/dashboard`)
- `GET /officer/{id}` - Complete dashboard
- `GET /activity-timeline/{id}` - Activity chart
- `GET /quick-stats/{id}` - Quick statistics

### Report APIs (`/api/reports`)
- `GET /` - List reports
- `POST /` - Create report
- `GET /filter` - Advanced filtering
- `GET /statistics` - Report analytics
- `GET /{id}` - Get specific report

### Chatbot APIs (`/api/chatbot`)
- `POST /chat` - Send message
- `GET /chat/health` - Service status
- `GET /chat/conversation/{id}` - Get history
- `DELETE /chat/conversation/{id}` - Delete conversation

### Mass Report APIs (`/api/mass-report`)
- `GET /recent-searches` - Get searches
- `GET /search-result/{id}` - Get result data
- `POST /report` - Create mass reports

### Admin APIs (`/api/admin`)
- `GET /reports/detailed` - Cross-officer analytics
- `GET /reports/statistics` - System-wide stats

**Full API documentation**: http://localhost:8000/docs

## 🤖 AI Features

### Cybercrime Risk Assessment

The system uses Google Gemini to analyze profiles for:

- **Risk Scoring**: 0-100 scale with categorization
  - Low (0-25): No significant concerns
  - Medium (26-50): Minor concerns, monitoring recommended
  - High (51-75): Significant concerns, investigation needed
  - Critical (76-100): Immediate attention required

- **Indicator Detection**:
  - Scam/fraud patterns
  - Harassment or threats
  - Illegal activity markers
  - Identity theft signals
  - Misinformation spreading
  - Suspicious behavior patterns

- **Content Analysis**:
  - Theme extraction
  - Sentiment analysis
  - Behavioral patterns
  - Engagement metrics

### RAG Chatbot

The intelligent chatbot provides:

- **System Guidance**: How to use features
- **API Help**: Endpoint usage and examples
- **Troubleshooting**: Common issues and solutions
- **Context-Aware**: Remembers conversation history
- **Source Citations**: References documentation

**Guardrails**:
- Rate limiting (10/min, 100/hour)
- Content filtering
- Input sanitization
- Response safety checks

## 🔐 Security Features

### Authentication
- JWT token-based authentication
- 7-day token expiration
- Secure password hashing (bcrypt)
- Session management

### Input Validation
- Pydantic schema validation
- SQL injection prevention
- XSS attack prevention
- Input sanitization

### Rate Limiting
- Chatbot: 10 requests/minute, 100/hour
- IP-based limiting
- Request tracking

### Content Safety
- Inappropriate content filtering
- Malicious pattern detection
- Response sanitization

## 📖 Documentation

Comprehensive documentation is available in the `system_docs/` directory:

1. **[System Overview](system_docs/01_system_overview.md)**: Complete feature list and architecture
2. **[API Documentation](system_docs/02_api_documentation.md)**: Detailed API reference with examples
3. **[Usage Guide](system_docs/03_usage_guide.md)**: Step-by-step instructions for officers and admins
4. **[Troubleshooting](system_docs/04_troubleshooting.md)**: Common issues and solutions

## 🚀 Deployment

### Development
```bash
python main.py
```

### Production

**Using Uvicorn**:
```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers 4
```

**Using Gunicorn**:
```bash
gunicorn app.main:app -w 4 -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000
```

### Environment Variables for Production

```env
DEBUG=false
DATABASE_URL=postgresql://user:pass@localhost/dbname
SECRET_KEY=generate_a_strong_random_key
GEMINI_API_KEY=your_production_api_key
CHATBOT_ENABLED=true
```

### Cloud Deployment

The application is compatible with:
- **Vercel**: Serverless deployment
- **Render**: Container deployment
- **AWS/GCP/Azure**: VM or container deployment

**Note**: Static files (admin panel) are disabled on Vercel. Use API only or deploy admin panel separately.

## ⚙️ Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `APP_NAME` | Application name | "Activity Monitoring Backend" |
| `API_PREFIX` | API route prefix | "/api" |
| `DATABASE_URL` | Database connection string | "sqlite:///./activity_monitoring.db" |
| `DEBUG` | Debug mode | true |
| `GEMINI_API_KEY` | Google Gemini API key | "" |
| `SECRET_KEY` | JWT signing key | (required for production) |
| `CHATBOT_ENABLED` | Enable chatbot | true |
| `CHATBOT_MAX_REQUESTS_PER_MINUTE` | Rate limit | 10 |
| `CHATBOT_MAX_REQUESTS_PER_HOUR` | Rate limit | 100 |
| `SENTENCE_TRANSFORMER_MODEL` | Embedding model | "all-MiniLM-L6-v2" |

### Database Configuration

**SQLite (Development)**:
```env
DATABASE_URL=sqlite:///./activity_monitoring.db
```

**PostgreSQL (Production)**:
```env
DATABASE_URL=postgresql://user:password@localhost:5432/dbname
```

**MySQL (Production)**:
```env
DATABASE_URL=mysql://user:password@localhost:3306/dbname
```

## 🧪 Testing

### Manual Testing

Use the interactive API documentation:
```
http://localhost:8000/docs
```

### API Testing with curl

**Health Check**:
```bash
curl http://localhost:8000/api/health
```

**Login**:
```bash
curl -X POST "http://localhost:8000/api/officers/login" \
  -H "Content-Type: application/json" \
  -d '{"email": "officer@example.com", "password": "password"}'
```

**Search**:
```bash
curl -X POST "http://localhost:8000/api/search/single-platform" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -d '{"username": "target", "platform": "instagram", "officer_id": 1}'
```

## 🛠️ Development

### Adding New Features

1. Create model in `app/models/`
2. Create schema in `app/schemas/`
3. Create service in `app/services/`
4. Create route in `app/api/routes/`
5. Register route in `app/api/routes/__init__.py`
6. Update documentation

### Database Migrations

**Using Alembic** (recommended for production):
```bash
# Install Alembic
pip install alembic

# Initialize
alembic init alembic

# Create migration
alembic revision --autogenerate -m "description"

# Apply migration
alembic upgrade head
```

### Code Style

- Follow PEP 8
- Use type hints
- Document functions with docstrings
- Keep functions focused and small

## 📝 Notes and Best Practices

### For Development

- **Database**: SQLite is fine for development
- **Migrations**: Use `create_all()` for quick prototyping
- **Debug Mode**: Keep `DEBUG=true` for detailed errors
- **CORS**: `allow_origins=["*"]` is acceptable

### For Production

- **Database**: Use PostgreSQL or MySQL
- **Migrations**: Implement Alembic for schema changes
- **Debug Mode**: Set `DEBUG=false`
- **CORS**: Specify exact origins
- **Secret Key**: Use strong, random key
- **HTTPS**: Always use HTTPS in production
- **Rate Limiting**: Implement stricter limits
- **Monitoring**: Set up logging and monitoring
- **Backups**: Regular database backups

### Instagram Scraping

- **Rate Limits**: Instagram has strict rate limits
- **Delays**: Space out searches (30-60 seconds)
- **User Agents**: System rotates automatically
- **Sessions**: Auto-reset after 3 requests
- **Private Profiles**: Limited data available

### AI Usage

- **API Quotas**: Monitor Gemini API usage
- **Costs**: Free tier has limits
- **Fallback**: System works without AI (manual analysis)
- **Verification**: Always verify AI findings manually

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Update documentation
6. Submit a pull request

## 📄 License

[Specify your license here]

## 🆘 Support

- **Documentation**: See `system_docs/` directory
- **API Docs**: http://localhost:8000/docs
- **Chatbot**: Ask questions via `/api/chatbot/chat`
- **Issues**: Report bugs on GitHub
- **Contact**: [Your contact information]

## 🙏 Acknowledgments

- **FastAPI**: For the excellent web framework
- **Google Gemini**: For AI capabilities
- **LangChain**: For RAG implementation
- **Instaloader**: For Instagram data access
- **Community**: For open-source contributions

---

**Built with ❤️ for law enforcement cyber-crime investigations**
