"""
SQLite-based Vector Store for RAG
Stores embeddings as JSON in SQLite and performs similarity search
"""
import json
import logging
import numpy as np
from typing import List, Dict, Optional
from sqlalchemy.orm import Session

from app.models.document_embedding import DocumentEmbedding
from app.db.session import SessionLocal

logger = logging.getLogger(__name__)


class SQLiteVectorStore:
    """Vector store implementation using SQLite with JSON embeddings"""
    
    def __init__(self, embedding_function):
        """
        Initialize SQLite vector store
        
        Args:
            embedding_function: Function that generates embeddings (e.g., SentenceTransformerEmbeddings)
        """
        self.embedding_function = embedding_function
        self._db = None
    
    @property
    def db(self):
        """Get database session"""
        if self._db is None:
            self._db = SessionLocal()
        return self._db
    
    def add_documents(self, documents: List, **kwargs):
        """
        Add documents to the vector store
        
        Args:
            documents: List of Document objects with page_content and metadata
        """
        db = SessionLocal()
        try:
            for doc in documents:
                # Generate embedding
                embedding = self.embedding_function.embed_query(doc.page_content)
                
                # Prepare metadata (LangChain Document uses 'metadata' attribute)
                metadata = doc.metadata or {}
                
                # Store in database
                doc_embedding = DocumentEmbedding(
                    content=doc.page_content,
                    embedding=embedding,  # SQLite JSON will serialize this
                    doc_metadata=metadata,
                    source=metadata.get("source", "unknown") if metadata else "unknown"
                )
                db.add(doc_embedding)
            
            db.commit()
            logger.info(f"✅ Added {len(documents)} documents to SQLite vector store")
            return True
            
        except Exception as e:
            db.rollback()
            logger.error(f"Error adding documents: {str(e)}")
            raise
        finally:
            db.close()
    
    def similarity_search(self, query: str, k: int = 5, **kwargs) -> List:
        """
        Perform similarity search
        
        Args:
            query: Query string
            k: Number of results to return
            
        Returns:
            List of Document objects
        """
        db = SessionLocal()
        try:
            # Generate query embedding
            query_embedding = self.embedding_function.embed_query(query)
            query_vector = np.array(query_embedding)
            
            # Get all documents from database
            all_docs = db.query(DocumentEmbedding).all()
            
            if not all_docs:
                logger.warning("No documents in vector store")
                return []
            
            # Calculate similarities
            similarities = []
            for doc in all_docs:
                doc_vector = np.array(doc.embedding)
                
                # Calculate cosine similarity
                similarity = self._cosine_similarity(query_vector, doc_vector)
                similarities.append((similarity, doc))
            
            # Sort by similarity (descending)
            similarities.sort(key=lambda x: x[0], reverse=True)
            
            # Return top k results as Document objects
            from langchain_core.documents import Document
            
            results = []
            for similarity, doc_embedding in similarities[:k]:
                # Handle metadata - it might be dict or None
                metadata = doc_embedding.doc_metadata if doc_embedding.doc_metadata else {}
                if isinstance(metadata, str):
                    import json
                    try:
                        metadata = json.loads(metadata)
                    except:
                        metadata = {}
                
                doc = Document(
                    page_content=doc_embedding.content,
                    metadata={
                        **metadata,
                        "source": doc_embedding.source or "unknown",
                        "similarity": float(similarity)
                    }
                )
                results.append(doc)
            
            logger.info(f"🔍 Found {len(results)} similar documents")
            return results
            
        except Exception as e:
            logger.error(f"Error in similarity search: {str(e)}")
            raise
        finally:
            db.close()
    
    def as_retriever(self, search_kwargs: Optional[Dict] = None):
        """Return a retriever interface"""
        return SQLiteRetriever(self, search_kwargs or {})
    
    def persist(self):
        """Persist changes (already handled by commit in add_documents)"""
        try:
            if self._db:
                self._db.commit()
        except Exception as e:
            logger.error(f"Error persisting: {str(e)}")
    
    def close(self):
        """Close database session"""
        if self._db:
            self._db.close()
            self._db = None
    
    def delete_all(self):
        """Delete all documents from vector store"""
        db = SessionLocal()
        try:
            db.query(DocumentEmbedding).delete()
            db.commit()
            logger.info("✅ Deleted all documents from vector store")
        except Exception as e:
            db.rollback()
            logger.error(f"Error deleting documents: {str(e)}")
            raise
        finally:
            db.close()
    
    def get_document_count(self) -> int:
        """Get total number of documents"""
        db = SessionLocal()
        try:
            return db.query(DocumentEmbedding).count()
        finally:
            db.close()
    
    @staticmethod
    def _cosine_similarity(vec1: np.ndarray, vec2: np.ndarray) -> float:
        """Calculate cosine similarity between two vectors"""
        dot_product = np.dot(vec1, vec2)
        norm1 = np.linalg.norm(vec1)
        norm2 = np.linalg.norm(vec2)
        
        if norm1 == 0 or norm2 == 0:
            return 0.0
        
        return dot_product / (norm1 * norm2)


class SQLiteRetriever:
    """Retriever interface for SQLiteVectorStore"""
    
    def __init__(self, vectorstore: SQLiteVectorStore, search_kwargs: Dict):
        self.vectorstore = vectorstore
        self.search_kwargs = search_kwargs
    
    def get_relevant_documents(self, query: str):
        """Get relevant documents for a query"""
        k = self.search_kwargs.get("k", 5)
        return self.vectorstore.similarity_search(query, k=k)
    
    def __call__(self, query: str):
        """Make retriever callable"""
        return self.get_relevant_documents(query)

