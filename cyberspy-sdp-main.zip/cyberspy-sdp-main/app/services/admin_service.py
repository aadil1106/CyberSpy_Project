from datetime import datetime, timedelta
from typing import Optional

from sqlalchemy import and_, or_, func
from sqlalchemy.orm import Session

from app.models.branch import Branch
from app.models.city import City
from app.models.officer import Officer
from app.models.report_log import ReportLog
from app.models.result_log import ResultLog
from app.models.search_type import SearchType
from app.schemas.admin import ReportFilter


def get_detailed_reports(
    db: Session,
    filters: ReportFilter,
    skip: int = 0,
    limit: int = 100
):
    """
    Get detailed reports with filters, including related officer, branch, city, and search type information.
    """
    query = (
        db.query(ReportLog, ResultLog, Officer, Branch, City, SearchType)
        .join(ResultLog, ReportLog.result_log_id == ResultLog.id)
        .join(Officer, ResultLog.officer_id == Officer.id)
        .join(Branch, Officer.branch_id == Branch.id)
        .join(City, Branch.city_id == City.id)
        .join(SearchType, ResultLog.search_type_id == SearchType.id)
    )

    # Apply filters
    conditions = []
    
    if filters.officer_id:
        conditions.append(Officer.id == filters.officer_id)
    
    if filters.branch_id:
        conditions.append(Branch.id == filters.branch_id)
    
    if filters.city_id:
        conditions.append(City.id == filters.city_id)
    
    if filters.search_type_id:
        conditions.append(SearchType.id == filters.search_type_id)
    
    if filters.start_date:
        conditions.append(ReportLog.reported_at >= filters.start_date)
    
    if filters.end_date:
        conditions.append(ReportLog.reported_at <= filters.end_date)
    
    if filters.social_media:
        conditions.append(ReportLog.social_media.ilike(f"%{filters.social_media}%"))
    
    if filters.username:
        conditions.append(ReportLog.username.ilike(f"%{filters.username}%"))

    if conditions:
        query = query.filter(and_(*conditions))

    # Order by reported_at descending
    query = query.order_by(ReportLog.reported_at.desc())

    results = query.offset(skip).limit(limit).all()

    # Transform to detailed format
    detailed_reports = []
    for report, result_log, officer, branch, city, search_type in results:
        detailed_reports.append({
            "report_id": report.id,
            "result_log_id": report.result_log_id,
            "officer_id": officer.id,
            "officer_name": f"{officer.first_name} {officer.last_name}",
            "branch_id": branch.id,
            "branch_name": branch.branch_name,
            "city_id": city.id,
            "city_name": city.city_name,
            "search_type_id": search_type.id,
            "search_type_name": search_type.search_type,
            "search_query": result_log.search_query,
            "username": report.username,
            "social_media": report.social_media,
            "reporting_results": report.reporting_results,
            "searched_at": result_log.searched_at,
            "reported_at": report.reported_at,
            "result_file_path": result_log.result_file_path,
        })

    return detailed_reports


def get_report_statistics(db: Session, filters: ReportFilter):
    """
    Get aggregated statistics for reports based on filters.
    """
    query = (
        db.query(ReportLog)
        .join(ResultLog, ReportLog.result_log_id == ResultLog.id)
        .join(Officer, ResultLog.officer_id == Officer.id)
        .join(Branch, Officer.branch_id == Branch.id)
        .join(City, Branch.city_id == City.id)
        .join(SearchType, ResultLog.search_type_id == SearchType.id)
    )

    # Apply filters
    conditions = []
    
    if filters.officer_id:
        conditions.append(Officer.id == filters.officer_id)
    
    if filters.branch_id:
        conditions.append(Branch.id == filters.branch_id)
    
    if filters.city_id:
        conditions.append(City.id == filters.city_id)
    
    if filters.search_type_id:
        conditions.append(SearchType.id == filters.search_type_id)
    
    if filters.start_date:
        conditions.append(ReportLog.reported_at >= filters.start_date)
    
    if filters.end_date:
        conditions.append(ReportLog.reported_at <= filters.end_date)
    
    if filters.social_media:
        conditions.append(ReportLog.social_media.ilike(f"%{filters.social_media}%"))
    
    if filters.username:
        conditions.append(ReportLog.username.ilike(f"%{filters.username}%"))

    if conditions:
        query = query.filter(and_(*conditions))

    total_reports = query.count()
    
    # Count by social media
    social_media_counts = (
        db.query(ReportLog.social_media, func.count(ReportLog.id).label('count'))
        .join(ResultLog, ReportLog.result_log_id == ResultLog.id)
        .join(Officer, ResultLog.officer_id == Officer.id)
        .join(Branch, Officer.branch_id == Branch.id)
        .join(City, Branch.city_id == City.id)
        .join(SearchType, ResultLog.search_type_id == SearchType.id)
    )
    
    if conditions:
        social_media_counts = social_media_counts.filter(and_(*conditions))
    
    social_media_counts = social_media_counts.group_by(ReportLog.social_media).all()
    
    # Count by city
    city_counts = (
        db.query(City.city_name, func.count(ReportLog.id).label('count'))
        .join(Branch, City.id == Branch.city_id)
        .join(Officer, Branch.id == Officer.branch_id)
        .join(ResultLog, Officer.id == ResultLog.officer_id)
        .join(ReportLog, ResultLog.id == ReportLog.result_log_id)
    )
    
    city_conditions = []
    if filters.city_id:
        city_conditions.append(City.id == filters.city_id)
    if filters.start_date:
        city_conditions.append(ReportLog.reported_at >= filters.start_date)
    if filters.end_date:
        city_conditions.append(ReportLog.reported_at <= filters.end_date)
    
    if city_conditions:
        city_counts = city_counts.filter(and_(*city_conditions))
    
    city_counts = city_counts.group_by(City.city_name).all()

    return {
        "total_reports": total_reports,
        "by_social_media": {name: count for name, count in social_media_counts},
        "by_city": {name: count for name, count in city_counts},
    }

def get_dashboard_stats(db: Session):
    """
    Get dashboard overview statistics comparing current totals with totals from 30 days ago.
    """
    now = datetime.utcnow()
    thirty_days_ago = now - timedelta(days=30)
    
    current_officers = db.query(Officer).count()
    previous_officers = db.query(Officer).filter(Officer.created_at < thirty_days_ago).count()
    
    current_branches = db.query(Branch).count()
    previous_branches = current_branches  # No created_at tracked, cumulative stays same essentially for past month tracking
    
    current_cities = db.query(City).count()
    previous_cities = current_cities # No created_at tracked
    
    current_reports = db.query(ReportLog).count()
    previous_reports = db.query(ReportLog).filter(ReportLog.reported_at < thirty_days_ago).count()
    
    return {
        "current": {
            "officers": current_officers,
            "branches": current_branches,
            "cities": current_cities,
            "reports": current_reports
        },
        "previous": {
            "officers": previous_officers,
            "branches": previous_branches,
            "cities": previous_cities,
            "reports": previous_reports
        }
    }

