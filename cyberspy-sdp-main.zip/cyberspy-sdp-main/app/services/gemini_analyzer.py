"""
Gemini AI Integration for Content Analysis and Cybercrime Detection
"""
import os
import logging
from typing import Dict, List, Optional
from google import genai

logger = logging.getLogger(__name__)

# Configure Gemini
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "AIzaSyDG80rHWir0TCDjS3DL6NYO1vNC388cmuQ")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash-lite")

if GEMINI_API_KEY:
    client = genai.Client(api_key=GEMINI_API_KEY)
else:
    client = None
    logger.warning("GEMINI_API_KEY not set - AI analysis will be disabled")


async def analyze_profile_for_cybercrime(
    username: str,
    platform: str,
    bio: Optional[str] = None,
    posts: List[Dict] = None,
    comments: List[str] = None,
    profile_data: Dict = None
) -> Dict:
    """
    Analyze user profile for potential cybercrime indicators using Gemini AI
    
    Returns:
        {
            "risk_level": "low|medium|high|critical",
            "risk_score": 0-100,
            "indicators": [...],
            "summary": "...",
            "recommendations": [...],
            "categories": [...],
            "analysis_details": {...}
        }
    """
    if not client:
        return {
            "risk_level": "unknown",
            "risk_score": 0,
            "indicators": [],
            "summary": "AI analysis unavailable - Gemini API key not configured",
            "recommendations": [],
            "categories": [],
            "analysis_details": {}
        }
    
    try:
        # Prepare content for analysis
        analysis_content = f"""
Analyze this social media profile for potential cybercrime indicators:

Platform: {platform}
Username: @{username}

Profile Bio:
{bio or "No bio available"}

Recent Posts/Captions ({len(posts or [])} posts):
{_format_posts_for_analysis(posts)}

Comments/Interactions ({len(comments or [])} comments):
{_format_comments_for_analysis(comments)}

Additional Profile Data:
{_format_profile_data(profile_data)}

Please analyze this profile and provide:

1. **Risk Assessment**: Rate the cybercrime risk level (low/medium/high/critical) and score (0-100)

2. **Red Flag Indicators**: List specific concerning elements found in:
   - Bio/Description
   - Post captions
   - Comments
   - Engagement patterns
   - Language used
   - Links/URLs
   - Hashtags

3. **Potential Cybercrime Categories**: Identify if content suggests:
   - Scam/Fraud
   - Phishing
   - Harassment/Cyberbullying
   - Hate speech
   - Illegal sales
   - Identity theft
   - Misinformation/Fake news
   - Spam
   - Impersonation
   - Other suspicious activity

4. **Summary**: Brief overview of findings

5. **Recommendations**: Actions to take (monitor, investigate, report, etc.)

Format your response as JSON with this structure:
{{
    "risk_level": "low|medium|high|critical",
    "risk_score": 0-100,
    "indicators": ["indicator1", "indicator2", ...],
    "categories": ["category1", "category2", ...],
    "summary": "Brief summary of findings",
    "recommendations": ["recommendation1", "recommendation2", ...],
    "detailed_analysis": {{
        "bio_analysis": "...",
        "content_analysis": "...",
        "engagement_analysis": "...",
        "language_analysis": "..."
    }}
}}
"""
        
        logger.info(f"Analyzing profile @{username} on {platform} with Gemini AI")
        
        # Generate analysis
        response = client.models.generate_content(
            model=GEMINI_MODEL,
            contents=analysis_content
        )
        
        # Parse response
        result_text = response.text
        
        # Try to extract JSON from response
        import json
        import re
        
        # Find JSON in response
        json_match = re.search(r'\{.*\}', result_text, re.DOTALL)
        if json_match:
            result = json.loads(json_match.group())
        else:
            # Fallback: parse text response
            result = _parse_text_response(result_text)
        
        logger.info(f"Analysis complete for @{username}: Risk level {result.get('risk_level')}, Score {result.get('risk_score')}")
        
        return result
        
    except Exception as e:
        logger.error(f"Error analyzing profile with Gemini: {str(e)}")
        return {
            "risk_level": "unknown",
            "risk_score": 0,
            "indicators": [],
            "summary": f"Analysis error: {str(e)}",
            "recommendations": ["Manual review recommended"],
            "categories": [],
            "analysis_details": {}
        }


async def generate_profile_summary(
    username: str,
    platform: str,
    profile_data: Dict,
    posts: List[Dict] = None,
    engagement_data: Dict = None
) -> str:
    """
    Generate a comprehensive summary of the profile using Gemini AI
    """
    if not client:
        return "AI summary unavailable - Gemini API key not configured"
    
    try:
        summary_prompt = f"""
Create a comprehensive summary of this social media profile:

Platform: {platform}
Username: @{username}

Profile Information:
- Followers: {profile_data.get('followers', 0)}
- Following: {profile_data.get('following', 0)}
- Posts: {profile_data.get('posts_count', 0)}
- Bio: {profile_data.get('biography', 'N/A')}
- Verified: {profile_data.get('is_verified', False)}
- Private: {profile_data.get('is_private', False)}

Recent Activity:
- Total Posts Analyzed: {len(posts or [])}
- Average Engagement: {engagement_data.get('engagement_rate', 0)}%
- Average Likes: {engagement_data.get('avg_likes', 0)}
- Average Comments: {engagement_data.get('avg_comments', 0)}

Post Themes:
{_extract_post_themes(posts)}

Provide a 2-3 paragraph professional summary covering:
1. Account overview and activity level
2. Content themes and engagement patterns
3. Notable characteristics or concerns
"""
        
        response = client.models.generate_content(
            model=GEMINI_MODEL,
            contents=summary_prompt
        )
        return response.text.strip()
        
    except Exception as e:
        logger.error(f"Error generating summary: {str(e)}")
        return f"Summary generation failed: {str(e)}"


def _format_posts_for_analysis(posts: List[Dict]) -> str:
    """Format posts for AI analysis"""
    if not posts:
        return "No posts available"
    
    formatted = []
    for i, post in enumerate(posts[:10], 1):  # Limit to 10 posts
        caption = post.get('caption', '')
        likes = post.get('likes', 0)
        comments = post.get('comments', 0)
        formatted.append(f"{i}. Caption: {caption[:200]}... (Likes: {likes}, Comments: {comments})")
    
    return "\n".join(formatted)


def _format_comments_for_analysis(comments: List[str]) -> str:
    """Format comments for AI analysis"""
    if not comments:
        return "No comments available"
    
    return "\n".join([f"- {comment[:150]}..." for comment in comments[:20]])


def _format_profile_data(profile_data: Dict) -> str:
    """Format profile data for analysis"""
    if not profile_data:
        return "No additional data"
    
    return f"""
- Account Type: {"Business" if profile_data.get('is_business_account') else "Personal"}
- Verified: {profile_data.get('is_verified', False)}
- Private: {profile_data.get('is_private', False)}
- External URL: {profile_data.get('external_url', 'None')}
"""


def _extract_post_themes(posts: List[Dict]) -> str:
    """Extract common themes from posts"""
    if not posts:
        return "No posts to analyze"
    
    # Simple theme extraction (can be enhanced)
    captions = [post.get('caption', '') for post in posts if post.get('caption')]
    return f"Analyzed {len(captions)} captions for themes"


def _parse_text_response(text: str) -> Dict:
    """Parse text response when JSON parsing fails"""
    # Basic fallback parsing
    result = {
        "risk_level": "medium",
        "risk_score": 50,
        "indicators": [],
        "categories": [],
        "summary": text[:500],
        "recommendations": ["Manual review recommended"],
        "analysis_details": {}
    }
    
    # Try to extract risk level
    text_lower = text.lower()
    if "critical" in text_lower or "high risk" in text_lower:
        result["risk_level"] = "critical"
        result["risk_score"] = 85
    elif "high" in text_lower:
        result["risk_level"] = "high"
        result["risk_score"] = 70
    elif "low" in text_lower:
        result["risk_level"] = "low"
        result["risk_score"] = 25
    
    return result
