from sqlalchemy.orm import Session

from app.core.security import hash_password
from app.models.officer import Officer
from app.schemas.officer import OfficerCreate, OfficerUpdate


def create_officer(db: Session, officer_in: OfficerCreate) -> Officer:
    db_officer = Officer(
        branch_id=officer_in.branch_id,
        first_name=officer_in.first_name,
        last_name=officer_in.last_name,
        gender=officer_in.gender,
        dob=officer_in.dob,
        phone_no=officer_in.phone_no,
        email=officer_in.email,
        password=hash_password(officer_in.password),
        is_active=officer_in.is_active if officer_in.is_active is not None else True,
    )
    db.add(db_officer)
    db.commit()
    db.refresh(db_officer)
    return db_officer


def get_officers(db: Session, skip: int = 0, limit: int = 100, is_active: bool | None = None, branch_id: int | None = None, city_id: int | None = None, gender: str | None = None, min_age: int | None = None, max_age: int | None = None):
    query = db.query(Officer)
    if is_active is not None:
        query = query.filter(Officer.is_active == is_active)
    if branch_id is not None:
        query = query.filter(Officer.branch_id == branch_id)
    return query.offset(skip).limit(limit).all()


def get_officer(db: Session, officer_id: int) -> Officer | None:
    return db.query(Officer).filter(Officer.id == officer_id).first()


def update_officer(db: Session, officer_id: int, officer_in: OfficerUpdate) -> Officer | None:
    officer = get_officer(db, officer_id)
    if not officer:
        return None
    update_data = officer_in.dict(exclude_unset=True)
    if "password" in update_data and update_data["password"]:
        update_data["password"] = hash_password(update_data["password"])
    for field, value in update_data.items():
        setattr(officer, field, value)
    db.commit()
    db.refresh(officer)
    return officer


from sqlalchemy.exc import IntegrityError

def delete_officer(db: Session, officer_id: int) -> bool:
    officer = db.query(Officer).filter(Officer.id == officer_id).first()
    if not officer:
        return False
    try:
        db.delete(officer)
        db.commit()
        return True
    except IntegrityError:
        db.rollback()
        raise ValueError("Cannot delete officer. They have associated login or result logs.")
