"""
Guardrails for Chatbot - Content filtering, rate limiting, and safety checks
"""
import re
import time
import logging
from typing import Dict, Optional, List
from collections import defaultdict
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

user_requests = defaultdict(list)
ip_requests = defaultdict(list)

# Configuration
MAX_REQUESTS_PER_MINUTE = 10
MAX_REQUESTS_PER_HOUR = 100
MAX_MESSAGE_LENGTH = 2000
MIN_MESSAGE_LENGTH = 3

# Blocked patterns (inappropriate content, attacks, etc.)
BLOCKED_PATTERNS = [
    r'(?i)\b(porn|xxx|sex|nude|explicit)\b',
    r'(?i)\b(hack|exploit|vulnerability|sql injection)\b',
    r'(?i)\b(bomb|terrorist|kill|murder)\b',
    r'(?i)\b(drug|weed|cocaine|heroin)\b',
    r'(?i)\b(scam|phishing|fraud|steal)\b',
    r'<script[^>]*>.*?</script>',  # XSS attempts
    r'javascript:',  # JavaScript injection
    r'onerror\s*=',  # Event handler injection
]

# Suspicious patterns (warn but allow)
SUSPICIOUS_PATTERNS = [
    r'(?i)\b(password|secret|key|token|api)\b',
    r'(?i)\b(delete|drop|truncate|alter)\b',
    r'(?i)\b(admin|root|sudo)\b',
]


def check_rate_limit(user_id: Optional[str] = None, ip_address: Optional[str] = None) -> Dict:
    """Check if user has exceeded rate limits"""
    now = time.time()
    
    # Check user-based rate limit
    if user_id:
        user_requests[user_id] = [
            req_time for req_time in user_requests[user_id]
            if now - req_time < 3600  # Keep last hour
        ]
        
        requests_last_minute = sum(
            1 for req_time in user_requests[user_id]
            if now - req_time < 60
        )
        requests_last_hour = len(user_requests[user_id])
        
        if requests_last_minute >= MAX_REQUESTS_PER_MINUTE:
            return {
                "allowed": False,
                "reason": "RATE_LIMIT_MINUTE",
                "message": f"Too many requests. Maximum {MAX_REQUESTS_PER_MINUTE} requests per minute."
            }
        
        if requests_last_hour >= MAX_REQUESTS_PER_HOUR:
            return {
                "allowed": False,
                "reason": "RATE_LIMIT_HOUR",
                "message": f"Too many requests. Maximum {MAX_REQUESTS_PER_HOUR} requests per hour."
            }
    
    # Check IP-based rate limit
    if ip_address:
        ip_requests[ip_address] = [
            req_time for req_time in ip_requests[ip_address]
            if now - req_time < 3600
        ]
        
        requests_last_minute = sum(
            1 for req_time in ip_requests[ip_address]
            if now - req_time < 60
        )
        
        if requests_last_minute >= MAX_REQUESTS_PER_MINUTE * 2:  # Stricter for IP
            return {
                "allowed": False,
                "reason": "RATE_LIMIT_IP",
                "message": "Too many requests from this IP address."
            }
    
    return {"allowed": True}


def record_request(user_id: Optional[str] = None, ip_address: Optional[str] = None):
    """Record a request for rate limiting"""
    now = time.time()
    if user_id:
        user_requests[user_id].append(now)
    if ip_address:
        ip_requests[ip_address].append(now)


def validate_message(message: str) -> Dict:
    """Validate message content"""
    # Check length
    if len(message) < MIN_MESSAGE_LENGTH:
        return {
            "valid": False,
            "reason": "TOO_SHORT",
            "message": f"Message must be at least {MIN_MESSAGE_LENGTH} characters."
        }
    
    if len(message) > MAX_MESSAGE_LENGTH:
        return {
            "valid": False,
            "reason": "TOO_LONG",
            "message": f"Message must be no more than {MAX_MESSAGE_LENGTH} characters."
        }
    
    # Check for blocked patterns
    for pattern in BLOCKED_PATTERNS:
        if re.search(pattern, message):
            logger.warning(f"Blocked message with pattern: {pattern}")
            return {
                "valid": False,
                "reason": "BLOCKED_CONTENT",
                "message": "Your message contains inappropriate content and cannot be processed."
            }
    
    # Check for suspicious patterns (warn but allow)
    warnings = []
    for pattern in SUSPICIOUS_PATTERNS:
        if re.search(pattern, message):
            warnings.append(f"Suspicious pattern detected: {pattern}")
    
    return {
        "valid": True,
        "warnings": warnings
    }


def sanitize_input(text: str) -> str:
    """Sanitize user input to prevent injection attacks"""
    # Remove null bytes
    text = text.replace('\x00', '')
    
    # Remove control characters except newlines and tabs
    text = re.sub(r'[\x00-\x08\x0B-\x0C\x0E-\x1F\x7F]', '', text)
    
    # Limit consecutive whitespace
    text = re.sub(r'\s+', ' ', text)
    
    # Trim
    text = text.strip()
    
    return text


def check_content_safety(response: str) -> Dict:
    """Check if AI response is safe to return"""
    # Check for potential harmful content
    harmful_patterns = [
        r'(?i)\b(how to hack|how to exploit|how to break)\b',
        r'(?i)\b(illegal|unlawful|criminal)\b',
    ]
    
    for pattern in harmful_patterns:
        if re.search(pattern, response):
            return {
                "safe": False,
                "reason": "POTENTIALLY_HARMFUL",
                "message": "Response contains potentially harmful content."
            }
    
    return {"safe": True}


def filter_response(response: str) -> str:
    """Filter and clean AI response"""
    # Remove any script tags
    response = re.sub(r'<script[^>]*>.*?</script>', '', response, flags=re.IGNORECASE | re.DOTALL)
    
    # Remove event handlers
    response = re.sub(r'on\w+\s*=\s*["\'][^"\']*["\']', '', response, flags=re.IGNORECASE)
    
    # Limit response length (prevent extremely long responses)
    max_response_length = 5000
    if len(response) > max_response_length:
        response = response[:max_response_length] + "... [Response truncated]"
    
    return response


def get_user_context(user_id: Optional[str] = None) -> Dict:
    """Get context about user for logging/analytics"""
    context = {
        "timestamp": datetime.now().isoformat(),
    }
    
    if user_id:
        context["user_id"] = user_id
        context["requests_count"] = len(user_requests.get(user_id, []))
    
    return context


