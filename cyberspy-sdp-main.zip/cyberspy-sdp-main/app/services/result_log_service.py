from sqlalchemy.orm import Session

from app.models.result_log import ResultLog
from app.schemas.result_log import ResultLogCreate


def create_result_log(db: Session, log_in: ResultLogCreate) -> ResultLog:
    db_log = ResultLog(
        officer_id=log_in.officer_id,
        search_type_id=log_in.search_type_id,
        search_query=log_in.search_query,
        result_file_path=log_in.result_file_path,
        searched_at=log_in.searched_at,
    )
    db.add(db_log)
    db.commit()
    db.refresh(db_log)
    return db_log


def list_result_logs(db: Session, skip: int = 0, limit: int = 100):
    return db.query(ResultLog).offset(skip).limit(limit).all()


def get_recent_searches_by_officer(
    db: Session, 
    officer_id: int = None, 
    limit: int = 50
) -> list[ResultLog]:
    """
    Get recent searches, optionally filtered by officer ID
    
    Args:
        db: Database session
        officer_id: Optional officer ID to filter by (None = all officers)
        limit: Maximum number of results to return
    
    Returns:
        List of ResultLog objects ordered by most recent first
    """
    query = db.query(ResultLog)
    
    if officer_id is not None:
        query = query.filter(ResultLog.officer_id == officer_id)
    
    return query.order_by(ResultLog.searched_at.desc()).limit(limit).all()


def get_result_log_by_id(db: Session, log_id: int) -> ResultLog | None:
    """
    Get a specific result log by ID
    
    Args:
        db: Database session
        log_id: ID of the result log
    
    Returns:
        ResultLog object or None if not found
    """
    return db.query(ResultLog).filter(ResultLog.id == log_id).first()

