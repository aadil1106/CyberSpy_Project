"""
RAG (Retrieval-Augmented Generation) Service for Chatbot
Uses LangChain with Google Gemini LLM and Sentence Transformers for embeddings
Stores embeddings in SQLite JSON
"""
import os
import logging
from typing import List, Dict, Optional
from pathlib import Path

from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.documents import Document
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough

from app.services.sqlite_vectorstore import SQLiteVectorStore
from app.services.sentence_transformer_embeddings import SentenceTransformerEmbeddings
from app.db.session import SessionLocal
from app.models.document_embedding import DocumentEmbedding

logger = logging.getLogger(__name__)

# Configuration
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "AIzaSyDG80rHWir0TCDjS3DL6NYO1vNC388cmuQ")
SENTENCE_TRANSFORMER_MODEL = os.getenv("SENTENCE_TRANSFORMER_MODEL", "all-MiniLM-L6-v2")
SYSTEM_DOCS_DIR = "./system_docs"
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash-lite")

# Initialize components
llm = None
embeddings = None
vectorstore = None
qa_chain = None
memory = None


def initialize_rag():
    """Initialize RAG components"""
    global llm, embeddings, vectorstore, qa_chain

    try:
        # =========================================================
        # Initialize LLM & Embeddings
        # =========================================================
        if not GEMINI_API_KEY:
            logger.warning("⚠️ GEMINI_API_KEY not set - RAG will be disabled")
            return False

        # Initialize Gemini LLM for generation
        llm = ChatGoogleGenerativeAI(
            model=GEMINI_MODEL,
            google_api_key=GEMINI_API_KEY,
            temperature=0.7,
            max_output_tokens=2048,
        )

        # Initialize Sentence Transformers for embeddings (local, no API needed)
        embeddings = SentenceTransformerEmbeddings(model_name=SENTENCE_TRANSFORMER_MODEL)

        logger.info(f"✅ Gemini LLM & Sentence Transformer embeddings ({SENTENCE_TRANSFORMER_MODEL}) initialized")

        # =========================================================
        # Create directories
        # =========================================================
        os.makedirs(SYSTEM_DOCS_DIR, exist_ok=True)

        # =========================================================
        # SQLite Vector Store
        # =========================================================
        # Check if documents already exist in database
        db = SessionLocal()
        try:
            doc_count = db.query(DocumentEmbedding).count()
            
            if doc_count > 0:
                logger.info(f"📚 Loading existing SQLite vector store with {doc_count} documents...")
                vectorstore = SQLiteVectorStore(embedding_function=embeddings)
            else:
                logger.info("📝 Creating new SQLite vector store from system docs...")
                documents = load_system_documents()

                if not documents:
                    logger.warning("⚠️ No documents found")
                    return False

                vectorstore = SQLiteVectorStore(embedding_function=embeddings)
                vectorstore.add_documents(documents)
                logger.info(f"✅ SQLite vector store created with {len(documents)} documents")
        except Exception as e:
            logger.error(f"Error initializing vector store: {str(e)}")
            raise
        finally:
            db.close()

        # =========================================================
        # Prompt - USER-ONLY (NO BACKEND/API)
        # =========================================================
        PROMPT = PromptTemplate(
            template="""You are a friendly support assistant for the Activity Monitoring System web application.

YOUR ROLE: Help users navigate and use the web interface effectively.

STRICT RULES - YOU MUST FOLLOW THESE:
1. ✅ ALWAYS provide answers in NUMBERED STEPS (1. 2. 3. etc.)
2. ✅ ONLY explain web interface actions (clicking buttons, filling forms, viewing pages)
3. ✅ Use simple, everyday language - no technical jargon
4. ✅ Describe what users will SEE on screen and what to DO
5. ❌ NEVER mention APIs, endpoints, code, or backend details
6. ❌ NEVER show curl commands, JSON, or technical examples
7. ❌ NEVER discuss databases, servers, or implementation

ANSWER FORMAT:
- Start with a brief explanation (1 sentence)
- Then provide NUMBERED STEPS
- End with what the user will see/get as a result

Use ONLY the context below. If you can't answer from the context, say "I don't have information about that in the user guide."

Context:
{context}

User Question:
{question}

Your Answer (numbered steps for web interface only):""",
            input_variables=["context", "question"]
        )

        # =========================================================
        # Retriever + Runnable Chain (CORRECT WIRING)
        # =========================================================
        # Prioritize user-focused documents
        retriever = vectorstore.as_retriever(
            search_kwargs={
                "k": 7,  # Get more results for better context
                "filter": lambda metadata: (
                    # Prioritize user guide
                    metadata.get("source", "").endswith("00_user_guide.md") or
                    metadata.get("source", "").endswith("03_usage_guide.md") or
                    # Then other docs
                    metadata.get("type") in ["system_doc", "readme"]
                )
            }
        )

        def format_docs(docs):
            """Format retrieved documents for context"""
            return "\n\n".join(doc.page_content for doc in docs)

        def retrieve_and_format(question: str):
            """Retrieve documents and format them"""
            docs = retriever.get_relevant_documents(question)
            return format_docs(docs)

        qa_chain = (
            {
                "context": lambda x: retrieve_and_format(x["question"]),
                "question": lambda x: x["question"]
            }
            | PROMPT
            | llm
            | StrOutputParser()
        )

        logger.info("✅ RAG service fully initialized")
        return True

    except Exception as e:
        logger.exception("❌ Error initializing RAG service")
        return False



def load_system_documents() -> List[Document]:
    """Load ONLY user-focused documentation files (NO API/backend docs)"""
    documents = []
    docs_dir = Path(SYSTEM_DOCS_DIR)
    
    # If docs directory doesn't exist or is empty, create default documentation
    if not docs_dir.exists() or not any(docs_dir.iterdir()):
        create_default_documentation()
    
    # =========================================================
    # ONLY LOAD USER-FOCUSED FILES
    # =========================================================
    user_focused_files = [
        "00_user_guide.md",        # ⭐ PRIMARY - Admin/User interface guide
        "00_officer_guide.md",     # ⭐ PRIMARY - Officer interface guide
        "03_usage_guide.md",       # ⭐ SECONDARY - Usage instructions
        "04_troubleshooting.md",   # ⭐ TERTIARY - User troubleshooting
    ]
    
    # Files to SKIP (backend/technical)
    skip_files = [
        "01_system_overview.md",   # ❌ Contains technical architecture
        "02_api_documentation.md", # ❌ API endpoints and code
    ]
    
    # Load only user-focused files
    for filename in user_focused_files:
        file_path = docs_dir / filename
        if file_path.exists():
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    content = f.read()
                    documents.append(Document(
                        page_content=content,
                        metadata={"source": str(file_path), "type": "user_guide"}
                    ))
                    logger.info(f"📄 ✅ Loaded USER guide: {file_path.name}")
            except Exception as e:
                logger.error(f"Error loading {file_path}: {str(e)}")
        else:
            logger.warning(f"⚠️  User guide not found: {filename}")
    
    # Log skipped files
    for filename in skip_files:
        file_path = docs_dir / filename
        if file_path.exists():
            logger.info(f"📄 ⏭️  Skipped BACKEND doc: {filename}")
    
    # DO NOT load README (contains technical info)
    logger.info("📄 ⏭️  Skipped README.md (contains backend details)")
    
    # Split documents into chunks
    if documents:
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200,
            length_function=len,
        )
        documents = text_splitter.split_documents(documents)
        logger.info(f"📚 Split into {len(documents)} chunks (USER-FOCUSED ONLY)")
    else:
        logger.warning("⚠️  No user-focused documents loaded!")
    
    return documents


def create_default_documentation():
    """Create default system documentation"""
    docs_dir = Path(SYSTEM_DOCS_DIR)
    docs_dir.mkdir(exist_ok=True)
    
    # System Overview
    overview_content = """# Activity Monitoring System - Overview

## What is this system?

The Activity Monitoring System is a comprehensive cyber-crime investigation platform designed for law enforcement officers to search, analyze, and report on social media profiles and activities.

## Key Features

### 1. Multi-Platform Search
- Search across multiple social media platforms (Instagram, Facebook, Reddit, Telegram)
- Single platform or multi-platform search capabilities
- Username and keyword-based searches

### 2. AI-Powered Analysis
- Google Gemini AI integration for profile analysis
- Cybercrime risk assessment
- Automated content analysis and flagging
- Profile summarization

### 3. Officer Management
- Officer accounts with role-based access
- Login tracking and audit logs
- Branch and city management
- Search type categorization

### 4. Reporting System
- Generate detailed reports on profiles
- Mass reporting capabilities
- Report history and tracking
- Export functionality

### 5. Dashboard & Analytics
- Real-time activity monitoring
- Search statistics and trends
- Officer activity tracking
- Visual charts and graphs

## System Architecture

- **Backend**: FastAPI (Python)
- **Database**: SQLite (default, can be configured)
- **AI Engine**: Google Gemini
- **Frontend**: HTML/CSS/JavaScript (Admin Panel)

## API Endpoints

All API endpoints are prefixed with `/api` by default.

### Search Endpoints
- `POST /api/search/multi-platform` - Search across all platforms
- `POST /api/search/single-platform` - Search a specific platform
- `GET /api/search/tracking/{tracking_id}` - Get search status

### Officer Management
- `GET /api/officers` - List all officers
- `POST /api/officers` - Create new officer
- `GET /api/officers/{id}` - Get officer details
- `PUT /api/officers/{id}` - Update officer
- `DELETE /api/officers/{id}` - Delete officer

### Reports
- `GET /api/reports` - List all reports
- `POST /api/reports` - Create new report
- `GET /api/reports/{id}` - Get report details

### Dashboard
- `GET /api/dashboard/stats` - Get dashboard statistics
- `GET /api/dashboard/activity` - Get activity data
"""
    
    # API Documentation
    api_content = """# API Documentation

## Authentication

Currently, the system uses session-based authentication. Officers log in through the admin panel.

## Search API

### Multi-Platform Search
Endpoint: `POST /api/search/multi-platform`

Request Body:
```json
{
  "username": "target_username",
  "officer_id": 1,
  "search_type_id": 1
}
```

Response:
```json
{
  "tracking_id": "uuid",
  "status": "processing",
  "platforms": ["instagram", "facebook", "reddit", "telegram"]
}
```

### Single Platform Search
Endpoint: `POST /api/search/single-platform`

Request Body:
```json
{
  "username": "target_username",
  "platform": "instagram",
  "officer_id": 1,
  "search_type_id": 1
}
```

## Result Logs

All searches are logged in the `result_logs` table with:
- Search timestamp
- Officer who performed the search
- Platform searched
- Search results
- AI analysis results

## Report Generation

Reports can be generated from search results and include:
- Profile information
- AI risk assessment
- Activity summary
- Recommendations
"""
    
    # Usage Guide
    usage_content = """# How to Use the System

## For Officers

### 1. Logging In
- Navigate to the admin panel
- Enter your officer credentials
- Session is maintained for your work session

### 2. Performing Searches

#### Single Platform Search
1. Go to Search page
2. Select platform (Instagram, Facebook, Reddit, Telegram)
3. Enter username or keyword
4. Select search type
5. Click "Search"
6. View results and AI analysis

#### Multi-Platform Search
1. Go to Search page
2. Select "Multi-Platform" option
3. Enter username
4. Select search type
5. Click "Search"
6. System searches all platforms simultaneously
7. View consolidated results

### 3. Viewing Results
- Search results show profile information
- AI analysis displays risk assessment
- Risk levels: Low, Medium, High, Critical
- View detailed analysis and recommendations

### 4. Generating Reports
1. After search, click "Generate Report"
2. Review report content
3. Save or export report
4. Reports are logged in system

### 5. Mass Reporting
- Use mass report feature for multiple profiles
- Upload CSV with usernames
- System processes in batch
- View progress and results

## Best Practices

1. **Search Types**: Use appropriate search types for categorization
2. **Documentation**: Always review AI analysis before taking action
3. **Reports**: Generate reports for important findings
4. **Privacy**: Follow data protection guidelines
5. **Verification**: Verify AI findings with manual review
"""
    
    # Troubleshooting
    troubleshooting_content = """# Troubleshooting Guide

## Common Issues

### Search Not Working
- Check internet connection
- Verify platform availability
- Check rate limits (Instagram has strict limits)
- Try different user agent rotation

### AI Analysis Not Available
- Verify GEMINI_API_KEY is set
- Check API quota limits
- Review error logs

### Slow Performance
- Check database size
- Clear old logs if needed
- Optimize search queries
- Check server resources

### Login Issues
- Verify credentials
- Check session storage
- Clear browser cache
- Contact administrator

## Error Codes

- `400`: Bad Request - Invalid input
- `401`: Unauthorized - Authentication required
- `404`: Not Found - Resource doesn't exist
- `429`: Too Many Requests - Rate limit exceeded
- `500`: Internal Server Error - Server issue

## Getting Help

- Check system logs for detailed error messages
- Review API documentation
- Contact system administrator
- Check GitHub issues (if applicable)
"""
    
    # Write documentation files
    (docs_dir / "01_system_overview.md").write_text(overview_content, encoding="utf-8")
    (docs_dir / "02_api_documentation.md").write_text(api_content, encoding="utf-8")
    (docs_dir / "03_usage_guide.md").write_text(usage_content, encoding="utf-8")
    (docs_dir / "04_troubleshooting.md").write_text(troubleshooting_content, encoding="utf-8")
    
    logger.info("✅ Created default system documentation")


async def query_rag(question: str, conversation_history: Optional[List[Dict]] = None, user_type: str = "officer") -> Dict:
    global qa_chain, vectorstore

    if not qa_chain or not vectorstore:
        return {
            "answer": "RAG service is not initialized.",
            "sources": [],
            "error": "RAG_NOT_INITIALIZED"
        }

    try:
        # Filter documents based on user type
        if user_type == "admin":
            # Admins get all user-focused documents
            docs = vectorstore.similarity_search(
                question, 
                k=7,
                filter=lambda metadata: (
                    metadata.get("source", "").endswith("00_user_guide.md") or
                    metadata.get("source", "").endswith("03_usage_guide.md") or
                    metadata.get("source", "").endswith("04_troubleshooting.md")
                )
            )
        else:
            # Officers get officer-specific documents
            docs = vectorstore.similarity_search(
                question, 
                k=7,
                filter=lambda metadata: (
                    metadata.get("source", "").endswith("00_officer_guide.md") or
                    metadata.get("source", "").endswith("03_usage_guide.md") or
                    metadata.get("source", "").endswith("04_troubleshooting.md")
                )
            )
        
        # Generate answer using the chain
        answer = qa_chain.invoke({"question": question})

        # Extract sources
        sources = list(
            set(d.metadata.get("source", "Unknown") for d in docs)
        )

        return {
            "answer": answer,
            "sources": sources,
            "error": None
        }

    except Exception as e:
        logger.exception("Error querying RAG")
        return {
            "answer": f"Error processing question: {str(e)}",
            "sources": [],
            "error": str(e)
        }



def add_document(content: str, metadata: Optional[Dict] = None):
    """Add a new document to the vector store"""
    global vectorstore, embeddings
    
    if not vectorstore or not embeddings:
        logger.error("Vector store not initialized")
        return False
    
    try:
        # Split document
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200,
        )
        docs = text_splitter.split_text(content)
        
        # Create document objects
        documents = [
            Document(
                page_content=doc,
                metadata=metadata or {}
            )
            for doc in docs
        ]
        
        # Add to vector store
        vectorstore.add_documents(documents)
        vectorstore.persist()
        
        logger.info(f"✅ Added {len(documents)} document chunks to SQLite vector store")
        return True
        
    except Exception as e:
        logger.error(f"Error adding document: {str(e)}")
        return False

