from sqlalchemy.orm import Session

from app.models.search_type import SearchType
from app.schemas.search_type import SearchTypeCreate, SearchTypeUpdate


def create_search_type(db: Session, search_type_in: SearchTypeCreate) -> SearchType:
    db_search_type = SearchType(
        search_type=search_type_in.search_type,
        is_active=search_type_in.is_active if search_type_in.is_active is not None else True,
    )
    db.add(db_search_type)
    db.commit()
    db.refresh(db_search_type)
    return db_search_type


def list_search_types(db: Session, is_active: bool | None = None):
    query = db.query(SearchType)
    if is_active is not None:
        query = query.filter(SearchType.is_active == is_active)
    return query.all()


def update_search_type(db: Session, search_type_id: int, search_type_in: SearchTypeUpdate) -> SearchType | None:
    record = db.query(SearchType).filter(SearchType.id == search_type_id).first()
    if not record:
        return None
    for field, value in search_type_in.dict(exclude_unset=True).items():
        setattr(record, field, value)
    db.commit()
    db.refresh(record)
    return record

