from sqlalchemy.orm import Session

from app.models.branch import Branch
from app.schemas.branch import BranchCreate, BranchUpdate


def create_branch(db: Session, branch_in: BranchCreate) -> Branch:
    branch = Branch(
        city_id=branch_in.city_id,
        branch_name=branch_in.branch_name,
        pincode=branch_in.pincode,
        is_active=branch_in.is_active if branch_in.is_active is not None else True,
    )
    db.add(branch)
    db.commit()
    db.refresh(branch)
    return branch


def list_branches(db: Session, is_active: bool | None = None, city_id: int | None = None):
    query = db.query(Branch)
    if is_active is not None:
        query = query.filter(Branch.is_active == is_active)
    if city_id is not None:
        query = query.filter(Branch.city_id == city_id)
    return query.all()


def update_branch(db: Session, branch_id: int, branch_in: BranchUpdate) -> Branch | None:
    branch = db.query(Branch).filter(Branch.id == branch_id).first()
    if not branch:
        return None
    for field, value in branch_in.dict(exclude_unset=True).items():
        setattr(branch, field, value)
    db.commit()
    db.refresh(branch)
    return branch


from sqlalchemy.exc import IntegrityError

def delete_branch(db: Session, branch_id: int) -> bool:
    branch = db.query(Branch).filter(Branch.id == branch_id).first()
    if not branch:
        return False
    try:
        db.delete(branch)
        db.commit()
        return True
    except IntegrityError:
        db.rollback()
        raise ValueError("Cannot delete branch. It has associated officers.")


