from sqlalchemy.orm import Session

from app.models.city import City
from app.schemas.city import CityCreate, CityUpdate


def create_city(db: Session, city_in: CityCreate) -> City:
    city = City(city_name=city_in.city_name, is_active=city_in.is_active if city_in.is_active is not None else True)
    db.add(city)
    db.commit()
    db.refresh(city)
    return city


def list_cities(db: Session, is_active: bool | None = None):
    query = db.query(City)
    if is_active is not None:
        query = query.filter(City.is_active == is_active)
    return query.all()


def update_city(db: Session, city_id: int, city_in: CityUpdate) -> City | None:
    city = db.query(City).filter(City.id == city_id).first()
    if not city:
        return None
    for field, value in city_in.dict(exclude_unset=True).items():
        setattr(city, field, value)
    db.commit()
    db.refresh(city)
    return city


from sqlalchemy.exc import IntegrityError

def delete_city(db: Session, city_id: int) -> bool:
    city = db.query(City).filter(City.id == city_id).first()
    if not city:
        return False
    try:
        db.delete(city)
        db.commit()
        return True
    except IntegrityError:
        db.rollback()
        raise ValueError("Cannot delete city. It has associated branches.")
