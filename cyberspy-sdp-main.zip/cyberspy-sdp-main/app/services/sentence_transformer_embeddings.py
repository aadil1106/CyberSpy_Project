"""
Sentence Transformer Embeddings Wrapper for LangChain
Uses sentence-transformers for local embeddings
"""
import logging
from typing import List

from sentence_transformers import SentenceTransformer

logger = logging.getLogger(__name__)


class SentenceTransformerEmbeddings:
    """Wrapper for sentence-transformers to work with LangChain"""
    
    def __init__(self, model_name: str = "all-MiniLM-L6-v2"):
        """
        Initialize sentence transformer embeddings
        
        Args:
            model_name: Name of the sentence transformer model
                       Default: "all-MiniLM-L6-v2" (fast, good quality)
                       Alternatives: "all-mpnet-base-v2" (better quality, slower)
        """
        logger.info(f"🔄 Loading sentence transformer model: {model_name}")
        self.model = SentenceTransformer(model_name)
        self.model_name = model_name
        logger.info(f"✅ Sentence transformer model loaded: {model_name}")
    
    def embed_query(self, text: str) -> List[float]:
        """
        Embed a single query string
        
        Args:
            text: Text to embed
            
        Returns:
            List of embedding values
        """
        embedding = self.model.encode(text, convert_to_numpy=True)
        return embedding.tolist()
    
    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """
        Embed multiple documents
        
        Args:
            texts: List of texts to embed
            
        Returns:
            List of embedding lists
        """
        embeddings = self.model.encode(texts, convert_to_numpy=True)
        return embeddings.tolist()


