from sqlalchemy.orm import Session

from app.models.report_log import ReportLog
from app.schemas.report_log import ReportLogCreate


def create_report_log(db: Session, log_in: ReportLogCreate) -> ReportLog:
    db_log = ReportLog(
        result_log_id=log_in.result_log_id,
        username=log_in.username,
        social_media=log_in.social_media,
        reporting_results=log_in.reporting_results,
        reported_at=log_in.reported_at,
    )
    db.add(db_log)
    db.commit()
    db.refresh(db_log)
    return db_log


def list_report_logs(db: Session, skip: int = 0, limit: int = 100):
    return db.query(ReportLog).offset(skip).limit(limit).all()

