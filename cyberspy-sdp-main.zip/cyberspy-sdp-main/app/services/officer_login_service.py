from datetime import datetime
from fastapi import HTTPException
from sqlalchemy.orm import Session

from app.core.security import verify_password
from app.models.officer import Officer
from app.models.officer_login_log import OfficerLoginLog
from app.schemas.officer import OfficerLogin
from app.schemas.officer_login_log import OfficerLoginLogCreate


def login_officer(db: Session, login_in: OfficerLogin) -> Officer:
    """
    Authenticate an officer by email and password.
    Creates a login log entry upon successful authentication.
    
    Args:
        db: Database session
        login_in: Login credentials (email and password)
    
    Returns:
        Officer: Authenticated officer object
    
    Raises:
        HTTPException: If credentials are invalid or officer is inactive
    """
    # Find officer by email
    officer = db.query(Officer).filter(Officer.email == login_in.email).first()
    
    if not officer:
        raise HTTPException(status_code=401, detail="Invalid email or password")
    
    # Verify password
    if not verify_password(login_in.password, officer.password):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    
    # Check if officer is active
    if not officer.is_active:
        raise HTTPException(status_code=403, detail="Officer account is inactive")
    
    # Create login log entry
    login_log = OfficerLoginLog(
        officer_id=officer.id,
        loggedin_at=datetime.utcnow()
    )
    db.add(login_log)
    db.commit()
    
    return officer

def create_login_log(db: Session, login_in: OfficerLoginLogCreate) -> OfficerLoginLog:
    log = OfficerLoginLog(officer_id=login_in.officer_id, loggedin_at=login_in.loggedin_at)
    db.add(log)
    db.commit()
    db.refresh(log)
    return log


def list_login_logs(db: Session, officer_id: int | None = None, skip: int = 0, limit: int = 100):
    query = db.query(OfficerLoginLog)
    if officer_id is not None:
        query = query.filter(OfficerLoginLog.officer_id == officer_id)
    return query.offset(skip).limit(limit).all()

