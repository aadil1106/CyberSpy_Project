from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func, desc
from pydantic import BaseModel
from typing import Optional, List, Dict
from datetime import datetime, timedelta

from app.db.session import get_db
from app.models.officer import Officer
from app.models.result_log import ResultLog
from app.models.report_log import ReportLog
from app.models.officer_login_log import OfficerLoginLog
from app.models.search_type import SearchType

router = APIRouter()


# Response Models
class RecentSearchItem(BaseModel):
    id: int
    search_query: str
    search_type: str
    searched_at: datetime
    
    class Config:
        from_attributes = True


class SearchTypeStats(BaseModel):
    search_type: str
    count: int


class ActivityStats(BaseModel):
    total_searches: int
    total_reports: int
    total_logins: int
    searches_this_week: int
    searches_this_month: int
    reports_this_week: int
    reports_this_month: int


class ProfileInfo(BaseModel):
    officer_id: int
    first_name: str
    last_name: str
    email: str
    phone_no: str
    gender: str
    dob: str
    branch_id: int
    is_active: bool
    created_at: datetime
    modified_at: datetime
    last_profile_updated: datetime
    account_age_days: int


class DashboardStats(BaseModel):
    profile_info: ProfileInfo
    activity_stats: ActivityStats
    recent_searches: List[RecentSearchItem]
    search_type_breakdown: List[SearchTypeStats]
    last_login: Optional[datetime]
    most_searched_platform: Optional[str]
    avg_searches_per_day: float


@router.get("/{officer_id}", response_model=DashboardStats)
def get_officer_dashboard(officer_id: int, db: Session = Depends(get_db)):
    """
    Get comprehensive dashboard statistics for a specific officer
    
    Returns:
    - Profile information including last update time
    - Total searches, reports, and logins
    - Recent activity (this week/month)
    - Recent searches list
    - Search type breakdown
    - Last login time
    - Most searched platform
    - Average searches per day
    """
    
    # 1. Get officer profile
    officer = db.query(Officer).filter(Officer.id == officer_id).first()
    if not officer:
        raise HTTPException(status_code=404, detail="Officer not found")
    
    # Calculate account age
    account_age = (datetime.utcnow() - officer.created_at).days
    
    profile_info = ProfileInfo(
        officer_id=officer.id,
        first_name=officer.first_name,
        last_name=officer.last_name,
        email=officer.email,
        phone_no=officer.phone_no,
        gender=officer.gender,
        dob=officer.dob.isoformat(),
        branch_id=officer.branch_id,
        is_active=officer.is_active,
        created_at=officer.created_at,
        modified_at=officer.modified_at,
        last_profile_updated=officer.modified_at,
        account_age_days=account_age
    )
    
    # 2. Get total counts
    total_searches = db.query(func.count(ResultLog.id)).filter(
        ResultLog.officer_id == officer_id
    ).scalar() or 0
    
    total_reports = db.query(func.count(ReportLog.id)).join(
        ResultLog, ReportLog.result_log_id == ResultLog.id
    ).filter(
        ResultLog.officer_id == officer_id
    ).scalar() or 0
    
    total_logins = db.query(func.count(OfficerLoginLog.id)).filter(
        OfficerLoginLog.officer_id == officer_id
    ).scalar() or 0
    
    # 3. Get activity for this week and month
    now = datetime.utcnow()
    week_ago = now - timedelta(days=7)
    month_ago = now - timedelta(days=30)
    
    searches_this_week = db.query(func.count(ResultLog.id)).filter(
        ResultLog.officer_id == officer_id,
        ResultLog.searched_at >= week_ago
    ).scalar() or 0
    
    searches_this_month = db.query(func.count(ResultLog.id)).filter(
        ResultLog.officer_id == officer_id,
        ResultLog.searched_at >= month_ago
    ).scalar() or 0
    
    reports_this_week = db.query(func.count(ReportLog.id)).join(
        ResultLog, ReportLog.result_log_id == ResultLog.id
    ).filter(
        ResultLog.officer_id == officer_id,
        ReportLog.reported_at >= week_ago
    ).scalar() or 0
    
    reports_this_month = db.query(func.count(ReportLog.id)).join(
        ResultLog, ReportLog.result_log_id == ResultLog.id
    ).filter(
        ResultLog.officer_id == officer_id,
        ReportLog.reported_at >= month_ago
    ).scalar() or 0
    
    activity_stats = ActivityStats(
        total_searches=total_searches,
        total_reports=total_reports,
        total_logins=total_logins,
        searches_this_week=searches_this_week,
        searches_this_month=searches_this_month,
        reports_this_week=reports_this_week,
        reports_this_month=reports_this_month
    )
    
    # 4. Get recent searches (last 10)
    recent_searches_query = db.query(
        ResultLog.id,
        ResultLog.search_query,
        SearchType.search_type,
        ResultLog.searched_at
    ).join(
        SearchType, ResultLog.search_type_id == SearchType.id
    ).filter(
        ResultLog.officer_id == officer_id
    ).order_by(
        desc(ResultLog.searched_at)
    ).limit(10).all()
    
    recent_searches = [
        RecentSearchItem(
            id=search.id,
            search_query=search.search_query,
            search_type=search.search_type,
            searched_at=search.searched_at
        )
        for search in recent_searches_query
    ]
    
    # 5. Get search type breakdown
    search_type_stats = db.query(
        SearchType.search_type,
        func.count(ResultLog.id).label('count')
    ).join(
        ResultLog, SearchType.id == ResultLog.search_type_id
    ).filter(
        ResultLog.officer_id == officer_id
    ).group_by(
        SearchType.search_type
    ).all()
    
    search_type_breakdown = [
        SearchTypeStats(search_type=stat.search_type, count=stat.count)
        for stat in search_type_stats
    ]
    
    # 6. Get last login
    last_login_record = db.query(OfficerLoginLog).filter(
        OfficerLoginLog.officer_id == officer_id
    ).order_by(
        desc(OfficerLoginLog.loggedin_at)
    ).first()
    
    last_login = last_login_record.loggedin_at if last_login_record else None
    
    # 7. Get most searched platform (from search queries or reports)
    most_searched_platform_query = db.query(
        ReportLog.social_media,
        func.count(ReportLog.id).label('count')
    ).join(
        ResultLog, ReportLog.result_log_id == ResultLog.id
    ).filter(
        ResultLog.officer_id == officer_id
    ).group_by(
        ReportLog.social_media
    ).order_by(
        desc('count')
    ).first()
    
    most_searched_platform = most_searched_platform_query.social_media if most_searched_platform_query else None
    
    # 8. Calculate average searches per day
    if account_age > 0:
        avg_searches_per_day = round(total_searches / account_age, 2)
    else:
        avg_searches_per_day = float(total_searches)
    
    # Build final response
    dashboard_stats = DashboardStats(
        profile_info=profile_info,
        activity_stats=activity_stats,
        recent_searches=recent_searches,
        search_type_breakdown=search_type_breakdown,
        last_login=last_login,
        most_searched_platform=most_searched_platform,
        avg_searches_per_day=avg_searches_per_day
    )
    
    return dashboard_stats


@router.get("/{officer_id}/activity-timeline", response_model=List[Dict])
def get_activity_timeline(
    officer_id: int, 
    days: int = 30,
    db: Session = Depends(get_db)
):
    """
    Get daily activity timeline for the officer (searches per day)
    
    Args:
        officer_id: ID of the officer
        days: Number of days to look back (default 30)
    
    Returns:
        List of daily activity counts
    """
    
    # Verify officer exists
    officer = db.query(Officer).filter(Officer.id == officer_id).first()
    if not officer:
        raise HTTPException(status_code=404, detail="Officer not found")
    
    # Get date range
    end_date = datetime.utcnow().date()
    start_date = end_date - timedelta(days=days)
    
    # Query searches grouped by date
    daily_searches = db.query(
        func.date(ResultLog.searched_at).label('date'),
        func.count(ResultLog.id).label('count')
    ).filter(
        ResultLog.officer_id == officer_id,
        func.date(ResultLog.searched_at) >= start_date
    ).group_by(
        func.date(ResultLog.searched_at)
    ).all()
    
    # Create a dictionary for easy lookup
    search_dict = {str(record.date): record.count for record in daily_searches}
    
    # Build complete timeline with zeros for days with no activity
    timeline = []
    current_date = start_date
    while current_date <= end_date:
        date_str = str(current_date)
        timeline.append({
            "date": date_str,
            "searches": search_dict.get(date_str, 0)
        })
        current_date += timedelta(days=1)
    
    return timeline


@router.get("/{officer_id}/quick-stats", response_model=Dict)
def get_quick_stats(officer_id: int, db: Session = Depends(get_db)):
    """
    Get quick statistics for dashboard widgets
    
    Returns minimal data for quick loading
    """
    
    # Verify officer exists
    officer = db.query(Officer).filter(Officer.id == officer_id).first()
    if not officer:
        raise HTTPException(status_code=404, detail="Officer not found")
    
    # Get counts
    total_searches = db.query(func.count(ResultLog.id)).filter(
        ResultLog.officer_id == officer_id
    ).scalar() or 0
    
    total_reports = db.query(func.count(ReportLog.id)).join(
        ResultLog, ReportLog.result_log_id == ResultLog.id
    ).filter(
        ResultLog.officer_id == officer_id
    ).scalar() or 0
    
    # Get today's activity
    today = datetime.utcnow().date()
    searches_today = db.query(func.count(ResultLog.id)).filter(
        ResultLog.officer_id == officer_id,
        func.date(ResultLog.searched_at) == today
    ).scalar() or 0
    
    return {
        "total_searches": total_searches,
        "total_reports": total_reports,
        "searches_today": searches_today,
        "last_profile_updated": officer.modified_at.isoformat(),
        "account_created": officer.created_at.isoformat()
    }
