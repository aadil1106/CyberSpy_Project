from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.schemas.search_type import SearchTypeCreate, SearchTypeRead, SearchTypeUpdate
from app.services import search_type_service

router = APIRouter()


@router.get("/", response_model=list[SearchTypeRead])
def list_search_types(is_active: bool | None = Query(None), db: Session = Depends(get_db)):
    return search_type_service.list_search_types(db, is_active=is_active)


@router.post("/", response_model=SearchTypeRead, status_code=201)
def create_search_type(search_type_in: SearchTypeCreate, db: Session = Depends(get_db)):
    return search_type_service.create_search_type(db, search_type_in)


@router.patch("/{search_type_id}", response_model=SearchTypeRead)
def update_search_type(search_type_id: int, search_type_in: SearchTypeUpdate, db: Session = Depends(get_db)):
    search_type = search_type_service.update_search_type(db, search_type_id, search_type_in)
    if not search_type:
        raise HTTPException(status_code=404, detail="Search type not found")
    return search_type

