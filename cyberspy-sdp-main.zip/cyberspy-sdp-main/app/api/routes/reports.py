from fastapi import APIRouter, Depends, Query, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from sqlalchemy import and_, func
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from datetime import datetime, date
import json
import os
import csv
import io
from pathlib import Path
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, landscape
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch

from app.db.session import get_db
from app.models.result_log import ResultLog
from app.models.officer import Officer
from app.models.branch import Branch
from app.models.city import City
from app.models.search_type import SearchType

router = APIRouter()

# Get the search_results directory path
SEARCH_RESULTS_DIR = Path(__file__).parent.parent.parent.parent / "search_results"


# Response Models
class SearchResultDetail(BaseModel):
    id: int
    officer_id: int
    officer_name: str
    branch_name: str
    city_name: str
    search_type: str
    search_query: str
    searched_at: datetime
    result_file_path: str
    file_data: Optional[Dict[str, Any]] = None
    
    class Config:
        from_attributes = True


class PaginatedResults(BaseModel):
    total: int
    page: int
    page_size: int
    total_pages: int
    results: List[SearchResultDetail]


def read_json_file(file_path: str):
    """Read and parse JSON file"""
    try:
        if not file_path:
            return None
        # Normalize to forward slashes for consistent handling
        normalized = file_path.replace("\\", "/")
        # The DB stores paths like "search_results/filename.json" but SEARCH_RESULTS_DIR
        # already points to the search_results folder — strip the leading prefix if present
        if normalized.startswith("search_results/"):
            normalized = normalized[len("search_results/"):]
        full_path = SEARCH_RESULTS_DIR / normalized
        if full_path.exists():
            with open(full_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        # Fallback: try path relative to project root (covers other storage patterns)
        alt_path = Path(__file__).parent.parent.parent.parent / file_path.replace("\\", "/")
        if alt_path.exists():
            with open(alt_path, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception as e:
        print(f"Error reading {file_path}: {e}")
    return None


def deep_search_match(term: str, data: Any) -> bool:
    """Recursively search for string term in dictionaries and lists."""
    if isinstance(data, dict):
        for k, v in data.items():
            if term in str(k).lower():
                return True
            if deep_search_match(term, v):
                return True
        return False
    elif isinstance(data, list):
        for item in data:
            if deep_search_match(term, item):
                return True
        return False
    elif data is not None:
        return term in str(data).lower()
    return False


@router.get("/filter", response_model=PaginatedResults)
def filter_reports(
    officer_id: Optional[int] = Query(None, description="Filter by officer ID"),
    city_name: Optional[str] = Query(None, description="Filter by city name"),
    branch_name: Optional[str] = Query(None, description="Filter by branch name"),
    search_type_id: Optional[int] = Query(None, description="Filter by search type ID"),
    social_media: Optional[str] = Query(None, description="Filter by social media platform"),
    username: Optional[str] = Query(None, description="Filter by username (partial match)"),
    date_from: Optional[date] = Query(None, description="Filter reports from this date (YYYY-MM-DD)"),
    date_to: Optional[date] = Query(None, description="Filter reports until this date (YYYY-MM-DD)"),
    global_search: Optional[str] = Query(None, description="Deep search across all metadata and JSON results"),
    page: int = Query(1, ge=1, description="Page number"),
    page_size: int = Query(20, ge=1, le=1000, description="Results per page"),
    db: Session = Depends(get_db)
):
    """
    Get filtered search results from database with JSON file data
    """
    
    # Build base query with joins
    query = db.query(
        ResultLog.id,
        ResultLog.officer_id,
        ResultLog.search_type_id,
        ResultLog.search_query,
        ResultLog.searched_at,
        ResultLog.result_file_path,
        Officer.first_name,
        Officer.last_name,
        Branch.branch_name,
        City.city_name,
        SearchType.search_type
    ).join(
        Officer, ResultLog.officer_id == Officer.id
    ).join(
        Branch, Officer.branch_id == Branch.id
    ).join(
        City, Branch.city_id == City.id
    ).join(
        SearchType, ResultLog.search_type_id == SearchType.id
    )
    
    # Apply filters
    filters = []
    
    if officer_id is not None:
        filters.append(ResultLog.officer_id == officer_id)
    
    if city_name:
        filters.append(City.city_name.ilike(f"%{city_name}%"))
    
    if branch_name:
        filters.append(Branch.branch_name.ilike(f"%{branch_name}%"))
    
    if search_type_id is not None:
        filters.append(ResultLog.search_type_id == search_type_id)
    
    if username:
        filters.append(ResultLog.search_query.ilike(f"%{username}%"))
    
    if date_from:
        filters.append(func.date(ResultLog.searched_at) >= date_from)
    
    if date_to:
        filters.append(func.date(ResultLog.searched_at) <= date_to)
    
    if filters:
        query = query.filter(and_(*filters))
    
    # Get total count of DB-only filters
    total = query.count()
    
    # Apply sorting (newest first)
    query = query.order_by(ResultLog.searched_at.desc())
    
    needs_python_filtering = bool(social_media or global_search)
    
    if needs_python_filtering:
        # Fetch all matching DB records since we need to filter Python-side
        results = query.all()
    else:
        # Apply standard DB pagination
        offset = (page - 1) * page_size
        query = query.offset(offset).limit(page_size)
        results = query.all()
    
    # Format results and load JSON data
    formatted_results = []
    
    # Fast path: pre-lower the global search term
    g_term = global_search.lower() if global_search else None
    
    for r in results:
        # Read JSON file data
        file_data = read_json_file(r.result_file_path)
        
        # Apply social media filter if specified
        if social_media:
            # No file data means we cannot confirm the platform → exclude
            if not file_data:
                continue
            sm_lower = social_media.lower()
            has_platform = False
            # 1) multi-search: top-level 'platforms' list
            if any(sm_lower in str(p).lower() for p in file_data.get('platforms', [])):
                has_platform = True
            # 2) multi-search: results[].platform
            if not has_platform:
                for result in file_data.get('results', []):
                    if sm_lower in str(result.get('platform', '')).lower():
                        has_platform = True
                        break
            # 3) single-result: root-level 'platform' key
            if not has_platform:
                if sm_lower in str(file_data.get('platform', '')).lower():
                    has_platform = True
            if not has_platform:
                continue
                
        # Apply strict deep search if specified
        if g_term:
            basic_match = False
            basic_fields = [
                r.first_name, r.last_name, r.branch_name, r.city_name,
                r.search_type, r.search_query, r.id, r.result_file_path
            ]
            for field in basic_fields:
                if field and g_term in str(field).lower():
                    basic_match = True
                    break
            
            if not basic_match:
                if not file_data or not deep_search_match(g_term, file_data):
                    continue
        
        formatted_results.append(SearchResultDetail(
            id=r.id,
            officer_id=r.officer_id,
            officer_name=f"{r.first_name} {r.last_name}",
            branch_name=r.branch_name,
            city_name=r.city_name,
            search_type=r.search_type,
            search_query=r.search_query,
            searched_at=r.searched_at,
            result_file_path=r.result_file_path,
            file_data=file_data
        ))
    
    if needs_python_filtering:
        actual_total = len(formatted_results)
        offset = (page - 1) * page_size
        paginated_results = formatted_results[offset:offset + page_size]
    else:
        actual_total = total
        paginated_results = formatted_results
        
    total_pages = (actual_total + page_size - 1) // page_size if actual_total > 0 else 0
    
    return PaginatedResults(
        total=actual_total,
        page=page,
        page_size=page_size,
        total_pages=total_pages,
        results=paginated_results
    )


@router.get("/statistics", response_model=dict)
def get_report_statistics(
    officer_id: Optional[int] = Query(None, description="Filter by officer ID"),
    city_name: Optional[str] = Query(None, description="Filter by city name"),
    branch_name: Optional[str] = Query(None, description="Filter by branch name"),
    social_media: Optional[str] = Query(None, description="Filter by social media platform"),
    username: Optional[str] = Query(None, description="Filter by username (partial match)"),
    date_from: Optional[date] = Query(None, description="Statistics from this date"),
    date_to: Optional[date] = Query(None, description="Statistics until this date"),
    db: Session = Depends(get_db)
):
    """
    Get statistics about search results
    """
    
    # Build base query
    query = db.query(ResultLog).join(
        Officer, ResultLog.officer_id == Officer.id
    ).join(
        Branch, Officer.branch_id == Branch.id
    ).join(
        City, Branch.city_id == City.id
    )
    
    # Apply filters
    filters = []
    if officer_id is not None:
        filters.append(ResultLog.officer_id == officer_id)
    if city_name:
        filters.append(City.city_name.ilike(f"%{city_name}%"))
    if branch_name:
        filters.append(Branch.branch_name.ilike(f"%{branch_name}%"))
    if date_from:
        filters.append(func.date(ResultLog.searched_at) >= date_from)
    if date_to:
        filters.append(func.date(ResultLog.searched_at) <= date_to)
    if username:
        filters.append(ResultLog.search_query.ilike(f"%{username}%"))
    
    if filters:
        query = query.filter(and_(*filters))
    
    # Get all results from DB
    all_results = query.all()
    
    # Apply Python-side social_media filter (requires reading JSON files)
    sm_lower = social_media.lower() if social_media else None
    filtered_results = []
    platform_counts = {}

    for result in all_results:
        file_data = read_json_file(result.result_file_path)

        # ── social_media filter ──────────────────────────────────────────────
        if sm_lower:
            if not file_data:
                continue  # can't confirm platform, exclude
            has_platform = False
            # 1) top-level 'platforms' list
            if any(sm_lower in str(p).lower() for p in file_data.get('platforms', [])):
                has_platform = True
            # 2) results[].platform
            if not has_platform:
                for r in file_data.get('results', []):
                    if sm_lower in str(r.get('platform', '')).lower():
                        has_platform = True
                        break
            # 3) single-result root 'platform'
            if not has_platform:
                if sm_lower in str(file_data.get('platform', '')).lower():
                    has_platform = True
            if not has_platform:
                continue

        filtered_results.append(result)

        # ── platform counting (all three shapes) ─────────────────────────────
        if file_data:
            # shape 1: top-level 'platforms' list
            for p in file_data.get('platforms', []):
                key = str(p).lower()
                platform_counts[key] = platform_counts.get(key, 0) + 1
            # shape 2: results[].platform
            for r in file_data.get('results', []):
                p = r.get('platform')
                if p:
                    key = str(p).lower()
                    # avoid double-counting if already in 'platforms'
                    if not file_data.get('platforms'):
                        platform_counts[key] = platform_counts.get(key, 0) + 1
            # shape 3: single-result root 'platform' (only when no 'results' list)
            if not file_data.get('results') and not file_data.get('platforms'):
                p = file_data.get('platform')
                if p:
                    key = str(p).lower()
                    platform_counts[key] = platform_counts.get(key, 0) + 1

    all_results = filtered_results
    total_searches = len(all_results)

    # Calculate statistics
    filtered_officer_ids = list({r.officer_id for r in all_results})
    unique_officers = len(filtered_officer_ids)

    # Get unique cities from the filtered officer set (DB query, always accurate)
    if filtered_officer_ids:
        unique_cities = db.query(City.id).join(
            Branch, City.id == Branch.city_id
        ).join(
            Officer, Branch.id == Officer.branch_id
        ).filter(Officer.id.in_(filtered_officer_ids)).distinct().count()
    else:
        unique_cities = 0

    platforms_by_count = [
        {"platform": platform, "count": count}
        for platform, count in sorted(platform_counts.items(), key=lambda x: x[1], reverse=True)
    ]

    # Top officers — scoped to the Python-filtered set
    officer_query = db.query(
        Officer.id,
        Officer.first_name,
        Officer.last_name,
        func.count(ResultLog.id).label('search_count')
    ).join(
        ResultLog, Officer.id == ResultLog.officer_id
    ).join(
        Branch, Officer.branch_id == Branch.id
    ).join(
        City, Branch.city_id == City.id
    )

    if filtered_officer_ids:
        officer_query = officer_query.filter(Officer.id.in_(filtered_officer_ids))
    
    top_officers_results = officer_query.group_by(
        Officer.id, Officer.first_name, Officer.last_name
    ).order_by(
        func.count(ResultLog.id).desc()
    ).limit(5).all()
    
    top_officers = [
        {
            "officer_id": r.id,
            "officer_name": f"{r.first_name} {r.last_name}",
            "search_count": r.search_count
        }
        for r in top_officers_results
    ]
    
    return {
        "total_searches": total_searches,
        "unique_officers": unique_officers,
        "unique_cities": unique_cities,
        "platforms_covered": len(platform_counts),
        "searches_by_platform": platforms_by_count,
        "top_officers": top_officers,
        "date_range": {
            "from": date_from.isoformat() if date_from else None,
            "to": date_to.isoformat() if date_to else None
        }
    }



# ─────────────────────────────────────────────────────────────────────────────
# Helper: normalise the per-platform results out of a JSON file
# ─────────────────────────────────────────────────────────────────────────────
def normalize_file_results(file_data: dict, search_query: str) -> list:
    """
    Returns a list of normalised result dicts regardless of whether the JSON
    file uses the multi-result shape { results: [...] } or the single-result
    shape { result: {...}, platform: ..., username: ... }.
    Each item is guaranteed to have:
        platform, username, found, profile_url, profile, cybercrime, ai_summary
    """
    if not file_data:
        return []

    raw_results = []

    if isinstance(file_data.get("results"), list):
        raw_results = file_data["results"]
    elif "result" in file_data or "profile" in file_data:
        raw_results = [file_data]   # treat the whole object as one result

    normalised = []
    for r in raw_results:
        # Handle the legacy wrapper { instagram_data: { profile, cybercrime_analysis } }
        inner = r.get("instagram_data") or r.get("twitter_data") or {}
        profile = inner.get("profile") or r.get("result", {}).get("profile") or r.get("profile") or {}
        cyber   = (inner.get("cybercrime_analysis")
                   or r.get("result", {}).get("cybercrime_analysis")
                   or r.get("cybercrime_analysis") or {})
        ai_sum  = (inner.get("ai_summary")
                   or r.get("result", {}).get("ai_summary")
                   or r.get("ai_summary") or "")

        plat    = r.get("platform") or file_data.get("platform") or "N/A"
        uname   = r.get("username") or file_data.get("username") or search_query
        found   = r.get("found")
        if found is None:
            found = file_data.get("result", {}).get("found", False) if "result" in file_data else False
        p_url   = (r.get("profile_url")
                   or (f"https://{plat}.com/{uname}" if plat not in ("N/A", "") else ""))

        normalised.append({
            "platform":   plat,
            "username":   uname,
            "found":      found,
            "profile_url": p_url,
            "profile":    profile,
            "cybercrime": cyber,
            "ai_summary": ai_sum,
        })

    return normalised


# ─────────────────────────────────────────────────────────────────────────────
# CSV Export
# ─────────────────────────────────────────────────────────────────────────────
@router.get("/export/csv")
def export_reports_csv(
    officer_id: Optional[int] = Query(None),
    city_name:  Optional[str] = Query(None),
    branch_name:Optional[str] = Query(None),
    search_type_id: Optional[int] = Query(None),
    social_media:Optional[str]= Query(None),
    username:   Optional[str] = Query(None),
    date_from:  Optional[date]= Query(None),
    date_to:    Optional[date]= Query(None),
    global_search: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """Export filtered search results to CSV (server-side, using Python csv library)."""

    results_response = filter_reports(
        officer_id=officer_id, city_name=city_name, branch_name=branch_name,
        search_type_id=search_type_id, social_media=social_media, username=username,
        date_from=date_from, date_to=date_to,
        global_search=global_search, page=1, page_size=10000, db=db
    )

    output = io.StringIO()
    writer = csv.writer(output, quoting=csv.QUOTE_ALL)

    # ── Header ─────────────────────────────────────────────────────────────
    writer.writerow([
        'ID', 'Search Type', 'Search Query', 'Reporting Officer', 'Branch', 'City',
        'Searched Date', 'Platform', 'Target Username', 'Found Status', 'Profile URL',
        'Profile Name', 'Biography', 'Followers', 'Following', 'Post Count',
        'Is Private', 'Is Verified',
        'Risk Level', 'Risk Score', 'Assigned Categories', 'Risk Synthesis',
        'Key Indicators', 'AI Analysis Summary',
        'Stored Result Path'
    ])

    # ── Rows ───────────────────────────────────────────────────────────────
    for rec in results_response.results:
        base = [
            rec.id, rec.search_type, rec.search_query,
            rec.officer_name, rec.branch_name, rec.city_name,
            rec.searched_at.strftime('%Y-%m-%d %H:%M:%S'),
        ]

        platform_results = normalize_file_results(rec.file_data or {}, rec.search_query)

        if not platform_results:
            writer.writerow(base + ['N/A'] * 17 + [rec.result_file_path])
            continue

        for pr in platform_results:
            prof  = pr["profile"]
            cyber = pr["cybercrime"]
            writer.writerow(base + [
                pr["platform"],
                pr["username"],
                'Yes' if pr["found"] else 'No',
                pr["profile_url"],
                prof.get("full_name", ""),
                prof.get("biography", ""),
                prof.get("followers", ""),
                prof.get("following", ""),
                prof.get("posts_count", ""),
                'Yes' if prof.get("is_private") else 'No',
                'Yes' if prof.get("is_verified") else 'No',
                cyber.get("risk_level", "N/A"),
                cyber.get("risk_score", "N/A"),
                ", ".join(cyber.get("categories", [])),
                cyber.get("summary", ""),
                "; ".join(cyber.get("indicators", [])),
                pr["ai_summary"],
                rec.result_file_path,
            ])

    output.seek(0)
    content = output.getvalue().encode("utf-8-sig")   # utf-8-sig → Excel opens correctly
    return StreamingResponse(
        iter([content]),
        media_type="text/csv",
        headers={
            "Content-Disposition": (
                f"attachment; filename=search_results_"
                f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
            )
        }
    )


# ─────────────────────────────────────────────────────────────────────────────
# PDF Export
# ─────────────────────────────────────────────────────────────────────────────
@router.get("/export/pdf")
def export_reports_pdf(
    officer_id: Optional[int] = Query(None),
    city_name:  Optional[str] = Query(None),
    branch_name:Optional[str] = Query(None),
    search_type_id: Optional[int] = Query(None),
    social_media:Optional[str]= Query(None),
    username:   Optional[str] = Query(None),
    date_from:  Optional[date]= Query(None),
    date_to:    Optional[date]= Query(None),
    global_search: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """Export filtered search results to PDF (server-side, using ReportLab)."""

    results_response = filter_reports(
        officer_id=officer_id, city_name=city_name, branch_name=branch_name,
        search_type_id=search_type_id, social_media=social_media, username=username,
        date_from=date_from, date_to=date_to,
        global_search=global_search, page=1, page_size=10000, db=db
    )

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=landscape(letter),
        leftMargin=0.4*inch, rightMargin=0.4*inch,
        topMargin=0.5*inch,  bottomMargin=0.5*inch,
    )

    styles   = getSampleStyleSheet()
    elements = []

    # ── Colour palette ──────────────────────────────────────────────────────
    HDR_BG   = colors.HexColor("#0f172a")   # slate-900 header
    HDR_FG   = colors.whitesmoke
    ROW_ALT  = colors.HexColor("#f8fafc")   # slate-50 alternate
    ROW_NORM = colors.white
    RISK_H   = colors.HexColor("#fee2e2")   # red-100
    RISK_M   = colors.HexColor("#fef3c7")   # amber-100
    RISK_L   = colors.HexColor("#dcfce7")   # green-100

    # ── Title block ─────────────────────────────────────────────────────────
    title_style = styles["Title"]
    title_style.textColor = colors.HexColor("#0f172a")
    title_style.alignment = 1 # Center align
    title_style.fontSize = 22
    title_style.spaceAfter = 14
    elements.append(Paragraph("<b>CYBERSPY — INTELLIGENCE REPORT</b>", title_style))
    elements.append(Spacer(1, 0.08*inch))

    # Filter summary line
    parts = []
    if officer_id:  parts.append(f"<b>Officer ID:</b> {officer_id}")
    if city_name:   parts.append(f"<b>City:</b> {city_name}")
    if branch_name: parts.append(f"<b>Branch:</b> {branch_name}")
    if social_media:parts.append(f"<b>Platform:</b> {social_media}")
    if username:    parts.append(f"<b>Subject:</b> {username}")
    if date_from:   parts.append(f"<b>From:</b> {date_from}")
    if date_to:     parts.append(f"<b>To:</b> {date_to}")
    filter_str = " | ".join(parts) if parts else "<b>Filters:</b> None (All records)"

    meta_style = styles["Normal"]
    meta_style.fontSize = 8.5
    meta_style.textColor = colors.HexColor("#64748b")
    elements.append(Paragraph(
        f"<b>Generated:</b> {datetime.now().strftime('%d %b %Y, %H:%M:%S')}  &nbsp;|&nbsp; "
        f"<b>Total records:</b> {results_response.total}  &nbsp;|&nbsp; {filter_str}",
        meta_style
    ))
    elements.append(Spacer(1, 0.2*inch))

    # ── Build table rows ────────────────────────────────────────────────────
    cell_style = styles["Normal"]
    cell_style.fontSize = 7
    cell_style.leading  = 9
    
    # Create a slightly smaller font style for long text like Categories
    small_cell_style = styles["Normal"]
    small_cell_style.fontSize = 6.5
    small_cell_style.leading = 8

    def P(text, bold=False, small=False, is_header=False):
        """Wrap text in a Paragraph for word-wrapping inside table cells."""
        txt = str(text) if text is not None else ""
        txt = txt.replace('\n', '<br />')
        if is_header:
            txt = f"<font color='white'>{txt}</font>"
        tag = "b" if bold else "span"
        style_to_use = small_cell_style if small else cell_style
        return Paragraph(f"<{tag}>{txt}</{tag}>" if bold else txt, style_to_use)

    headers = [
        P("ID", bold=True, is_header=True), P("Query", bold=True, is_header=True), P("Officer", bold=True, is_header=True),
        P("Location", bold=True, is_header=True), P("Platform", bold=True, is_header=True),
        P("Username", bold=True, is_header=True), P("Found", bold=True, is_header=True),
        P("Profile", bold=True, is_header=True), P("Followers", bold=True, is_header=True),
        P("Risk", bold=True, is_header=True), P("Score", bold=True, is_header=True),
        P("Categories", bold=True, is_header=True), P("Date", bold=True, is_header=True),
    ]
    table_data   = [headers]
    risk_row_map = {}   # row_index → risk level string

    row_idx = 1
    for rec in results_response.results:
        platform_results = normalize_file_results(rec.file_data or {}, rec.search_query)

        if not platform_results:
            table_data.append([
                P(rec.id), P(rec.search_query), P(rec.officer_name),
                P(f"{rec.branch_name}\n{rec.city_name}"), P("N/A"), P("N/A"),
                P("N/A"), P("N/A"), P("N/A"), P("N/A"), P("N/A"), P("N/A", small=True),
                P(rec.searched_at.strftime("%Y-%m-%d")),
            ])
            row_idx += 1
            continue

        for pr in platform_results:
            prof  = pr["profile"]
            cyber = pr["cybercrime"]
            rl    = str(cyber.get("risk_level", "N/A")).lower()
            risk_row_map[row_idx] = rl

            cats = ", ".join(cyber.get("categories", []))
            table_data.append([
                P(rec.id),
                P(rec.search_query, bold=True),
                P(rec.officer_name),
                P(f"{rec.branch_name}\n{rec.city_name}"),
                P(str(pr["platform"]).title()),
                P(pr["username"]),
                P("Yes" if pr["found"] else "No", bold=pr["found"]),
                P(prof.get("full_name", "")),
                P(prof.get("followers", "")),
                P(rl.upper() if rl != "n/a" else "N/A", bold=True),
                P(cyber.get("risk_score", "")),
                P(cats, small=True),
                P(rec.searched_at.strftime("%Y-%m-%d")),
            ])
            row_idx += 1

    # ── Column widths (total ≈ 10.2 inches for landscape letter leaving 0.8 margins) ──────────────
    col_widths = [
        0.35*inch,  # ID
        1.0*inch,   # Query
        1.1*inch,   # Officer
        1.2*inch,   # Location
        0.75*inch,  # Platform
        1.1*inch,   # Username
        0.45*inch,  # Found
        1.1*inch,   # Profile
        0.65*inch,  # Followers
        0.65*inch,  # Risk Lvl
        0.45*inch,  # Score
        1.4*inch,   # Categories
        0.65*inch,  # Date
    ]

    table = Table(table_data, colWidths=col_widths, repeatRows=1)

    # Base style
    ts = TableStyle([
        # Header row
        ("BACKGROUND",  (0, 0), (-1, 0),  HDR_BG),
        ("TEXTCOLOR",   (0, 0), (-1, 0),  HDR_FG),
        ("FONTNAME",    (0, 0), (-1, 0),  "Helvetica-Bold"),
        ("FONTSIZE",    (0, 0), (-1, 0),  8.5),
        ("BOTTOMPADDING",(0,0), (-1, 0),  8),
        ("TOPPADDING",  (0, 0), (-1, 0),  8),
        # Data rows
        ("FONTNAME",    (0, 1), (-1, -1), "Helvetica"),
        ("FONTSIZE",    (0, 1), (-1, -1), 7),
        ("TOPPADDING",  (0, 1), (-1, -1), 5),
        ("BOTTOMPADDING",(0, 1),(-1, -1), 5),
        ("VALIGN",      (0, 0), (-1, -1), "TOP"),
        ("ALIGN",       (0, 0), (-1, -1), "LEFT"),
        # Grid
        ("LINEBELOW",   (0, 0), (-1, 0),  1.0, colors.HexColor("#0f172a")),
        ("INNERGRID",   (0, 1), (-1, -1), 0.25, colors.HexColor("#e2e8f0")),
        ("BOX",         (0, 0), (-1, -1), 0.5,  colors.HexColor("#cbd5e1")),
    ])

    # Alternating row backgrounds
    for i in range(1, len(table_data)):
        bg = ROW_ALT if i % 2 == 0 else ROW_NORM
        ts.add("BACKGROUND", (0, i), (-1, i), bg)

    # Risk-level row colouring (overwrites alternate for risk column)
    for i, rl in risk_row_map.items():
        if rl == "high":
            ts.add("BACKGROUND", (9, i), (9, i), RISK_H)
            ts.add("TEXTCOLOR",  (9, i), (9, i), colors.HexColor("#991b1b"))
        elif rl == "medium":
            ts.add("BACKGROUND", (9, i), (9, i), RISK_M)
            ts.add("TEXTCOLOR",  (9, i), (9, i), colors.HexColor("#92400e"))
        elif rl == "low":
            ts.add("BACKGROUND", (9, i), (9, i), RISK_L)
            ts.add("TEXTCOLOR",  (9, i), (9, i), colors.HexColor("#166534"))

    table.setStyle(ts)
    elements.append(table)

    # ── Footer note ─────────────────────────────────────────────────────────
    elements.append(Spacer(1, 0.2*inch))
    foot_style = styles["Normal"]
    foot_style.fontSize = 6.5
    foot_style.textColor = colors.HexColor("#94a3b8")
    elements.append(Paragraph(
        "<b>CONFIDENTIAL</b> &mdash; CyberSpy Open Source Intelligence Platform | "
        f"Generated on {datetime.now().strftime('%d %b %Y %H:%M')} (Server Time)",
        foot_style
    ))

    doc.build(elements)
    buffer.seek(0)

    return StreamingResponse(
        iter([buffer.getvalue()]),
        media_type="application/pdf",
        headers={
            "Content-Disposition": (
                f"attachment; filename=search_results_"
                f"{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
            )
        }
    )


