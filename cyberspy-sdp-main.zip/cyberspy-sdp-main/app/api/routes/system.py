from fastapi import APIRouter
from fastapi.responses import RedirectResponse

router = APIRouter()


@router.get("/health")
def health_check():
    return {"status": "ok"}


@router.get("/admin")
def admin_redirect():
    """Redirect to admin panel"""
    return RedirectResponse(url="/static/admin/index.html")

