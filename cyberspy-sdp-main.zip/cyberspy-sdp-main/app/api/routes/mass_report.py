from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from sqlalchemy import func, and_
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime, date
import io
import csv
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, landscape
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
import json
import random
from pathlib import Path

from app.db.session import get_db
from app.models.result_log import ResultLog
from app.models.search_type import SearchType
from app.models.officer import Officer
from app.models.report_log import ReportLog

router = APIRouter()


class RecentSearchItem(BaseModel):
    id: int
    officer_id: int
    officer_name: str
    search_type: str
    search_query: str
    searched_at: datetime
    result_file_path: str
    
    class Config:
        from_attributes = True


class SearchResultData(BaseModel):
    log_id: int
    search_type: str
    search_query: str
    searched_at: datetime
    result_data: dict


class MassReportRequest(BaseModel):
    log_id: int
    platforms: List[str]  # List of platform usernames to report


class MassReportResponse(BaseModel):
    success: bool
    message: str
    reported_count: int
    failed_count: int
    details: List[dict]


@router.get("/recent-searches", response_model=List[RecentSearchItem])
def get_recent_searches(
    limit: int = 50,
    search_type: Optional[str] = None,
    db: Session = Depends(get_db)
):
    """
    Get recent searches for mass reporting.
    Returns searches from both multi-platform and single-platform types.
    """
    query = db.query(
        ResultLog.id,
        ResultLog.officer_id,
        ResultLog.search_query,
        ResultLog.searched_at,
        ResultLog.result_file_path,
        SearchType.search_type,
        Officer.first_name,
        Officer.last_name
    ).join(
        SearchType, ResultLog.search_type_id == SearchType.id
    ).join(
        Officer, ResultLog.officer_id == Officer.id
    )
    
    # Filter by search type if provided
    if search_type:
        query = query.filter(SearchType.search_type == search_type)
    
    # Order by most recent first
    query = query.order_by(ResultLog.searched_at.desc()).limit(limit)
    
    results = query.all()
    
    return [
        RecentSearchItem(
            id=r.id,
            officer_id=r.officer_id,
            officer_name=f"{r.first_name} {r.last_name}",
            search_type=r.search_type,
            search_query=r.search_query,
            searched_at=r.searched_at,
            result_file_path=r.result_file_path
        )
        for r in results
    ]


@router.get("/search-result/{log_id}", response_model=SearchResultData)
def get_search_result_for_reporting(log_id: int, db: Session = Depends(get_db)):
    """
    Get the full search result data for a specific log ID.
    This will be used to display results before mass reporting.
    """
    result = db.query(
        ResultLog.id,
        ResultLog.search_query,
        ResultLog.searched_at,
        ResultLog.result_file_path,
        SearchType.search_type
    ).join(
        SearchType, ResultLog.search_type_id == SearchType.id
    ).filter(
        ResultLog.id == log_id
    ).first()
    
    if not result:
        raise HTTPException(status_code=404, detail="Search result not found")
    
    # Read the result data from JSON file
    result_data = {}
    try:
        file_path = Path(result.result_file_path)
        if file_path.exists():
            with open(file_path, 'r', encoding='utf-8') as f:
                result_data = json.load(f)
        else:
            raise HTTPException(status_code=404, detail="Result file not found")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error reading result file: {str(e)}")
    
    return SearchResultData(
        log_id=result.id,
        search_type=result.search_type,
        search_query=result.search_query,
        searched_at=result.searched_at,
        result_data=result_data
    )


@router.post("/mass-report", response_model=MassReportResponse)
def create_mass_report(
    request: MassReportRequest,
    db: Session = Depends(get_db)
):
    """
    Create mass reports for multiple platforms from a search result.
    This endpoint will report selected accounts across different platforms
    and log each report to the database.
    """
    # Get the search result
    result = db.query(ResultLog).filter(ResultLog.id == request.log_id).first()
    
    if not result:
        raise HTTPException(status_code=404, detail="Search result not found")
    
    # Read the result data
    try:
        file_path = Path(result.result_file_path)
        if not file_path.exists():
            raise HTTPException(status_code=404, detail="Result file not found")
        
        with open(file_path, 'r', encoding='utf-8') as f:
            result_data = json.load(f)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error reading result file: {str(e)}")
    
    # Process mass reporting
    reported_count = 0
    failed_count = 0
    details = []
    
    for platform_info in request.platforms:
        try:
            # Extract platform and username from the format "platform:username"
            if ':' in platform_info:
                platform, username = platform_info.split(':', 1)
            else:
                platform = "unknown"
                username = platform_info
            
            # Perform actual reporting (simulated for now)
            # TODO: Integrate with platform-specific reporting APIs
            # In production, replace this with actual API calls to platform reporting systems
            reporting_success = random.random() > 0.1  # 90% success rate for demonstration
            
            if reporting_success:
                # Log successful report to database
                report_log = ReportLog(
                    result_log_id=request.log_id,
                    username=username,
                    social_media=platform,
                    reporting_results=f"Successfully reported {username} on {platform}",
                    reported_at=datetime.utcnow()
                )
                db.add(report_log)
                
                reported_count += 1
                details.append({
                    "platform": platform,
                    "username": username,
                    "status": "success",
                    "message": f"Successfully reported {username} on {platform}"
                })
            else:
                # Log failed report to database
                report_log = ReportLog(
                    result_log_id=request.log_id,
                    username=username,
                    social_media=platform,
                    reporting_results=f"Failed to report {username} on {platform} - Platform API unavailable",
                    reported_at=datetime.utcnow()
                )
                db.add(report_log)
                
                failed_count += 1
                details.append({
                    "platform": platform,
                    "username": username,
                    "status": "failed",
                    "message": f"Failed to report {username} on {platform} - Platform API unavailable"
                })
                
        except Exception as e:
            # Log error to database
            try:
                report_log = ReportLog(
                    result_log_id=request.log_id,
                    username=username if 'username' in locals() else platform_info,
                    social_media=platform if 'platform' in locals() else "unknown",
                    reporting_results=f"Error: {str(e)}",
                    reported_at=datetime.utcnow()
                )
                db.add(report_log)
            except:
                pass  # If even logging fails, continue
            
            failed_count += 1
            details.append({
                "platform": platform if 'platform' in locals() else "unknown",
                "username": username if 'username' in locals() else platform_info,
                "status": "error",
                "message": str(e)
            })
    
    # Commit all report logs to database
    try:
        db.commit()
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error saving report logs: {str(e)}")
    
    return MassReportResponse(
        success=reported_count > 0,
        message=f"Mass reporting completed: {reported_count} successful, {failed_count} failed",
        reported_count=reported_count,
        failed_count=failed_count,
        details=details
    )


# -------------------------------------------------------------------------
# History and Export Endpoints
# -------------------------------------------------------------------------

class ReportLogItem(BaseModel):
    id: int
    result_log_id: int
    officer_name: str
    search_query: str
    target_username: str
    platform: str
    status: str
    message: str
    reported_at: datetime

    class Config:
        from_attributes = True


class PaginatedReportLogs(BaseModel):
    total: int
    page: int
    page_size: int
    total_pages: int
    results: List[ReportLogItem]


def get_mass_report_history_query(
    db: Session,
    officer_id: Optional[int] = None,
    social_media: Optional[str] = None,
    date_from: Optional[date] = None,
    date_to: Optional[date] = None,
    global_search: Optional[str] = None
):
    query = db.query(
        ReportLog,
        ResultLog.search_query,
        Officer.first_name,
        Officer.last_name
    ).join(
        ResultLog, ReportLog.result_log_id == ResultLog.id
    ).join(
        Officer, ResultLog.officer_id == Officer.id
    )

    filters = []
    if officer_id is not None:
        filters.append(ResultLog.officer_id == officer_id)
    if social_media:
        filters.append(ReportLog.social_media.ilike(f"%{social_media}%"))
    if date_from:
        filters.append(func.date(ReportLog.reported_at) >= date_from)
    if date_to:
        filters.append(func.date(ReportLog.reported_at) <= date_to)

    if global_search:
        search_filter = and_(
            ReportLog.social_media.ilike(f"%{global_search}%") | 
            ReportLog.username.ilike(f"%{global_search}%") | 
            ResultLog.search_query.ilike(f"%{global_search}%")
        )
        filters.append(search_filter)

    if filters:
        query = query.filter(and_(*filters))

    return query.order_by(ReportLog.reported_at.desc())


@router.get("/history", response_model=PaginatedReportLogs)
def get_mass_report_history(
    officer_id: Optional[int] = Query(None),
    social_media: Optional[str] = Query(None),
    date_from: Optional[date] = Query(None),
    date_to: Optional[date] = Query(None),
    global_search: Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=1000),
    db: Session = Depends(get_db)
):
    """
    Get paginated mass reporting history.
    """
    query = get_mass_report_history_query(
        db, officer_id, social_media, date_from, date_to, global_search
    )
    
    total = query.count()
    offset = (page - 1) * page_size
    results = query.offset(offset).limit(page_size).all()
    
    formatted = []
    for log, search_query, first_name, last_name in results:
        status = "Success" if "Successfully" in log.reporting_results else "Failed"
        formatted.append(ReportLogItem(
            id=log.id,
            result_log_id=log.result_log_id,
            officer_name=f"{first_name} {last_name}",
            search_query=search_query,
            target_username=log.username,
            platform=log.social_media,
            status=status,
            message=log.reporting_results,
            reported_at=log.reported_at
        ))
        
    total_pages = (total + page_size - 1) // page_size if total > 0 else 0
    
    return PaginatedReportLogs(
        total=total,
        page=page,
        page_size=page_size,
        total_pages=total_pages,
        results=formatted
    )


@router.get("/export/csv")
def export_mass_report_csv(
    officer_id: Optional[int] = Query(None),
    social_media: Optional[str] = Query(None),
    date_from: Optional[date] = Query(None),
    date_to: Optional[date] = Query(None),
    global_search: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """Export mass reporting history to CSV."""
    query = get_mass_report_history_query(
        db, officer_id, social_media, date_from, date_to, global_search
    )
    results = query.all()

    output = io.StringIO()
    writer = csv.writer(output, quoting=csv.QUOTE_ALL)
    
    writer.writerow([
        'Log ID', 'Result ID', 'Officer Name', 'Original Search Query', 
        'Reported Platform', 'Reported Target Username', 'Result Status', 
        'System Message', 'Report Date'
    ])

    for log, search_query, first_name, last_name in results:
        status = "Success" if "Successfully" in log.reporting_results else "Failed"
        writer.writerow([
            log.id, log.result_log_id, f"{first_name} {last_name}", search_query,
            log.social_media, log.username, status, log.reporting_results,
            log.reported_at.strftime('%Y-%m-%d %H:%M:%S')
        ])

    output.seek(0)
    content = output.getvalue().encode("utf-8-sig")
    
    return StreamingResponse(
        iter([content]),
        media_type="text/csv",
        headers={
            "Content-Disposition": f"attachment; filename=mass_reports_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        }
    )


@router.get("/export/pdf")
def export_mass_report_pdf(
    officer_id: Optional[int] = Query(None),
    social_media: Optional[str] = Query(None),
    date_from: Optional[date] = Query(None),
    date_to: Optional[date] = Query(None),
    global_search: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """Export mass reporting history to PDF."""
    query = get_mass_report_history_query(
        db, officer_id, social_media, date_from, date_to, global_search
    )
    results = query.all()

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=landscape(letter),
        leftMargin=0.4*inch, rightMargin=0.4*inch,
        topMargin=0.5*inch, bottomMargin=0.5*inch,
    )

    styles = getSampleStyleSheet()
    elements = []

    # Title
    title_style = styles["Title"]
    title_style.textColor = colors.HexColor("#0f172a")
    title_style.alignment = 1
    title_style.fontSize = 20
    title_style.spaceAfter = 14
    elements.append(Paragraph("<b>CYBERSPY — MASS REPORTING HISTORY</b>", title_style))
    elements.append(Spacer(1, 0.1*inch))
    
    # Meta
    meta_style = styles["Normal"]
    meta_style.fontSize = 8.5
    meta_style.textColor = colors.HexColor("#64748b")
    elements.append(Paragraph(
        f"<b>Generated:</b> {datetime.now().strftime('%d %b %Y, %H:%M:%S')}  |  <b>Total records:</b> {len(results)}",
        meta_style
    ))
    elements.append(Spacer(1, 0.2*inch))

    # Table
    headers = [
        Paragraph("<b>ID</b>", styles["Normal"]),
        Paragraph("<b>Officer</b>", styles["Normal"]),
        Paragraph("<b>Orig. Query</b>", styles["Normal"]),
        Paragraph("<b>Platform</b>", styles["Normal"]),
        Paragraph("<b>Target @</b>", styles["Normal"]),
        Paragraph("<b>Status</b>", styles["Normal"]),
        Paragraph("<b>Message</b>", styles["Normal"]),
        Paragraph("<b>Date</b>", styles["Normal"]),
    ]
    table_data = [headers]

    for log, search_query, first_name, last_name in results:
        status = "Success" if "Successfully" in log.reporting_results else "Failed"
        table_data.append([
            Paragraph(str(log.id), styles["Normal"]),
            Paragraph(f"{first_name} {last_name}", styles["Normal"]),
            Paragraph(str(search_query), styles["Normal"]),
            Paragraph(str(log.social_media).title(), styles["Normal"]),
            Paragraph(str(log.username), styles["Normal"]),
            Paragraph(status, styles["Normal"]),
            Paragraph(str(log.reporting_results), styles["Normal"]),
            Paragraph(log.reported_at.strftime("%Y-%m-%d"), styles["Normal"]),
        ])

    col_widths = [0.5*inch, 1.2*inch, 1.2*inch, 0.8*inch, 1.2*inch, 0.8*inch, 3.5*inch, 0.8*inch]
    
    table = Table(table_data, colWidths=col_widths, repeatRows=1)
    ts = TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0f172a")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, 0), 8.5),
        ("BOTTOMPADDING", (0, 0), (-1, 0), 6),
        ("TOPPADDING", (0, 0), (-1, 0), 6),
        ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
        ("FONTSIZE", (0, 1), (-1, -1), 7),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("INNERGRID", (0, 1), (-1, -1), 0.25, colors.HexColor("#e2e8f0")),
        ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#cbd5e1")),
    ])
    
    for i in range(1, len(table_data)):
        ts.add("BACKGROUND", (0, i), (-1, i), colors.HexColor("#f8fafc") if i % 2 == 0 else colors.white)

    table.setStyle(ts)
    elements.append(table)

    doc.build(elements)
    buffer.seek(0)

    return StreamingResponse(
        iter([buffer.getvalue()]),
        media_type="application/pdf",
        headers={
            "Content-Disposition": f"attachment; filename=mass_reports_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
        }
    )
