from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.schemas.city import CityCreate, CityRead, CityUpdate
from app.services import city_service

router = APIRouter()


@router.get("/", response_model=list[CityRead])
def list_cities(is_active: bool | None = Query(None), db: Session = Depends(get_db)):
    return city_service.list_cities(db, is_active=is_active)


@router.post("/", response_model=CityRead, status_code=201)
def create_city(city_in: CityCreate, db: Session = Depends(get_db)):
    return city_service.create_city(db, city_in)


@router.patch("/{city_id}", response_model=CityRead)
def update_city(city_id: int, city_in: CityUpdate, db: Session = Depends(get_db)):
    city = city_service.update_city(db, city_id, city_in)
    if not city:
        raise HTTPException(status_code=404, detail="City not found")
    return city


@router.delete("/{city_id}", status_code=204)
def delete_city(city_id: int, db: Session = Depends(get_db)):
    try:
        success = city_service.delete_city(db, city_id)
        if not success:
            raise HTTPException(status_code=404, detail="City not found")
        return None
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
