from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.schemas.branch import BranchCreate, BranchRead, BranchUpdate
from app.services import branch_service

router = APIRouter()


@router.get("/", response_model=list[BranchRead])
def list_branches(is_active: bool | None = Query(None), city_id: int | None = Query(None), db: Session = Depends(get_db)):
    return branch_service.list_branches(db, is_active=is_active, city_id=city_id)


@router.post("/", response_model=BranchRead, status_code=201)
def create_branch(branch_in: BranchCreate, db: Session = Depends(get_db)):
    return branch_service.create_branch(db, branch_in)


@router.patch("/{branch_id}", response_model=BranchRead)
def update_branch(branch_id: int, branch_in: BranchUpdate, db: Session = Depends(get_db)):
    branch = branch_service.update_branch(db, branch_id, branch_in)
    if not branch:
        raise HTTPException(status_code=404, detail="Branch not found")
    return branch


@router.delete("/{branch_id}", status_code=204)
def delete_branch(branch_id: int, db: Session = Depends(get_db)):
    try:
        success = branch_service.delete_branch(db, branch_id)
        if not success:
            raise HTTPException(status_code=404, detail="Branch not found")
        return None
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
