from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
import jwt
import os

from app.db.session import get_db
from app.schemas.officer import OfficerCreate, OfficerRead, OfficerUpdate, OfficerLogin, OfficerLoginResponse
from app.services import officer_login_service, officer_service
from app.schemas.officer_login_log import OfficerLoginLogCreate, OfficerLoginLogRead
from app.schemas.officer import OfficerInfo

router = APIRouter()


@router.get("/", response_model=list[OfficerRead])
def list_officers(
    is_active: bool | None = Query(None), 
    branch_id: int | None = Query(None), 
    city_id: int | None = Query(None),
    gender: str | None = Query(None),
    min_age: int | None = Query(None),
    max_age: int | None = Query(None),
    db: Session = Depends(get_db)
):
    return officer_service.get_officers(db, is_active=is_active, branch_id=branch_id, city_id=city_id, gender=gender, min_age=min_age, max_age=max_age)


@router.get("/reports/login-logs", response_model=list[OfficerLoginLogRead])
def get_all_login_logs(db: Session = Depends(get_db)):
    from app.models.officer_login_log import OfficerLoginLog
    return db.query(OfficerLoginLog).order_by(OfficerLoginLog.loggedin_at.desc()).all()


@router.get("/{officer_id}", response_model=OfficerRead)
def get_officer(officer_id: int, db: Session = Depends(get_db)):
    officer = officer_service.get_officer(db, officer_id)
    if not officer:
        raise HTTPException(status_code=404, detail="Officer not found")
    return officer


@router.post("/", response_model=OfficerRead, status_code=201)
def create_officer(officer_in: OfficerCreate, db: Session = Depends(get_db)):
    return officer_service.create_officer(db, officer_in)


@router.delete("/{officer_id}", status_code=204)
def delete_officer(officer_id: int, db: Session = Depends(get_db)):
    try:
        success = officer_service.delete_officer(db, officer_id)
        if not success:
            raise HTTPException(status_code=404, detail="Officer not found")
        return None
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.patch("/{officer_id}", response_model=OfficerLoginResponse)
def update_officer(officer_id: int, officer_in: OfficerUpdate, db: Session = Depends(get_db)):
    officer = officer_service.update_officer(db, officer_id, officer_in)

    secret_key = os.getenv("SECRET_KEY", "your-secret-key-change-in-production")
    algorithm = "HS256"
    
    token_data = {
        "sub": str(officer.id),
        "email": officer.email,
        "exp": datetime.utcnow() + timedelta(days=7)
    }
    
    access_token = jwt.encode(token_data, secret_key, algorithm=algorithm)

    officer_info = OfficerInfo(
        id=officer.id,
        email=officer.email,
        first_name=officer.first_name,
        last_name=officer.last_name,
        branch_id=officer.branch_id,
        is_active=officer.is_active,
        gender=officer.gender,
        dob=officer.dob,
        phone_no=officer.phone_no,
        created_at=officer.created_at,
        modified_at=officer.modified_at
    )

    
    if not officer:
        raise HTTPException(status_code=404, detail="Officer not found")
    
    return OfficerLoginResponse(
        access_token=access_token,
        token_type="bearer",
        officer=officer_info
    )


@router.post("/{officer_id}/login-log", response_model=OfficerLoginLogRead, status_code=201)
def log_officer_login(officer_id: int, login_in: OfficerLoginLogCreate, db: Session = Depends(get_db)):
    if login_in.officer_id != officer_id:
        raise HTTPException(status_code=400, detail="Officer id mismatch")
    return officer_login_service.create_login_log(db, login_in)


@router.get("/{officer_id}/login-log", response_model=list[OfficerLoginLogRead])
def list_login_logs(officer_id: int, db: Session = Depends(get_db)):
    return officer_login_service.list_login_logs(db, officer_id=officer_id)


@router.post("/login", response_model=OfficerLoginResponse)
def login_officer(login_in: OfficerLogin, db: Session = Depends(get_db)):

    officer = officer_login_service.login_officer(db, login_in)
    
    secret_key = os.getenv("SECRET_KEY", "your-secret-key-change-in-production")
    algorithm = "HS256"
    
    token_data = {
        "sub": str(officer.id),
        "email": officer.email,
        "exp": datetime.utcnow() + timedelta(days=7)
    }
    
    access_token = jwt.encode(token_data, secret_key, algorithm=algorithm)
        
    officer_info = OfficerInfo(
        id=officer.id,
        email=officer.email,
        first_name=officer.first_name,
        last_name=officer.last_name,
        branch_id=officer.branch_id,
        is_active=officer.is_active,
        gender=officer.gender,
        dob=officer.dob,
        phone_no=officer.phone_no,
        created_at=officer.created_at,
        modified_at=officer.modified_at
    )
    
    return OfficerLoginResponse(
        access_token=access_token,
        token_type="bearer",
        officer=officer_info
    )