"""
Chatbot API Routes with RAG and Guardrails
"""
import logging
from typing import Optional, List, Dict
from fastapi import APIRouter, HTTPException, Depends, Request
from pydantic import BaseModel, Field
from datetime import datetime

from app.services.rag_service import query_rag, initialize_rag
from app.services.guardrails import (
    check_rate_limit,
    record_request,
    validate_message,
    sanitize_input,
    check_content_safety,
    filter_response,
    get_user_context
)

logger = logging.getLogger(__name__)

router = APIRouter()

# Initialize RAG on module load
rag_initialized = False

try:
    rag_initialized = initialize_rag()
    if rag_initialized:
        logger.info("✅ Chatbot RAG service initialized successfully")
    else:
        logger.warning("⚠️ Chatbot RAG service initialization failed")
except Exception as e:
    logger.error(f"❌ Error initializing RAG: {str(e)}")


class ChatMessage(BaseModel):
    message: str = Field(..., min_length=1, max_length=2000, description="User's message/question")
    conversation_id: Optional[str] = Field(None, description="Optional conversation ID for context")
    user_id: Optional[str] = Field(None, description="Optional user ID for rate limiting")
    user_type: Optional[str] = Field("officer", description="User type: 'admin' or 'officer'")


class ChatResponse(BaseModel):
    answer: str = Field(..., description="AI's response")
    sources: List[str] = Field(default_factory=list, description="Source documents used")
    conversation_id: Optional[str] = Field(None, description="Conversation ID")
    timestamp: str = Field(..., description="Response timestamp")
    warnings: List[str] = Field(default_factory=list, description="Any warnings")


class ConversationHistory(BaseModel):
    conversation_id: str
    messages: List[Dict] = Field(default_factory=list)


# In-memory conversation storage (use Redis/DB in production)
conversations: Dict[str, List[Dict]] = {}


def get_client_ip(request: Request) -> str:
    """Extract client IP address"""
    if request.client:
        return request.client.host
    return "unknown"


@router.post("/chat", response_model=ChatResponse)
async def chat(
    chat_message: ChatMessage,
    request: Request
):
    """
    Chat with the AI assistant using RAG
    
    - **message**: Your question or message
    - **conversation_id**: Optional ID to maintain conversation context
    - **user_id**: Optional user ID for rate limiting
    """
    try:
        # Get client IP
        client_ip = get_client_ip(request)
        user_id = chat_message.user_id or client_ip
        
        # Rate limiting check
        rate_limit_check = check_rate_limit(user_id=user_id, ip_address=client_ip)
        if not rate_limit_check["allowed"]:
            raise HTTPException(
                status_code=429,
                detail={
                    "error": rate_limit_check["reason"],
                    "message": rate_limit_check["message"]
                }
            )
        
        # Sanitize input
        sanitized_message = sanitize_input(chat_message.message)
        
        # Validate message
        validation = validate_message(sanitized_message)
        if not validation["valid"]:
            raise HTTPException(
                status_code=400,
                detail={
                    "error": validation["reason"],
                    "message": validation["message"]
                }
            )
        
        # Record request
        record_request(user_id=user_id, ip_address=client_ip)
        
        # Get conversation history if conversation_id provided
        conversation_history = None
        if chat_message.conversation_id:
            conversation_history = conversations.get(chat_message.conversation_id, [])
        
        # Query RAG with user type
        logger.info(f"💬 Chat query from {user_id} (type: {chat_message.user_type}): {sanitized_message[:100]}...")
        rag_result = await query_rag(sanitized_message, conversation_history, user_type=chat_message.user_type)
        
        if rag_result.get("error"):
            logger.error(f"RAG error: {rag_result['error']}")
            # Graceful fallback: respond with user-friendly message instead of raising
            filtered_answer = "AI assistant is currently unavailable. Please try again later or consult the user guide."
            sources = []
            warnings = ["AI_UNAVAILABLE"]

            # Update conversation history with fallback
            conversation_id = chat_message.conversation_id or f"conv_{datetime.now().timestamp()}"
            if conversation_id not in conversations:
                conversations[conversation_id] = []
            conversations[conversation_id].append({
                "question": sanitized_message,
                "answer": filtered_answer,
                "timestamp": datetime.now().isoformat()
            })
            conversations[conversation_id] = conversations[conversation_id][-10:]

            response = ChatResponse(
                answer=filtered_answer,
                sources=sources,
                conversation_id=conversation_id,
                timestamp=datetime.now().isoformat(),
                warnings=warnings
            )

            logger.info(f"✅ Chat fallback response generated for {user_id}")
            return response
        
        # Check content safety
        safety_check = check_content_safety(rag_result["answer"]) 
        if not safety_check["safe"]:
            logger.warning(f"Unsafe content detected in response")
            rag_result["answer"] = "I apologize, but I cannot provide that information. Please ask about the Activity Monitoring System or its features."
        
        # Filter response
        filtered_answer = filter_response(rag_result["answer"])
        
        # Update conversation history
        conversation_id = chat_message.conversation_id or f"conv_{datetime.now().timestamp()}"
        if conversation_id not in conversations:
            conversations[conversation_id] = []
        
        conversations[conversation_id].append({
            "question": sanitized_message,
            "answer": filtered_answer,
            "timestamp": datetime.now().isoformat()
        })
        
        # Keep only last 10 messages in history
        conversations[conversation_id] = conversations[conversation_id][-10:]
        
        # Build response
        response = ChatResponse(
            answer=filtered_answer,
            sources=rag_result.get("sources", []),
            conversation_id=conversation_id,
            timestamp=datetime.now().isoformat(),
            warnings=validation.get("warnings", [])
        )
        
        logger.info(f"✅ Chat response generated for {user_id}")
        return response
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error in chat endpoint: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail={
                "error": "INTERNAL_ERROR",
                "message": "An error occurred while processing your request."
            }
        )


@router.get("/chat/health")
async def chat_health():
    """Check chatbot service health"""
    return {
        "status": "healthy" if rag_initialized else "unhealthy",
        "rag_initialized": rag_initialized,
        "service": "chatbot"
    }


@router.get("/chat/conversation/{conversation_id}")
async def get_conversation(conversation_id: str):
    """Get conversation history"""
    if conversation_id not in conversations:
        raise HTTPException(status_code=404, detail="Conversation not found")
    
    return {
        "conversation_id": conversation_id,
        "messages": conversations[conversation_id],
        "message_count": len(conversations[conversation_id])
    }


@router.delete("/chat/conversation/{conversation_id}")
async def delete_conversation(conversation_id: str):
    """Delete a conversation"""
    if conversation_id in conversations:
        del conversations[conversation_id]
        return {"message": "Conversation deleted", "conversation_id": conversation_id}
    else:
        raise HTTPException(status_code=404, detail="Conversation not found")


