from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, func
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime, date
import json
from pathlib import Path

from app.db.session import get_db
from app.schemas.result_log import ResultLogCreate, ResultLogRead
from app.services import result_log_service
from app.models.result_log import ResultLog
from app.models.search_type import SearchType
from app.models.officer import Officer

router = APIRouter()


# Response Models
class FilteredResultLog(BaseModel):
    id: int
    officer_id: int
    officer_name: str
    search_type: str
    search_query: str
    searched_at: datetime
    result_file_path: str
    
    class Config:
        from_attributes = True


class PaginatedResults(BaseModel):
    total: int
    page: int
    page_size: int
    total_pages: int
    results: List[FilteredResultLog]


class SearchResultDetail(BaseModel):
    log_id: int
    officer_id: int
    officer_name: str
    search_type: str
    search_query: str
    searched_at: datetime
    result_data: dict


@router.get("/", response_model=list[ResultLogRead])
def list_result_logs(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    return result_log_service.list_result_logs(db, skip=skip, limit=limit)


@router.post("/", response_model=ResultLogRead, status_code=201)
def create_result_log(log_in: ResultLogCreate, db: Session = Depends(get_db)):
    return result_log_service.create_result_log(db, log_in)


@router.get("/filter", response_model=PaginatedResults)
def filter_result_logs(
    officer_id: Optional[int] = Query(None, description="Filter by officer ID"),
    search_type: Optional[str] = Query(None, description="Filter by search type (e.g., 'multi-platform', 'single-platform')"),
    search_query: Optional[str] = Query(None, description="Filter by search query (partial match)"),
    date_from: Optional[date] = Query(None, description="Filter results from this date (YYYY-MM-DD)"),
    date_to: Optional[date] = Query(None, description="Filter results until this date (YYYY-MM-DD)"),
    page: int = Query(1, ge=1, description="Page number"),
    page_size: int = Query(20, ge=1, le=100, description="Results per page"),
    sort_by: str = Query("searched_at", description="Sort by field (searched_at, search_query)"),
    sort_order: str = Query("desc", description="Sort order (asc, desc)"),
    db: Session = Depends(get_db)
):
    """
    Advanced filtering for search result logs with pagination
    
    Filters:
    - officer_id: Filter by specific officer
    - search_type: Filter by search type
    - search_query: Partial text search in queries
    - date_from/date_to: Date range filter
    - Pagination with page and page_size
    - Sorting options
    """
    
    # Build base query with joins
    query = db.query(
        ResultLog.id,
        ResultLog.officer_id,
        ResultLog.search_type_id,
        ResultLog.search_query,
        ResultLog.searched_at,
        ResultLog.result_file_path,
        SearchType.search_type,
        Officer.first_name,
        Officer.last_name
    ).join(
        SearchType, ResultLog.search_type_id == SearchType.id
    ).join(
        Officer, ResultLog.officer_id == Officer.id
    )
    
    # Apply filters
    filters = []
    
    if officer_id is not None:
        filters.append(ResultLog.officer_id == officer_id)
    
    if search_type:
        filters.append(SearchType.search_type.ilike(f"%{search_type}%"))
    
    if search_query:
        filters.append(ResultLog.search_query.ilike(f"%{search_query}%"))
    
    if date_from:
        filters.append(func.date(ResultLog.searched_at) >= date_from)
    
    if date_to:
        filters.append(func.date(ResultLog.searched_at) <= date_to)
    
    if filters:
        query = query.filter(and_(*filters))
    
    # Get total count
    total = query.count()
    
    # Apply sorting
    if sort_order.lower() == "desc":
        if sort_by == "searched_at":
            query = query.order_by(ResultLog.searched_at.desc())
        elif sort_by == "search_query":
            query = query.order_by(ResultLog.search_query.desc())
        else:
            query = query.order_by(ResultLog.searched_at.desc())
    else:
        if sort_by == "searched_at":
            query = query.order_by(ResultLog.searched_at.asc())
        elif sort_by == "search_query":
            query = query.order_by(ResultLog.search_query.asc())
        else:
            query = query.order_by(ResultLog.searched_at.asc())
    
    # Apply pagination
    offset = (page - 1) * page_size
    query = query.offset(offset).limit(page_size)
    
    # Execute query
    results = query.all()
    
    # Format results
    filtered_results = [
        FilteredResultLog(
            id=r.id,
            officer_id=r.officer_id,
            officer_name=f"{r.first_name} {r.last_name}",
            search_type=r.search_type,
            search_query=r.search_query,
            searched_at=r.searched_at,
            result_file_path=r.result_file_path
        )
        for r in results
    ]
    
    # Calculate total pages
    total_pages = (total + page_size - 1) // page_size
    
    return PaginatedResults(
        total=total,
        page=page,
        page_size=page_size,
        total_pages=total_pages,
        results=filtered_results
    )


@router.get("/{log_id}/details", response_model=SearchResultDetail)
def get_result_log_details(log_id: int, db: Session = Depends(get_db)):
    """
    Get detailed information about a specific search result log,
    including the actual search result data from the JSON file
    """
    
    # Query the log with joins
    result = db.query(
        ResultLog.id,
        ResultLog.officer_id,
        ResultLog.search_type_id,
        ResultLog.search_query,
        ResultLog.searched_at,
        ResultLog.result_file_path,
        SearchType.search_type,
        Officer.first_name,
        Officer.last_name
    ).join(
        SearchType, ResultLog.search_type_id == SearchType.id
    ).join(
        Officer, ResultLog.officer_id == Officer.id
    ).filter(
        ResultLog.id == log_id
    ).first()
    
    if not result:
        raise HTTPException(status_code=404, detail="Result log not found")
    
    # Read the result data from JSON file
    result_data = {}
    try:
        file_path = Path(result.result_file_path)
        if file_path.exists():
            with open(file_path, 'r', encoding='utf-8') as f:
                result_data = json.load(f)
        else:
            result_data = {"error": "Result file not found"}
    except Exception as e:
        result_data = {"error": f"Error reading result file: {str(e)}"}
    
    return SearchResultDetail(
        log_id=result.id,
        officer_id=result.officer_id,
        officer_name=f"{result.first_name} {result.last_name}",
        search_type=result.search_type,
        search_query=result.search_query,
        searched_at=result.searched_at,
        result_data=result_data
    )


@router.get("/search-types/list", response_model=List[str])
def get_available_search_types(db: Session = Depends(get_db)):
    """
    Get list of all available search types for filtering
    """
    search_types = db.query(SearchType.search_type).filter(
        SearchType.is_active == True
    ).distinct().all()
    
    return [st.search_type for st in search_types]


@router.get("/statistics", response_model=dict)
def get_result_logs_statistics(
    officer_id: Optional[int] = Query(None, description="Filter by officer ID"),
    date_from: Optional[date] = Query(None, description="Statistics from this date"),
    date_to: Optional[date] = Query(None, description="Statistics until this date"),
    db: Session = Depends(get_db)
):
    """
    Get statistics about search result logs
    """
    
    # Build base query
    query = db.query(ResultLog)
    
    # Apply filters
    filters = []
    if officer_id is not None:
        filters.append(ResultLog.officer_id == officer_id)
    if date_from:
        filters.append(func.date(ResultLog.searched_at) >= date_from)
    if date_to:
        filters.append(func.date(ResultLog.searched_at) <= date_to)
    
    if filters:
        query = query.filter(and_(*filters))
    
    # Get total count
    total_searches = query.count()
    
    # Get search type breakdown
    search_type_stats = db.query(
        SearchType.search_type,
        func.count(ResultLog.id).label('count')
    ).join(
        ResultLog, SearchType.id == ResultLog.search_type_id
    )
    
    if filters:
        search_type_stats = search_type_stats.filter(and_(*filters))
    
    search_type_stats = search_type_stats.group_by(SearchType.search_type).all()
    
    # Get top searchers (if not filtered by officer)
    top_searchers = []
    if officer_id is None:
        top_searchers_query = db.query(
            Officer.id,
            Officer.first_name,
            Officer.last_name,
            func.count(ResultLog.id).label('search_count')
        ).join(
            ResultLog, Officer.id == ResultLog.officer_id
        )
        
        if date_from:
            top_searchers_query = top_searchers_query.filter(
                func.date(ResultLog.searched_at) >= date_from
            )
        if date_to:
            top_searchers_query = top_searchers_query.filter(
                func.date(ResultLog.searched_at) <= date_to
            )
        
        top_searchers_query = top_searchers_query.group_by(
            Officer.id, Officer.first_name, Officer.last_name
        ).order_by(
            func.count(ResultLog.id).desc()
        ).limit(5)
        
        top_searchers_results = top_searchers_query.all()
        top_searchers = [
            {
                "officer_id": r.id,
                "officer_name": f"{r.first_name} {r.last_name}",
                "search_count": r.search_count
            }
            for r in top_searchers_results
        ]
    
    return {
        "total_searches": total_searches,
        "search_type_breakdown": [
            {"search_type": st.search_type, "count": st.count}
            for st in search_type_stats
        ],
        "top_searchers": top_searchers,
        "date_range": {
            "from": date_from.isoformat() if date_from else None,
            "to": date_to.isoformat() if date_to else None
        }
    }
