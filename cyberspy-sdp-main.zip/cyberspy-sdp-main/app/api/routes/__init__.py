from fastapi import APIRouter

from app.api.routes import admin, branches, cities, dashboard, officers, reports, result_logs, search, search_types, system, mass_report, chatbot

api_router = APIRouter()
api_router.include_router(system.router, tags=["system"])
api_router.include_router(cities.router, prefix="/cities", tags=["cities"])
api_router.include_router(branches.router, prefix="/branches", tags=["branches"])
api_router.include_router(officers.router, prefix="/officers", tags=["officers"])
api_router.include_router(dashboard.router, prefix="/dashboard", tags=["dashboard"])
api_router.include_router(search_types.router, prefix="/search-types", tags=["search_types"])
api_router.include_router(result_logs.router, prefix="/result-logs", tags=["result_logs"])
api_router.include_router(reports.router, prefix="/reports", tags=["reports"])
api_router.include_router(mass_report.router, prefix="/mass-report", tags=["mass_report"])
api_router.include_router(admin.router, prefix="/admin", tags=["admin"])
api_router.include_router(search.router, prefix="/search", tags=["search"])
api_router.include_router(chatbot.router, prefix="/chatbot", tags=["chatbot"])

