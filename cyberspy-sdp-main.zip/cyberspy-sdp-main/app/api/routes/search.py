from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import List, Optional, Dict
from datetime import datetime, timedelta
import instaloader
import logging
import time
import random
import uuid
import json
import os
from pathlib import Path

from app.db.session import get_db
from app.services.gemini_analyzer import analyze_profile_for_cybercrime, generate_profile_summary
from app.services.platform_search import (
    search_all_platforms_username,
    search_all_platforms_keyword,
    search_facebook_username,
    search_reddit_username,
    search_telegram_username
)
from app.services.result_log_service import (
    create_result_log,
    get_recent_searches_by_officer,
    get_result_log_by_id
)
from app.schemas.result_log import ResultLogCreate, ResultLogRead

router = APIRouter()
logger = logging.getLogger(__name__)

# User agents for rotation
USER_AGENTS = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15',
]

# Initialize Instaloader with session management
L = None
last_session_reset = None
request_count = 0
MAX_REQUESTS_PER_SESSION = 3  # Reduced from 5 to 3 for better rate limit avoidance
IS_PRODUCTION = os.getenv("RENDER") or os.getenv("VERCEL")  # Detect if running on cloud

def get_random_user_agent():
    """Get a random user agent"""
    return random.choice(USER_AGENTS)

def get_instaloader():
    """Get or create Instaloader instance with session management and anti-rate-limit features"""
    global L, last_session_reset, request_count
    
    # More aggressive session rotation in production
    session_timeout = 180 if IS_PRODUCTION else 300  # 3 min in prod, 5 min locally
    
    # Create new instance if:
    # 1. None exists
    # 2. Session is older than timeout
    # 3. Too many requests on current session
    should_reset = (
        L is None or
        (last_session_reset and (datetime.now() - last_session_reset).seconds > session_timeout) or
        request_count >= MAX_REQUESTS_PER_SESSION
    )
    
    if should_reset:
        logger.info(f"Creating new Instaloader session (requests: {request_count}, production: {IS_PRODUCTION})")
        
        # Generate unique session identifier
        session_id = str(uuid.uuid4())[:8]
        
        # Create new instance with anti-detection settings
        L = instaloader.Instaloader(
            download_pictures=False,
            download_videos=False,
            download_video_thumbnails=False,
            download_geotags=False,
            download_comments=False,
            save_metadata=False,
            compress_json=False,
            max_connection_attempts=1,  # Reduced from 2 to 1
            request_timeout=15,  # Increased from 10 to 15
            user_agent=get_random_user_agent(),  # Random user agent
            sleep=True,  # Enable sleep between requests
            quiet=True,
            filename_pattern=session_id  # Unique session pattern
        )
        
        # Clear any existing cookies/session data
        L.context._session.cookies.clear()
        
        # Try to login if credentials are provided (helps with rate limits)
        instagram_username = "site_smithing"
        instagram_password = "MyNameIsAadil@1106"
        
        if instagram_username and instagram_password:
            try:
                logger.info(f"🔐 Attempting Instagram login as {instagram_username}")
                L.login(instagram_username, instagram_password)
                logger.info("✅ Instagram login successful - higher rate limits available")
            except Exception as e:
                logger.warning(f"⚠️ Instagram login failed: {str(e)}")
                logger.warning("Continuing without authentication (higher rate limit risk)")
        else:
            logger.info("ℹ️ No Instagram credentials provided - using anonymous access")
            logger.info("   Add INSTAGRAM_USERNAME and INSTAGRAM_PASSWORD env vars for better rate limits")
        
        # Reset counters
        last_session_reset = datetime.now()
        request_count = 0
        
        logger.info(f"New session created with ID: {session_id}")

    
    # Increment request counter
    request_count += 1
    
    # Add longer random delay in production (1-4 seconds vs 0.5-2 seconds locally)
    if request_count > 1:
        if IS_PRODUCTION:
            delay = random.uniform(2.0, 5.0)  # Longer delays in production
        else:
            delay = random.uniform(0.5, 2.0)
        logger.debug(f"Random delay: {delay:.2f}s")
        time.sleep(delay)
    
    return L

def reset_instaloader_session():
    """Force reset Instaloader session on rate limit"""
    global L, last_session_reset, request_count
    
    logger.warning("Force resetting Instaloader session due to rate limit")
    
    # Clear session completely
    if L:
        try:
            L.context._session.cookies.clear()
            L.context._session.close()
        except:
            pass
    
    L = None
    last_session_reset = None
    request_count = 0
    
    # Longer wait in production before creating new session
    if IS_PRODUCTION:
        wait_time = random.uniform(5, 10)  # 5-10 seconds in production
    else:
        wait_time = random.uniform(2, 4)  # 2-4 seconds locally
    
    logger.info(f"Waiting {wait_time:.2f}s before new session...")
    time.sleep(wait_time)
    
    return get_instaloader()


# Request/Response Models
class SearchRequest(BaseModel):
    keyword: str
    platforms: List[str]
    officer_id: Optional[int] = 0  # Default to 0 for admin


class SinglePlatformSearchRequest(BaseModel):
    username: str   
    platform: str
    officer_id: Optional[int] = 0  # Default to 0 for admin


class TrackingRequest(BaseModel):
    username: str
    platform: str
    duration_value: int
    duration_unit: str
    frequency: str
    officer_id: Optional[int] = 0  # Default to 0 for admin


class InstagramProfileStats(BaseModel):
    username: str
    full_name: Optional[str] = None
    biography: Optional[str] = None
    followers: int = 0
    following: int = 0
    posts_count: int = 0
    is_private: bool = False
    is_verified: bool = False
    profile_pic_url: Optional[str] = None
    external_url: Optional[str] = None
    is_business_account: bool = False
    business_category: Optional[str] = None


class InstagramPost(BaseModel):
    post_url: str
    caption: Optional[str] = None
    likes: int = 0
    comments: int = 0
    date: str
    is_video: bool = False
    video_views: Optional[int] = None


class InstagramSearchResult(BaseModel):
    profile: Optional[InstagramProfileStats] = None
    recent_posts: List[InstagramPost] = []
    engagement_rate: float = 0.0
    avg_likes: int = 0
    avg_comments: int = 0
    found: bool = True
    error: Optional[str] = None
    
    # AI Analysis fields
    cybercrime_analysis: Optional[Dict] = None
    ai_summary: Optional[str] = None


class HashtagSearchResult(BaseModel):
    keyword: str
    total_posts_found: int
    profiles: List[InstagramProfileStats] = []
    top_posts: List[InstagramPost] = []


class PlatformResult(BaseModel):
    platform: str
    username: str
    found: bool
    profile_url: Optional[str] = None
    last_activity: Optional[str] = None
    error: Optional[str] = None
    instagram_data: Optional[InstagramSearchResult] = None


class TrackingResponse(BaseModel):
    tracking_id: str
    username: str
    platform: str
    duration: str
    frequency: str
    start_time: str
    end_time: str
    status: str




# Helper function to get Instagram profile data
async def get_instagram_profile(username: str) -> InstagramSearchResult:
    """
    Fetch Instagram profile data using Instaloader with rate limit handling
    """
    # Reduce retries in production to avoid hammering Instagram
    max_retries = 1 if IS_PRODUCTION else 2
    retry_count = 0
    
    while retry_count <= max_retries:
        try:
            logger.info(f"Fetching Instagram profile for: {username} (attempt {retry_count + 1}/{max_retries + 1})")
            
            # Get Instaloader instance
            loader = get_instaloader()
            
            # Get profile
            profile = instaloader.Profile.from_username(loader.context, username)
            
            # Get profile stats
            profile_stats = InstagramProfileStats(
                username=profile.username,
                full_name=profile.full_name,
                biography=profile.biography,
                followers=profile.followers,
                following=profile.followees,
                posts_count=profile.mediacount,
                is_private=profile.is_private,
                is_verified=profile.is_verified,
                profile_pic_url=profile.profile_pic_url,
                external_url=profile.external_url,
                is_business_account=profile.is_business_account,
                business_category=profile.business_category_name if profile.is_business_account else None
            )
            
            # Get recent posts (limit to fewer posts in production to reduce API calls)
            post_limit = 6 if IS_PRODUCTION else 12  # Reduced from 12 to 6 in production
            recent_posts = []
            total_likes = 0
            total_comments = 0
            post_count = 0
            
            if not profile.is_private:
                try:
                    for post in profile.get_posts():
                        if post_count >= post_limit:  # Limit recent posts
                            break
                        
                        post_data = InstagramPost(
                            post_url=f"https://www.instagram.com/p/{post.shortcode}/",
                            caption=post.caption if post.caption else None,
                            likes=post.likes,
                            comments=post.comments,
                            date=post.date_utc.isoformat(),
                            is_video=post.is_video,
                            video_views=post.video_view_count if post.is_video else None
                        )
                        recent_posts.append(post_data)
                        total_likes += post.likes
                        total_comments += post.comments
                        post_count += 1
                        
                except Exception as e:
                    logger.warning(f"Error fetching posts: {str(e)}")
            
            logger.info(f"Recent posts fetched: {len(recent_posts)}")
            
            # Calculate engagement rate
            engagement_rate = 0.0
            avg_likes = 0
            avg_comments = 0
            
            if post_count > 0 and profile.followers > 0:
                avg_likes = total_likes / post_count
                avg_comments = total_comments / post_count
                engagement_rate = ((total_likes + total_comments) / post_count / profile.followers) * 100
                engagement_rate = round(engagement_rate, 2)
            
            logger.info(f"Profile found! Followers: {profile.followers}, Posts: {profile.mediacount}")
            
            # ========================================
            # GEMINI AI ANALYSIS
            # ========================================
            cybercrime_analysis = None
            ai_summary = None
            
            try:
                logger.info(f"Starting AI analysis for @{username}")
                
                # Analyze for cybercrime
                cybercrime_analysis = await analyze_profile_for_cybercrime(
                    username=username,
                    platform="instagram",
                    bio=profile.biography,
                    posts=[{
                        "caption": p.caption,
                        "likes": p.likes,
                        "comments": p.comments,
                        "date": p.date
                    } for p in recent_posts],
                    profile_data={
                        "is_business_account": profile.is_business_account,
                        "is_verified": profile.is_verified,
                        "is_private": profile.is_private,
                        "external_url": profile.external_url,
                        "followers": profile.followers,
                        "following": profile.followees,
                        "posts_count": profile.mediacount
                    }
                )
                
                logger.info(f"Cybercrime analysis complete: Risk level {cybercrime_analysis.get('risk_level')}")
                
                # Generate AI summary
                ai_summary = await generate_profile_summary(
                    username=username,
                    platform="instagram",
                    profile_data={
                        "followers": profile.followers,
                        "following": profile.followees,
                        "posts_count": profile.mediacount,
                        "biography": profile.biography,
                        "is_verified": profile.is_verified,
                        "is_private": profile.is_private,
                        "full_name": profile.full_name
                    },
                    posts=[{
                        "caption": p.caption,
                        "likes": p.likes,
                        "comments": p.comments
                    } for p in recent_posts],
                    engagement_data={
                        "engagement_rate": engagement_rate,
                        "avg_likes": int(avg_likes),
                        "avg_comments": int(avg_comments)
                    }
                )
                
                logger.info(f"AI summary generated successfully")
                
            except Exception as e:
                logger.error(f"AI analysis error: {str(e)}")
                # Continue without AI analysis if it fails
                cybercrime_analysis = {
                    "risk_level": "unknown",
                    "risk_score": 0,
                    "indicators": [],
                    "summary": f"AI analysis unavailable: {str(e)}",
                    "recommendations": [],
                    "categories": []
                }
                ai_summary = "AI summary unavailable"
            
            # Log what we're about to return
            logger.info(f"📊 Returning Instagram result with:")
            logger.info(f"   - Profile: {profile_stats.username}")
            logger.info(f"   - Posts: {len(recent_posts)}")
            logger.info(f"   - Has cybercrime_analysis: {cybercrime_analysis is not None}")
            logger.info(f"   - Has ai_summary: {ai_summary is not None}")
            if cybercrime_analysis:
                logger.info(f"   - Risk Level: {cybercrime_analysis.get('risk_level')}")
                logger.info(f"   - Risk Score: {cybercrime_analysis.get('risk_score')}")
            
            result = InstagramSearchResult(
                profile=profile_stats,
                recent_posts=recent_posts,
                engagement_rate=engagement_rate,
                avg_likes=int(avg_likes),
                avg_comments=int(avg_comments),
                found=True,
                cybercrime_analysis=cybercrime_analysis,
                ai_summary=ai_summary
            )
            
            # Verify the result has the fields
            logger.info(f"✅ InstagramSearchResult created:")
            logger.info(f"   - cybercrime_analysis in result: {result.cybercrime_analysis is not None}")
            logger.info(f"   - ai_summary in result: {result.ai_summary is not None}")
            
            return result
            
        except instaloader.exceptions.ConnectionException as e:
            error_msg = str(e)
            logger.error(f"Connection error for {username}: {error_msg}")
            
            # Check if it's a rate limit error
            if "401" in error_msg or "Please wait" in error_msg or "rate" in error_msg.lower():
                logger.warning(f"Rate limit detected for {username}, attempt {retry_count + 1}")
                
                if retry_count < max_retries:
                    # Reset session and retry
                    reset_instaloader_session()
                    retry_count += 1
                    # Longer exponential backoff in production
                    if IS_PRODUCTION:
                        wait_time = 10 * (retry_count + 1)  # 10s, 20s in production
                    else:
                        wait_time = 3 * (retry_count + 1)  # 3s, 6s locally
                    logger.info(f"Waiting {wait_time} seconds before retry...")
                    time.sleep(wait_time)
                    continue
                else:
                    # Max retries reached - provide helpful message
                    error_msg = (
                        "Instagram rate limit reached. This is common on cloud servers. "
                        "The service will automatically retry. Please try again in 5-10 minutes, "
                        "or try searching for a different profile."
                    )
                    return InstagramSearchResult(
                        profile=None,
                        recent_posts=[],
                        engagement_rate=0.0,
                        avg_likes=0,
                        avg_comments=0,
                        found=False,
                        error=error_msg
                    )
            else:
                # Other connection error
                return InstagramSearchResult(
                    profile=None,
                    recent_posts=[],
                    engagement_rate=0.0,
                    avg_likes=0,
                    avg_comments=0,
                    found=False,
                    error=f"Connection error: {error_msg}"
                )
                
        except instaloader.exceptions.ProfileNotExistsException:
            logger.warning(f"Profile not found: {username}")
            return InstagramSearchResult(
                profile=None,
                recent_posts=[],
                engagement_rate=0.0,
                avg_likes=0,
                avg_comments=0,
                found=False,
                error=f"Profile @{username} not found on Instagram"
            )
            
        except Exception as e:
            logger.exception(f"Unexpected error fetching profile {username}")
            return InstagramSearchResult(
                profile=None,
                recent_posts=[],
                engagement_rate=0.0,
                avg_likes=0,
                avg_comments=0,
                found=False,
                error=f"Error: {str(e)}"
            )
    
    # Should not reach here, but just in case
    return InstagramSearchResult(
        profile=None,
        recent_posts=[],
        engagement_rate=0.0,
        avg_likes=0,
        avg_comments=0,
        found=False,
        error="Max retries exceeded"
    )


# Helper function to save search results and create result log
def save_search_result_and_log(
    db: Session,
    officer_id: Optional[int],
    search_type: str,
    search_query: str,
    result_data: dict
) -> Optional[int]:
    """
    Save search results to a JSON file and create a result log entry
    
    Args:
        db: Database session
        officer_id: ID of the officer performing the search (0 for admin)
        search_type: Type of search (e.g., "multi-platform", "single-platform")
        search_query: The search query/keyword
        result_data: The search result data to save
    
    Returns:
        Result log ID if successful, None otherwise
    """
    try:
        # Create results directory if it doesn't exist
        results_dir = Path("search_results")
        results_dir.mkdir(exist_ok=True)
        
        # Generate unique filename with timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_query = "".join(c if c.isalnum() else "_" for c in search_query)[:30]
        filename = f"{search_type}_{safe_query}_{timestamp}.json"
        file_path = results_dir / filename
        
        # Save result data to JSON file
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(result_data, f, indent=2, ensure_ascii=False, default=str)
        
        logger.info(f"Search results saved to: {file_path}")
        
        # Get or create search type ID
        from app.models.search_type import SearchType
        search_type_obj = db.query(SearchType).filter(
            SearchType.search_type == search_type
        ).first()
        
        if not search_type_obj:
            # Create new search type if it doesn't exist
            search_type_obj = SearchType(
                search_type=search_type,
                is_active=True
            )
            db.add(search_type_obj)
            db.commit()
            db.refresh(search_type_obj)
            logger.info(f"Created new search type: {search_type}")
        
        # Create result log entry
        result_log = ResultLogCreate(
            officer_id=officer_id,
            search_type_id=search_type_obj.id,
            search_query=search_query[:30],  # Limit to 30 chars as per model
            result_file_path=str(file_path),
            searched_at=datetime.utcnow()
        )
        
        db_log = create_result_log(db, result_log)
        logger.info(f"Result log created with ID: {db_log.id}")
        
        return db_log.id
        
    except Exception as e:
        logger.error(f"Error saving search result and log: {str(e)}")
        logger.exception(e)
        return None


# Helper function to search Instagram by hashtag/keyword
async def search_instagram_hashtag(keyword: str, limit: int = 20) -> HashtagSearchResult:
    """
    Search Instagram by hashtag or keyword
    """
    try:
        logger.info(f"Searching Instagram for keyword: {keyword}")
        
        # Remove # if present
        hashtag = keyword.replace('#', '')
        
        # Get hashtag object
        hashtag_obj = instaloader.Hashtag.from_name(L.context, hashtag)
        
        profiles_dict = {}
        top_posts = []
        post_count = 0
        
        # Get posts from hashtag
        for post in hashtag_obj.get_posts():
            if post_count >= limit:
                break
            
            # Add post to top posts
            post_data = InstagramPost(
                post_url=f"https://www.instagram.com/p/{post.shortcode}/",
                caption=post.caption if post.caption else None,
                likes=post.likes,
                comments=post.comments,
                date=post.date_utc.isoformat(),
                is_video=post.is_video,
                video_views=post.video_view_count if post.is_video else None
            )
            top_posts.append(post_data)
            
            # Add profile to unique profiles
            if post.owner_username not in profiles_dict:
                try:
                    profile = instaloader.Profile.from_username(L.context, post.owner_username)
                    profile_stats = InstagramProfileStats(
                        username=profile.username,
                        full_name=profile.full_name,
                        biography=profile.biography,
                        followers=profile.followers,
                        following=profile.followees,
                        posts_count=profile.mediacount,
                        is_private=profile.is_private,
                        is_verified=profile.is_verified,
                        profile_pic_url=profile.profile_pic_url
                    )
                    profiles_dict[post.owner_username] = profile_stats
                except Exception as e:
                    logger.warning(f"Error fetching profile {post.owner_username}: {str(e)}")
            
            post_count += 1
        
        return HashtagSearchResult(
            keyword=keyword,
            total_posts_found=post_count,
            profiles=list(profiles_dict.values()),
            top_posts=top_posts
        )
        
    except Exception as e:
        logger.error(f"Error searching hashtag {keyword}: {str(e)}")
        return HashtagSearchResult(
            keyword=keyword,
            total_posts_found=0,
            profiles=[],
            top_posts=[]
        )


# Type 1: Multi-Platform Search
@router.post("/multi-platform")
async def search_multi_platform(request: SearchRequest, db: Session = Depends(get_db)):
    """
    Search for a keyword/username across multiple social media platforms
    For Instagram: Uses Instaloader for real data
    For others: Returns placeholder data
    """
    logger.info(f"🔍 Multi-platform search started")
    logger.info(f"   Keyword: {request.keyword}")
    logger.info(f"   Platforms: {request.platforms}")
    
    results = []
    
    # Check if it's a username (no spaces, starts with @) or keyword
    is_username = not ' ' in request.keyword and (request.keyword.startswith('@') or len(request.keyword.split()) == 1)
    keyword = request.keyword.replace('@', '')
    
    logger.info(f"   Detected as: {'username' if is_username else 'keyword/hashtag'}")
    logger.info(f"   Cleaned keyword: {keyword}")
    
    for platform in request.platforms:
        try:
            logger.info(f"   📱 Searching {platform}...")
            
            if platform == "instagram":
                if is_username:
                    # Search for specific username
                    logger.info(f"      Fetching Instagram profile: @{keyword}")
                    instagram_data = await get_instagram_profile(keyword)
                    
                    if instagram_data.found:
                        logger.info(f"      ✅ Profile found!")
                        logger.info(f"         Followers: {instagram_data.profile.followers}")
                        logger.info(f"         Posts: {instagram_data.profile.posts_count}")
                        logger.info(f"         Recent posts fetched: {len(instagram_data.recent_posts)}")
                    else:
                        logger.warning(f"      ❌ Profile not found: {instagram_data.error}")
                    
                    result = PlatformResult(
                        platform=platform,
                        username=keyword,
                        found=instagram_data.found,
                        profile_url=f"https://instagram.com/{keyword}" if instagram_data.found else None,
                        last_activity=datetime.now().isoformat(),
                        instagram_data=instagram_data,
                        error=instagram_data.error
                    )
                else:
                    # Search by hashtag/keyword
                    logger.info(f"      Searching hashtag: #{keyword}")
                    hashtag_results = await search_instagram_hashtag(keyword, limit=10)
                    
                    logger.info(f"      ✅ Found {hashtag_results.total_posts_found} posts")
                    logger.info(f"         Unique profiles: {len(hashtag_results.profiles)}")
                    
                    result = PlatformResult(
                        platform=platform,
                        username=keyword,
                        found=hashtag_results.total_posts_found > 0,
                        profile_url=f"https://instagram.com/explore/tags/{keyword}/",
                        last_activity=datetime.now().isoformat(),
                        error=None if hashtag_results.total_posts_found > 0 else "No posts found"
                    )
            
            elif platform == "facebook":
                logger.info(f"      Searching Facebook...")
                # FAKE DATA INJECTION
                fb_data = {
                    "found": True,
                    "profile": {"profile_url": f"https://facebook.com/{keyword}"}
                }
                
                result = PlatformResult(
                    platform=platform,
                    username=keyword,
                    found=True,
                    profile_url=fb_data.get('profile', {}).get('profile_url') if is_username else f"https://facebook.com/search/top/?q={keyword}",
                    last_activity=datetime.now().isoformat(),
                    error=None
                )
            
            elif platform == "reddit":
                logger.info(f"      Searching Reddit...")
                # FAKE DATA INJECTION
                reddit_data = {
                    "found": True,
                    "profile": {"profile_url": f"https://reddit.com/user/{keyword}"}
                }
                
                result = PlatformResult(
                    platform=platform,
                    username=keyword,
                    found=True,
                    profile_url=reddit_data.get('profile', {}).get('profile_url') if is_username else f"https://www.reddit.com/search/?q={keyword}",
                    last_activity=datetime.now().isoformat(),
                    error=None
                )
            
            elif platform == "telegram":
                logger.info(f"      Searching Telegram...")
                # FAKE DATA INJECTION
                tg_data = {
                    "found": True,
                    "profile": {"profile_url": f"https://t.me/{keyword}"}
                }
                
                result = PlatformResult(
                    platform=platform,
                    username=keyword,
                    found=True,
                    profile_url=tg_data.get('profile', {}).get('profile_url') if is_username else f"https://t.me/s/{keyword}",
                    last_activity=datetime.now().isoformat(),
                    error=None
                )
            
            else:
                # Unknown platform
                logger.info(f"      ⏳ {platform.capitalize()} not yet integrated")
                result = PlatformResult(
                    platform=platform,
                    username=keyword,
                    found=False,
                    profile_url=None,
                    error=f"{platform.capitalize()} integration coming soon"
                )
            
            results.append(result)
            logger.info(f"      ✅ {platform.capitalize()} search complete")
            
        except Exception as e:
            logger.error(f"      ❌ Error searching {platform}: {str(e)}")
            logger.exception(e)
            results.append(PlatformResult(
                platform=platform,
                username=keyword,
                found=False,
                error=str(e)
            ))
    
    logger.info(f"✅ Multi-platform search completed. Results: {len(results)}")
    
    # Log Instagram result specifically to verify AI data
    for result in results:
        if result.platform == "instagram" and result.instagram_data:
            logger.info(f"📷 Instagram result in response:")
            logger.info(f"   - Has instagram_data: True")
            logger.info(f"   - Has profile: {result.instagram_data.profile is not None}")
            logger.info(f"   - Has cybercrime_analysis: {result.instagram_data.cybercrime_analysis is not None}")
            logger.info(f"   - Has ai_summary: {result.instagram_data.ai_summary is not None}")
            if result.instagram_data.cybercrime_analysis:
                logger.info(f"   - AI Risk Level: {result.instagram_data.cybercrime_analysis.get('risk_level')}")
    
    # Save search results and create result log
    try:
        result_data = {
            "search_type": "multi-platform",
            "keyword": request.keyword,
            "platforms": request.platforms,
            "officer_id": request.officer_id,
            "timestamp": datetime.now().isoformat(),
            "results": [r.dict() for r in results]
        }
        
        log_id = save_search_result_and_log(
            db=db,
            officer_id=request.officer_id,
            search_type="multi-platform",
            search_query=request.keyword,
            result_data=result_data
        )
        
        if log_id:
            logger.info(f"📝 Search logged with ID: {log_id}")
        else:
            logger.warning("⚠️ Failed to create result log")
    except Exception as e:
        logger.error(f"Error logging search results: {str(e)}")
        # Don't fail the request if logging fails
    
    return results



# Type 2: Single Platform Search
@router.post("/single-platform")
async def search_single_platform(request: SinglePlatformSearchRequest, db: Session = Depends(get_db)):
    """
    Deep search on a single platform for detailed profile information
    For Instagram: Uses Instaloader for comprehensive stats
    """
    logger.info(f"🔍 Single platform search started")
    logger.info(f"   Username: @{request.username}")
    logger.info(f"   Platform: {request.platform}")
    
    try:
        if request.platform == "instagram":
            logger.info(f"   📱 Fetching Instagram profile...")
            instagram_data = await get_instagram_profile(request.username)
            
            if not instagram_data.found:
                logger.warning(f"   ❌ Profile not found: {instagram_data.error}")
                raise HTTPException(status_code=404, detail=instagram_data.error or "Profile not found")
            
            logger.info(f"   ✅ Profile found!")
            logger.info(f"      Username: @{instagram_data.profile.username}")
            logger.info(f"      Full name: {instagram_data.profile.full_name}")
            logger.info(f"      Followers: {instagram_data.profile.followers}")
            logger.info(f"      Following: {instagram_data.profile.following}")
            logger.info(f"      Posts: {instagram_data.profile.posts_count}")
            logger.info(f"      Verified: {instagram_data.profile.is_verified}")
            logger.info(f"      Private: {instagram_data.profile.is_private}")
            logger.info(f"      Business: {instagram_data.profile.is_business_account}")
            logger.info(f"      Recent posts: {len(instagram_data.recent_posts)}")
            logger.info(f"      Engagement rate: {instagram_data.engagement_rate}%")
            
            # Save search results and create result log
            try:
                result_data = {
                    "search_type": "single-platform",
                    "username": request.username,
                    "platform": request.platform,
                    "officer_id": request.officer_id,
                    "timestamp": datetime.now().isoformat(),
                    "result": instagram_data.dict()
                }
                
                log_id = save_search_result_and_log(
                    db=db,
                    officer_id=request.officer_id,
                    search_type="single-platform",
                    search_query=request.username,
                    result_data=result_data
                )
                
                if log_id:
                    logger.info(f"📝 Search logged with ID: {log_id}")
                else:
                    logger.warning("⚠️ Failed to create result log")
            except Exception as e:
                logger.error(f"Error logging search results: {str(e)}")
                # Don't fail the request if logging fails
            
            return instagram_data
        elif request.platform in ["facebook", "reddit", "telegram"]:
            logger.info(f"   📱 Generating highly detailed Mock {request.platform.capitalize()} data...")
            
            mock_data: dict = {
                "platform": request.platform,
                "username": request.username,
                "found": True,
                "error": None
            }
            
            # Common AI metrics for all mocked platforms
            mock_ai = {
                "risk_level": random.choice(["low", "medium", "low", "high"]),
                "risk_score": random.randint(10, 85),
                "indicators": [
                    "Posts consistently at unusual hours",
                    "Multiple connections to unverified accounts",
                    "Uses VPN-associated IP pools (simulated)"
                ],
                "summary": f"This is an AI-generated mock summary for {request.username}. The account demonstrates standard activity typical of this platform. No imminent threats detected, though some engagement spikes are anomalous.",
                "categories": ["bot_activity", "spam_likelihood"]
            }
            
            if request.platform == "facebook":
                mock_data["profile"] = {
                    "full_name": f"{request.username.capitalize()} Smithing",
                    "profile_url": f"https://facebook.com/{request.username}",
                    "profile_pic": f"https://ui-avatars.com/api/?name={request.username}&background=3b5998&color=fff",
                    "followers": random.randint(400, 15000),
                    "friends": random.randint(150, 4999),
                    "is_private": random.choice([True, False]),
                    "join_date": "2012-04-18",
                    "hometown": "Chicago, IL",
                    "current_city": "New York, NY",
                    "workplace": "Self-Employed",
                    "education": "State University"
                }
                mock_data["engagement_rate"] = round(random.uniform(1.2, 8.5), 2)
                mock_data["recent_posts"] = [
                    {
                        "content": "Just had the most incredible tech meetup in the city! 🚀 Networking is everything.",
                        "likes": random.randint(40, 400),
                        "comments": random.randint(5, 50),
                        "shares": random.randint(0, 15),
                        "date": (datetime.now() - timedelta(hours=2)).isoformat(),
                        "visibility": "Public"
                    },
                    {
                        "content": "Can't believe how fast AI is evolving. Have you seen the latest models?",
                        "likes": random.randint(100, 800),
                        "comments": random.randint(20, 100),
                        "shares": random.randint(2, 40),
                        "date": (datetime.now() - timedelta(days=2)).isoformat(),
                        "visibility": "Public"
                    },
                    {
                        "content": "Vacation starts now! 🏖️ Switching off my laptop for a week.",
                        "likes": random.randint(200, 1200),
                        "comments": random.randint(40, 150),
                        "shares": 0,
                        "date": (datetime.now() - timedelta(days=14)).isoformat(),
                        "visibility": "Friends Only"
                    }
                ]
                mock_data["cybercrime_analysis"] = mock_ai
                
            elif request.platform == "reddit":
                mock_data["profile"] = {
                    "profile_url": f"https://reddit.com/user/{request.username}",
                    "avatar": f"https://ui-avatars.com/api/?name={request.username}&background=ff4500&color=fff",
                    "total_karma": random.randint(5000, 150000),
                    "post_karma": random.randint(1000, 80000),
                    "comment_karma": random.randint(4000, 70000),
                    "cake_day": "2016-09-24",
                    "is_premium": random.choice([True, False]),
                    "is_mod": random.choice([True, False, False]),
                    "top_subreddits": ["r/technology", "r/programming", "r/cybersecurity", "r/news"]
                }
                mock_data["recent_posts"] = [
                    {
                        "title": "A deep dive into the latest cybersecurity breaches of 2025",
                        "subreddit": "r/cybersecurity",
                        "upvotes": random.randint(500, 5000),
                        "comments": random.randint(50, 400),
                        "url": f"https://reddit.com/r/cybersecurity/comments/mock/{request.username}_post/",
                        "date": (datetime.now() - timedelta(days=1)).isoformat()
                    },
                    {
                        "title": "I built an open source OSINT tool, let me know what you think!",
                        "subreddit": "r/programming",
                        "upvotes": random.randint(1000, 12000),
                        "comments": random.randint(100, 800),
                        "url": f"https://reddit.com/r/programming/comments/mock/{request.username}_tool/",
                        "date": (datetime.now() - timedelta(days=5)).isoformat()
                    }
                ]
                mock_data["recent_comments"] = [
                    {
                        "subreddit": "r/technology",
                        "body": "It's all about properly sanitizing your inputs. Injection attacks are still way too common.",
                        "upvotes": random.randint(10, 500),
                        "date": (datetime.now() - timedelta(hours=5)).isoformat()
                    }
                ]
                mock_data["cybercrime_analysis"] = mock_ai
                
            elif request.platform == "telegram":
                mock_data["profile"] = {
                    "full_name": f"{request.username.capitalize()}",
                    "profile_url": f"https://t.me/{request.username}",
                    "profile_pic": f"https://ui-avatars.com/api/?name={request.username}&background=229ED9&color=fff",
                    "status": "last seen recently",
                    "bio": "Crypto enthusiast | Security Researcher 🔐",
                    "phone_number": "+1 (555) ***-**" + str(random.randint(10, 99)),
                    "is_bot": False,
                    "is_scam": False
                }
                mock_data["recent_activity"] = [
                    {
                        "type": "Group Message",
                        "channel": "Python Developers Chat",
                        "content": "Has anyone integrated MTProto directly in Python recently?",
                        "date": (datetime.now() - timedelta(minutes=45)).isoformat()
                    },
                    {
                        "type": "Forwarded File",
                        "channel": "OSINT Tools Global",
                        "content": "Document: investigation_guidelines.pdf",
                        "date": (datetime.now() - timedelta(days=2)).isoformat()
                    }
                ]
                mock_data["associated_groups"] = ["Python Developers Chat", "OSINT Tools Global", "Crypto Traders Hub"]
                mock_data["cybercrime_analysis"] = mock_ai
                
            try:
                result_data = {
                    "search_type": "single-platform",
                    "username": request.username,
                    "platform": request.platform,
                    "officer_id": request.officer_id,
                    "timestamp": datetime.now().isoformat(),
                    "result": mock_data
                }
                
                log_id = save_search_result_and_log(
                    db=db,
                    officer_id=request.officer_id,
                    search_type="single-platform",
                    search_query=request.username,
                    result_data=result_data
                )
                
                if log_id:
                    logger.info(f"📝 Search logged with ID: {log_id}")
            except Exception as e:
                logger.error(f"Error logging search results: {str(e)}")
                
            return mock_data
        else:
            logger.warning(f"   ⏳ {request.platform.capitalize()} not yet integrated")
            raise HTTPException(status_code=400, detail=f"{request.platform.capitalize()} integration coming soon")
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"   ❌ Error in single platform search: {str(e)}")
        logger.exception(e)
        raise HTTPException(status_code=500, detail=str(e))



# Type 3: Start Continuous Tracking
@router.post("/start-tracking", response_model=TrackingResponse)
async def start_tracking(request: TrackingRequest, db: Session = Depends(get_db)):
    """
    Set up continuous monitoring for a user on a specific platform
    """
    try:
        # Calculate end time
        duration_multipliers = {
            "hours": 1,
            "days": 24,
            "weeks": 24 * 7,
            "months": 24 * 30
        }
        
        hours = request.duration_value * duration_multipliers.get(request.duration_unit, 1)
        start_time = datetime.now()
        end_time = start_time + timedelta(hours=hours)
        
        # Generate tracking ID
        import random
        tracking_id = f"TRK-{request.platform.upper()}-{random.randint(10000, 99999)}"
        
        # TODO: Store tracking info in database
        # TODO: Set up background task for monitoring
        
        response = TrackingResponse(
            tracking_id=tracking_id,
            username=request.username,
            platform=request.platform,
            duration=f"{request.duration_value} {request.duration_unit}",
            frequency=request.frequency,
            start_time=start_time.isoformat(),
            end_time=end_time.isoformat(),
            status="active"
        )
        
        return response
        
    except Exception as e:
        logger.error(f"Error starting tracking: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


# Get tracking status
@router.get("/tracking/{tracking_id}")
async def get_tracking_status(tracking_id: str, db: Session = Depends(get_db)):
    """
    Get the status of an active tracking job
    """
    import random
    return {
        "tracking_id": tracking_id,
        "status": "active",
        "checks_completed": random.randint(1, 50),
        "last_check": datetime.now().isoformat(),
        "findings": random.randint(0, 10)
    }


# ========================================
# RESULT LOG ENDPOINTS
# ========================================

@router.get("/result-logs/recent")
async def get_recent_searches(
    officer_id: Optional[int] = None,
    limit: int = 50,
    db: Session = Depends(get_db)
):
    """
    Get recent searches, optionally filtered by officer ID
    
    Query Parameters:
        officer_id: Optional officer ID to filter by (omit to get all searches)
        limit: Maximum number of results (default: 50, max: 100)
    
    Returns:
        List of recent search logs with basic information
    """
    try:
        # Validate limit
        if limit > 100:
            limit = 100
        elif limit < 1:
            limit = 50
        
        logger.info(f"📋 Fetching recent searches (officer_id={officer_id}, limit={limit})")
        
        # Get recent searches
        result_logs = get_recent_searches_by_officer(
            db=db,
            officer_id=officer_id,
            limit=limit
        )
        
        # Convert to response format
        response = []
        for log in result_logs:
            response.append({
                "id": log.id,
                "officer_id": log.officer_id,
                "search_type_id": log.search_type_id,
                "search_type": log.search_type.search_type if log.search_type else None,
                "search_query": log.search_query,
                "searched_at": log.searched_at.isoformat(),
                "result_file_path": log.result_file_path
            })
        
        logger.info(f"✅ Found {len(response)} search logs")
        
        return {
            "total": len(response),
            "officer_id": officer_id,
            "limit": limit,
            "searches": response
        }
        
    except Exception as e:
        logger.error(f"Error fetching recent searches: {str(e)}")
        logger.exception(e)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/result-logs/{log_id}")
async def get_result_log_detail(
    log_id: int,
    db: Session = Depends(get_db)
):
    """
    Get detailed information about a specific result log by ID
    
    Path Parameters:
        log_id: ID of the result log
    
    Returns:
        Detailed result log information including the saved search results
    """
    try:
        logger.info(f"📄 Fetching result log details for ID: {log_id}")
        
        # Get result log from database
        result_log = get_result_log_by_id(db=db, log_id=log_id)
        
        if not result_log:
            logger.warning(f"Result log not found: {log_id}")
            raise HTTPException(status_code=404, detail=f"Result log with ID {log_id} not found")
        
        # Read the saved JSON file
        search_results = None
        file_exists = False
        
        try:
            file_path = Path(result_log.result_file_path)
            if file_path.exists():
                file_exists = True
                with open(file_path, 'r', encoding='utf-8') as f:
                    search_results = json.load(f)
                logger.info(f"✅ Loaded search results from: {file_path}")
            else:
                logger.warning(f"⚠️ Result file not found: {file_path}")
        except Exception as e:
            logger.error(f"Error reading result file: {str(e)}")
        
        # Build response
        response = {
            "log_info": {
                "id": result_log.id,
                "officer_id": result_log.officer_id,
                "officer_name": result_log.officer.name if result_log.officer else "Admin",
                "search_type_id": result_log.search_type_id,
                "search_type": result_log.search_type.search_type if result_log.search_type else None,
                "search_query": result_log.search_query,
                "searched_at": result_log.searched_at.isoformat(),
                "result_file_path": result_log.result_file_path,
                "file_exists": file_exists
            },
            "search_results": search_results
        }
        
        logger.info(f"✅ Result log details retrieved successfully")
        
        return response
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching result log details: {str(e)}")
        logger.exception(e)
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/result-file")
def result_file(
    file_path: str,
    db: Session = Depends(get_db)
):
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="File not found")   

    if not file_path.endswith(".json"):
        raise HTTPException(status_code=400, detail="Only JSON files are allowed")

    try:
        with open(file_path, "r", encoding="utf-8") as file:
            data = json.load(file)

        return data

    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Invalid JSON file")

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))