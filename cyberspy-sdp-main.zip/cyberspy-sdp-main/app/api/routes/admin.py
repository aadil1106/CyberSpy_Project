from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from typing import Optional
from datetime import datetime

from app.db.session import get_db
from app.schemas.admin import ReportFilter, DetailedReportRead
from app.services import admin_service

router = APIRouter()


@router.get("/reports/detailed", response_model=list[DetailedReportRead])
def get_detailed_reports(
    officer_id: Optional[int] = Query(None),
    branch_id: Optional[int] = Query(None),
    city_id: Optional[int] = Query(None),
    search_type_id: Optional[int] = Query(None),
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    social_media: Optional[str] = Query(None),
    username: Optional[str] = Query(None),
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    db: Session = Depends(get_db)
):
    """
    Get detailed reports with various filters.
    """
    filters = ReportFilter(
        officer_id=officer_id,
        branch_id=branch_id,
        city_id=city_id,
        search_type_id=search_type_id,
        start_date=start_date,
        end_date=end_date,
        social_media=social_media,
        username=username
    )
    
    reports = admin_service.get_detailed_reports(db, filters, skip=skip, limit=limit)
    return reports


@router.get("/reports/statistics")
def get_report_statistics(
    officer_id: Optional[int] = Query(None),
    branch_id: Optional[int] = Query(None),
    city_id: Optional[int] = Query(None),
    search_type_id: Optional[int] = Query(None),
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    social_media: Optional[str] = Query(None),
    username: Optional[str] = Query(None),
    db: Session = Depends(get_db)
):
    """
    Get aggregated statistics for reports based on filters.
    """
    filters = ReportFilter(
        officer_id=officer_id,
        branch_id=branch_id,
        city_id=city_id,
        search_type_id=search_type_id,
        start_date=start_date,
        end_date=end_date,
        social_media=social_media,
        username=username
    )
    
    stats = admin_service.get_report_statistics(db, filters)
    return stats

@router.get("/dashboard-stats")
def get_admin_dashboard_stats(db: Session = Depends(get_db)):
    """
    Get generic dashboard statistics comparing current values to previous month's historical values.
    """
    stats = admin_service.get_dashboard_stats(db)
    return stats

