from datetime import datetime

from sqlalchemy import Boolean, Column, Date, DateTime, ForeignKey, Integer, String
from sqlalchemy.orm import relationship

from app.db.session import Base


class Officer(Base):
    __tablename__ = "officers_tbl"

    id = Column(Integer, primary_key=True, index=True)
    branch_id = Column(Integer, ForeignKey("branch_tbl.id"), nullable=False)
    first_name = Column(String(25), nullable=False)
    last_name = Column(String(25), nullable=False)
    gender = Column(String(1), nullable=False)
    dob = Column(Date, nullable=False)
    phone_no = Column(String(15), nullable=False, unique=True)
    email = Column(String(50), nullable=False, unique=True)
    password = Column(String(128), nullable=False)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    modified_at = Column(DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_active = Column(Boolean, nullable=False, default=True)

    branch = relationship("Branch", back_populates="officers")
    result_logs = relationship("ResultLog", back_populates="officer", cascade="all, delete-orphan")
    login_logs = relationship("OfficerLoginLog", back_populates="officer", cascade="all, delete-orphan")

