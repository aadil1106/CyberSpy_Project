from datetime import datetime

from sqlalchemy import Column, DateTime, ForeignKey, Integer
from sqlalchemy.orm import relationship

from app.db.session import Base


class OfficerLoginLog(Base):
    __tablename__ = "officer_login_logs_tbl"

    id = Column(Integer, primary_key=True, index=True)
    officer_id = Column(Integer, ForeignKey("officers_tbl.id"), nullable=False)
    loggedin_at = Column(DateTime, nullable=False, default=datetime.utcnow)

    officer = relationship("Officer", back_populates="login_logs")

