from datetime import datetime

from sqlalchemy import Column, DateTime, ForeignKey, Integer, String
from sqlalchemy.orm import relationship

from app.db.session import Base


class ResultLog(Base):
    __tablename__ = "result_logs_tbl"

    id = Column(Integer, primary_key=True, index=True)
    officer_id = Column(Integer, ForeignKey("officers_tbl.id"), nullable=False)
    search_type_id = Column(Integer, ForeignKey("search_type_tbl.id"), nullable=False)
    search_query = Column(String(30), nullable=False)
    searched_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    result_file_path = Column(String(255), nullable=False)

    officer = relationship("Officer", back_populates="result_logs")
    search_type = relationship("SearchType", back_populates="result_logs")
    report_logs = relationship("ReportLog", back_populates="result_log")

