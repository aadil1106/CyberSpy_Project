from sqlalchemy import Boolean, Column, Integer, String
from sqlalchemy.orm import relationship

from app.db.session import Base


class SearchType(Base):
    __tablename__ = "search_type_tbl"

    id = Column(Integer, primary_key=True, index=True)
    search_type = Column(String(25), nullable=False, unique=True)
    is_active = Column(Boolean, nullable=False, default=True)

    result_logs = relationship("ResultLog", back_populates="search_type")

