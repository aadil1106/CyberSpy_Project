from sqlalchemy import Boolean, Column, ForeignKey, Integer, String
from sqlalchemy.orm import relationship, backref

from app.db.session import Base


class Branch(Base):
    __tablename__ = "branch_tbl"

    id = Column(Integer, primary_key=True, index=True)
    city_id = Column(Integer, ForeignKey("city_tbl.id"), nullable=False)
    branch_name = Column(String(25), nullable=False)
    pincode = Column(Integer, nullable=False)
    is_active = Column(Boolean, nullable=False, default=True)

    city = relationship("City", backref=backref("branches", cascade="all, delete-orphan"))
    officers = relationship("Officer", back_populates="branch", cascade="all, delete-orphan")

    @property
    def officer_count(self) -> int:
        return len(self.officers) if self.officers else 0

