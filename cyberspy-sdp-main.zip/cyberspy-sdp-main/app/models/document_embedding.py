"""
SQLAlchemy model for storing document embeddings in SQLite
"""
from sqlalchemy import Column, Integer, String, Text, JSON, DateTime
from datetime import datetime

from app.db.session import Base


class DocumentEmbedding(Base):
    __tablename__ = "document_embeddings_tbl"

    id = Column(Integer, primary_key=True, index=True)
    content = Column(Text, nullable=False)

    embedding = Column(JSON, nullable=False)  # Stores embedding as JSON array

    # 🚨 Renamed from `metadata` (reserved)
    doc_metadata = Column(JSON, nullable=True)

    source = Column(String(500), nullable=True)
    created_at = Column(DateTime, nullable=False, default=datetime.utcnow)

