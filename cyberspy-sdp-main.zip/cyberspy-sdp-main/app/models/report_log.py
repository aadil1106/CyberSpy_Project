from datetime import datetime

from sqlalchemy import Column, DateTime, ForeignKey, Integer, String
from sqlalchemy.orm import relationship

from app.db.session import Base


class ReportLog(Base):
    __tablename__ = "report_logs_tbl"

    id = Column(Integer, primary_key=True, index=True)
    result_log_id = Column(Integer, ForeignKey("result_logs_tbl.id"), nullable=False)
    username = Column(String(25), nullable=False)
    social_media = Column(String(30), nullable=False)
    reported_at = Column(DateTime, nullable=False, default=datetime.utcnow)
    reporting_results = Column(String(255), nullable=False)

    result_log = relationship("ResultLog", back_populates="report_logs")

