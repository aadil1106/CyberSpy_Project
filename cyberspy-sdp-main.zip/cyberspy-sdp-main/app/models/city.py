from sqlalchemy import Boolean, Column, Integer, String

from app.db.session import Base


class City(Base):
    __tablename__ = "city_tbl"

    id = Column(Integer, primary_key=True, index=True)
    city_name = Column(String(25), nullable=False)
    is_active = Column(Boolean, nullable=False, default=True)

    @property
    def branch_count(self) -> int:
        return len(self.branches) if self.branches else 0

