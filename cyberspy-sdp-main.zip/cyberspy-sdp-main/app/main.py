import os
import logging
from contextlib import asynccontextmanager
import asyncio

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import RedirectResponse

from app.api.routes import api_router
from app.core.config import get_settings
from app.db import session as db_session
from app.models import *  # noqa: F401,F403

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)
logger.info("🚀 Starting Activity Monitoring Backend...")

settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Lifespan context manager.
    Ports will open immediately.
    Heavy AI loading runs in background.
    """

    logger.info("⚙️ Creating database tables...")
    db_session.Base.metadata.create_all(bind=db_session.engine)

    yield  

    async def init_llm_background():
        if not settings.chatbot_enabled:
            logger.info("🤖 Chatbot disabled — skipping RAG init")
            return

        try:
            logger.info("🤖 Initializing RAG chatbot service in background...")

            from app.services.rag_service import initialize_rag

            loop = asyncio.get_running_loop()

            rag_initialized = await loop.run_in_executor(
                None,
                initialize_rag
            )

            if rag_initialized:
                logger.info("✅ RAG chatbot initialized successfully")
            else:
                logger.warning("⚠️ RAG chatbot initialization failed")

        except Exception as e:
            logger.error(f"❌ Error initializing RAG service: {str(e)}")

    asyncio.create_task(init_llm_background())

    logger.info("🛑 Application shutting down...")



app = FastAPI(
    title=settings.app_name, 
    debug=settings.debug,
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Add request logging middleware
@app.middleware("http")
async def log_requests(request, call_next):
    logger.info(f"📥 {request.method} {request.url.path}")
    if request.method == "POST":
        logger.info(f"   Headers: {dict(request.headers)}")
    
    response = await call_next(request)
    
    logger.info(f"📤 Response: {response.status_code}")
    return response


app.include_router(api_router, prefix=settings.api_prefix)


# Serve static files for admin panel (only in non-serverless environments)
static_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "static")
if os.path.exists(static_dir) and not os.environ.get("VERCEL"):
    app.mount("/static", StaticFiles(directory=static_dir), name="static")


@app.get("/")
def root():
    """Redirect to admin panel"""
    return RedirectResponse(url="/static/admin/index.html")


@app.get("/health")
def health_check():
    """Health check endpoint for Vercel"""
    return {"status": "healthy", "app": settings.app_name}


