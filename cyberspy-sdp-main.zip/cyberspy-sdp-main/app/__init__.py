# Package initializer for the activity monitoring backend.

