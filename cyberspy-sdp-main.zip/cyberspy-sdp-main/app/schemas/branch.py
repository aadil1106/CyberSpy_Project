from typing import Optional

from pydantic import BaseModel


class BranchBase(BaseModel):
    city_id: int
    branch_name: str
    pincode: int
    is_active: Optional[bool] = True


class BranchCreate(BranchBase):
    pass


class BranchUpdate(BaseModel):
    city_id: Optional[int] = None
    branch_name: Optional[str] = None
    pincode: Optional[int] = None
    is_active: Optional[bool] = None


class BranchRead(BranchBase):
    id: int
    officer_count: Optional[int] = 0

    class Config:
        from_attributes = True

