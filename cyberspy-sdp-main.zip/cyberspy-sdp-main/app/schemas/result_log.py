from datetime import datetime
from typing import Optional

from pydantic import BaseModel


class ResultLogBase(BaseModel):
    officer_id: int
    search_type_id: int
    search_query: str
    result_file_path: str
    searched_at: Optional[datetime] = None


class ResultLogCreate(ResultLogBase):
    pass


class ResultLogRead(ResultLogBase):
    id: int
    searched_at: datetime

    class Config:
        from_attributes = True

