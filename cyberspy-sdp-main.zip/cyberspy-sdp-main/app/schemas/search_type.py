from typing import Optional

from pydantic import BaseModel


class SearchTypeBase(BaseModel):
    search_type: str
    is_active: Optional[bool] = True


class SearchTypeCreate(SearchTypeBase):
    pass


class SearchTypeUpdate(BaseModel):
    search_type: Optional[str] = None
    is_active: Optional[bool] = None


class SearchTypeRead(SearchTypeBase):
    id: int

    class Config:
        from_attributes = True

