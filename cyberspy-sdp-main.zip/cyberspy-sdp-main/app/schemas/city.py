from typing import Optional

from pydantic import BaseModel


class CityBase(BaseModel):
    city_name: str
    is_active: Optional[bool] = True


class CityCreate(CityBase):
    pass


class CityUpdate(BaseModel):
    city_name: Optional[str] = None
    is_active: Optional[bool] = None


class CityRead(CityBase):
    id: int
    branch_count: Optional[int] = 0

    class Config:
        from_attributes = True

