from datetime import datetime

from pydantic import BaseModel


class OfficerLoginLogBase(BaseModel):
    officer_id: int
    loggedin_at: datetime | None = None


class OfficerLoginLogCreate(OfficerLoginLogBase):
    pass


class OfficerLoginLogRead(OfficerLoginLogBase):
    id: int
    loggedin_at: datetime

    class Config:
        from_attributes = True

