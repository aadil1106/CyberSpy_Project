from datetime import date, datetime
from typing import Optional

from pydantic import BaseModel, EmailStr, Field


class OfficerBase(BaseModel):
    branch_id: int
    first_name: str
    last_name: str
    gender: str = Field(..., min_length=1, max_length=1)
    dob: date
    phone_no: str
    email: EmailStr
    is_active: Optional[bool] = True


class OfficerCreate(OfficerBase):
    password: str = Field(..., min_length=6)


class OfficerUpdate(BaseModel):
    branch_id: Optional[int] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    gender: Optional[str] = Field(None, min_length=1, max_length=1)
    dob: Optional[date] = None
    phone_no: Optional[str] = None
    email: Optional[EmailStr] = None
    password: Optional[str] = Field(None, min_length=6)
    is_active: Optional[bool] = None


class OfficerRead(OfficerBase):
    id: int
    created_at: datetime
    modified_at: datetime

    class Config:
        from_attributes = True


class OfficerLogin(BaseModel):
    email: str
    password: str


class OfficerInfo(BaseModel):
    """Officer information schema"""
    id: int
    email: str
    first_name: str
    last_name: str
    branch_id: int
    is_active: bool
    gender: str
    dob: date
    phone_no: str
    created_at: datetime = None
    modified_at: datetime = None
    
    class Config:
        from_attributes = True


class OfficerLoginResponse(BaseModel):
    """Response schema for successful officer login"""
    access_token: str
    token_type: str = "bearer"
    officer: OfficerInfo
    
    class Config:
        from_attributes = True
