from datetime import datetime
from typing import Optional

from pydantic import BaseModel


class ReportFilter(BaseModel):
    officer_id: Optional[int] = None
    branch_id: Optional[int] = None
    city_id: Optional[int] = None
    search_type_id: Optional[int] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    social_media: Optional[str] = None
    username: Optional[str] = None


class DetailedReportRead(BaseModel):
    report_id: int
    result_log_id: int
    officer_id: int
    officer_name: str
    branch_id: int
    branch_name: str
    city_id: int
    city_name: str
    search_type_id: int
    search_type_name: Optional[str] = None
    search_query: str
    username: str
    social_media: str
    reporting_results: str
    searched_at: datetime
    reported_at: datetime
    result_file_path: str

    class Config:
        from_attributes = True

