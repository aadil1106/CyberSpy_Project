from datetime import datetime
from typing import Optional

from pydantic import BaseModel


class ReportLogBase(BaseModel):
    result_log_id: int
    username: str
    social_media: str
    reporting_results: str
    reported_at: Optional[datetime] = None


class ReportLogCreate(ReportLogBase):
    pass


class ReportLogRead(ReportLogBase):
    id: int
    reported_at: datetime

    class Config:
        from_attributes = True

