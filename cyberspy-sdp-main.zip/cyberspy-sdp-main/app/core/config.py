from functools import lru_cache

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    app_name: str = "Activity Monitoring Backend"
    api_prefix: str = "/api"
    database_url: str = "sqlite:///./activity_monitoring.db"
    debug: bool = True
    gemini_api_key: str = ""
    chatbot_enabled: bool = True
    chatbot_max_requests_per_minute: int = 10
    chatbot_max_requests_per_hour: int = 100

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


@lru_cache
def get_settings() -> Settings:
    return Settings()

