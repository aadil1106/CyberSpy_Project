"""
Script to Reinitialize RAG Vector Store with Updated Documentation

This script will:
1. Clear the existing vector embeddings from the database
2. Reload all documentation files from system_docs/
3. Create new vector embeddings
4. Store them in the SQLite database

Run this after updating documentation files to make the chatbot aware of changes.
"""

import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app.db.session import SessionLocal, engine
from app.models.document_embedding import DocumentEmbedding
from app.db.session import Base
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def reinitialize_vectors():
    """Reinitialize the vector store with updated documentation"""
    
    print("=" * 60)
    print("🔄 Reinitializing RAG Vector Store")
    print("=" * 60)
    
    # Step 1: Clear existing embeddings
    print("\n📝 Step 1: Clearing existing vector embeddings...")
    db = SessionLocal()
    try:
        count = db.query(DocumentEmbedding).count()
        print(f"   Found {count} existing embeddings")
        
        if count > 0:
            db.query(DocumentEmbedding).delete()
            db.commit()
            print(f"   ✅ Deleted {count} old embeddings")
        else:
            print("   ℹ️  No existing embeddings found")
    except Exception as e:
        print(f"   ❌ Error clearing embeddings: {str(e)}")
        db.rollback()
        return False
    finally:
        db.close()
    
    # Step 2: Reinitialize RAG service (this will reload docs)
    print("\n📚 Step 2: Reloading documentation and creating new embeddings...")
    try:
        from app.services.rag_service import initialize_rag
        
        success = initialize_rag()
        
        if success:
            print("   ✅ RAG service reinitialized successfully")
            
            # Verify new embeddings
            db = SessionLocal()
            try:
                new_count = db.query(DocumentEmbedding).count()
                print(f"   ✅ Created {new_count} new embeddings")
            finally:
                db.close()
            
            return True
        else:
            print("   ❌ Failed to reinitialize RAG service")
            return False
            
    except Exception as e:
        print(f"   ❌ Error reinitializing RAG: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def verify_documentation():
    """Verify that documentation files exist"""
    print("\n🔍 Verifying documentation files...")
    
    docs_dir = "system_docs"
    expected_files = [
        "00_user_guide.md",  # User-focused guide (prioritized)
        "01_system_overview.md",
        "02_api_documentation.md",
        "03_usage_guide.md",
        "04_troubleshooting.md"
    ]
    
    all_exist = True
    for filename in expected_files:
        filepath = os.path.join(docs_dir, filename)
        if os.path.exists(filepath):
            size = os.path.getsize(filepath)
            priority = "⭐ PRIORITY" if filename == "00_user_guide.md" else ""
            print(f"   ✅ {filename} ({size:,} bytes) {priority}")
        else:
            print(f"   ❌ {filename} - NOT FOUND")
            all_exist = False
    
    # Check README
    if os.path.exists("README.md"):
        size = os.path.getsize("README.md")
        print(f"   ✅ README.md ({size:,} bytes)")
    else:
        print(f"   ⚠️  README.md - NOT FOUND (optional)")
    
    return all_exist


def test_chatbot():
    """Test the chatbot with a sample question"""
    print("\n🧪 Testing chatbot with sample question...")
    
    try:
        from app.services.rag_service import query_rag
        import asyncio
        
        question = "What are the main features of the Activity Monitoring System?"
        print(f"   Question: {question}")
        
        result = asyncio.run(query_rag(question))
        
        if result.get("error"):
            print(f"   ❌ Error: {result['error']}")
            return False
        
        answer = result.get("answer", "")
        sources = result.get("sources", [])
        
        print(f"\n   Answer preview: {answer[:200]}...")
        print(f"   Sources: {', '.join(sources)}")
        print("   ✅ Chatbot is working!")
        return True
        
    except Exception as e:
        print(f"   ❌ Error testing chatbot: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """Main execution"""
    print("\n🚀 Starting Vector Store Reinitialization Process\n")
    
    # Step 1: Verify documentation
    if not verify_documentation():
        print("\n⚠️  Warning: Some documentation files are missing!")
        response = input("Continue anyway? (y/n): ")
        if response.lower() != 'y':
            print("Aborted.")
            return
    
    # Step 2: Reinitialize vectors
    success = reinitialize_vectors()
    
    if not success:
        print("\n❌ Failed to reinitialize vector store")
        print("Please check the error messages above and try again.")
        return
    
    # Step 3: Test chatbot
    print("\n" + "=" * 60)
    test_chatbot()
    
    print("\n" + "=" * 60)
    print("✅ Vector Store Reinitialization Complete!")
    print("=" * 60)
    print("\nThe chatbot now has access to the updated documentation.")
    print("You can test it by:")
    print("  1. Starting the server: python main.py")
    print("  2. Asking questions via: POST /api/chatbot/chat")
    print("\nExample questions to try:")
    print("  - What are the main features of this system?")
    print("  - How do I perform a multi-platform search?")
    print("  - What are the different risk levels?")
    print("  - How does the RAG chatbot work?")
    print("  - What is mass reporting?")
    print()


if __name__ == "__main__":
    main()
